﻿
Public Module DialogModule

    Sub InfoBox(message As String)
        MsgBox(message, MsgBoxStyle.Information, "Notice")
    End Sub

    Sub WarnBox(message As String)
        MsgBox(message, MsgBoxStyle.Exclamation, "Warning")
    End Sub

    Sub ErrorBox(message As String)
        MsgBox(message, MsgBoxStyle.Critical, "Error")
    End Sub

    Sub AskForAssistance(why As String)

        Dim msg = "Ask Dave for Assistance. Tell him this:" + vbNewLine + vbNewLine + why
        InfoBox(msg)

    End Sub

End Module

