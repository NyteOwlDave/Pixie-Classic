﻿
Friend Module InternalModule

    Friend Function PathNameContainsSpaces(ByVal pathName As String) As Boolean

        Return pathName.Contains(" ")

    End Function

End Module
