﻿
Public Module ShellModule

    Public Function ShellOpen(pathName As String, Optional arguments As String = "") As Boolean

        Try
            Dim shell As New NCS.ShellProcess(pathName)
            Return shell.Execute(arguments)
        Catch ex As Exception
            WarnBox(ex.Message)
            Return False
        End Try

    End Function

End Module

