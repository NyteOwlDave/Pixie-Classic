﻿
Module NetworkModuleWin

    Private _myLocalNetwork As NCS.LocalNetwork

    Public ReadOnly Property MyLocalNetwork As NCS.LocalNetwork
        Get
            Return _myLocalNetwork
        End Get
    End Property

    Sub Initialize()

        NetworkModuleWin._myLocalNetwork = New NCS.LocalNetwork

    End Sub

End Module

