﻿
Public Class ChooseFolderForm

    Private myMessage As String = String.Empty

    Public Property Message As String
        Get
            Return myMessage
        End Get
        Set(value As String)
            myMessage = GetSafeString(value)
        End Set
    End Property

    Public Property SelectedFolder As String
        Get
            Return GetSafeFolder(My.Settings.ImportFolder)
        End Get
        Set(value As String)
            My.Settings.ImportFolder = value
        End Set
    End Property

    Private Function GetSafeFolder(folder As String) As String
        If String.IsNullOrWhiteSpace(folder) Then folder = "?"
        If folder = "?" Or (Not IO.Directory.Exists(folder)) Then
            folder = My.Computer.FileSystem.SpecialDirectories.MyPictures
        End If
        Return folder
    End Function

    Private Sub ThrowBadFolder(folder As String)
        Throw New ArgumentException("Invalid folder: " & folder)
    End Sub

    Private Function IsDrive(folder As String) As Boolean
        folder = GetSafeString(folder)
        Dim len As Integer = folder.Length
        If len < 3 Then
            ThrowBadFolder(folder)
            Return False ' Redundant
        End If
        If len > 3 Then Return False
        If Not IO.Path.IsPathRooted(folder) Then
            ThrowBadFolder(folder)
            Return False ' Redundant
        End If
        Return True
    End Function

    Private Function GetImageKey(folder As String) As String
        If IsDrive(folder) Then Return "Drive"
        Return "Folder"
    End Function

    Private Function CreateNode(folder As String) As TreeNode
        Dim name As String = IO.Path.GetFileName(folder)
        Dim node As New TreeNode(name)
        node.ImageKey = GetImageKey(folder)
        node.SelectedImageKey = node.ImageKey
        node.Tag = folder
        Dim dummy As New TreeNode("dummy")
        node.Nodes.Add(dummy)
        Return node
    End Function

    Private Function PopulateNode(node As TreeNode) As Boolean
        node.Nodes.Clear()
        If node Is Nothing Then GoTo Failed
        Dim folder As String = CStr(node.Tag)
        If Not IO.Directory.Exists(folder) Then GoTo Failed
        Dim folders As String() = IO.Directory.GetDirectories(folder)
        If folders.Count < 1 Then GoTo Failed
        Dim item As String
        Dim child As TreeNode
        For Each item In folders
            child = CreateNode(item)
            node.Nodes.Add(child)
        Next
        Return True
Failed:
        child = New TreeNode("dummy")
        node.Nodes.Add(child)
        Return False
    End Function

    Private Sub PopulateTree()
        Dim folder As String = SelectedFolder
        Dim root As TreeNode = CreateNode(folder)
        With TreeView1
            .Nodes.Clear()
            .Nodes.Add(root)
        End With
        ' Handled automatically during expand
        ' PopulateNode(root)
        root.Expand()
    End Sub

    Private Sub ChooseFolderForm_Load(sender As Object, e As EventArgs) Handles Me.Load
        If myMessage.Length > 0 Then
            Me.PixieSaysLabel.Text = myMessage
        End If
        PopulateTree()
    End Sub

    Private Sub OK_Button_Click(sender As Object, e As EventArgs) Handles OK_Button.Click
        Dim node As TreeNode = TreeView1.SelectedNode
        If node Is Nothing Then
            InfoBox("Please select a folder before clicking OK.")
            Return
        End If
        Me.SelectedFolder = CStr(node.Tag)
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

    Private Sub TreeView1_BeforeExpand(sender As Object, e As TreeViewCancelEventArgs) Handles TreeView1.BeforeExpand
        Dim ok As Boolean = False
        Try
            ok = Me.PopulateNode(e.Node)
        Catch ex As Exception
            Dim msg As String = "Error:" & vbCrLf = ex.Message
            InfoBox(msg)
        End Try
        e.Cancel = Not ok
    End Sub

    Private Sub ExploreButton_Click(sender As Object, e As EventArgs) Handles ExploreButton.Click
        Dim node As TreeNode = TreeView1.SelectedNode
        If node Is Nothing Then
            InfoBox("Please select a folder before clicking Explore.")
            Return
        End If
        Dim folder As String = CStr(node.Tag)
        Try
            Process.Start("explorer.exe", Chr(34) & folder & Chr(34))
            Threading.Thread.Sleep(10)
        Catch ex As Exception
            Dim msg As String = "Error:" & vbCrLf & ex.Message
            InfoBox(msg)
        End Try
    End Sub

End Class
