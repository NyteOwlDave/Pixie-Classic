﻿
Public Class CopyProgressForm

    ' Operation ID codes
    Public Enum OperationID
        Test
        Import
        Export
    End Enum

    ' Set the operation ID (called from parent/assistant)
    Public Sub SetOperation(id As OperationID, pix As StringList)
        With Me.State
            .Pictures = pix
            .Operation = id
        End With
    End Sub

    ' Internal copy state class
    Private Class WorkerThreadState
        Private ID As OperationID = OperationID.Test
        Private Callback As FileOperationThread.Handler = Nothing
        Private Pictures As New StringList
        Public Function Initialize(pix As StringList, callback As FileOperationThread.Handler) As Boolean
            Me.Callback = callback
            Me.Pictures = pix
            Return Me.Initialized
        End Function
        Public ReadOnly Property Initialized As Boolean
            Get
                If Me.Pictures.Count > 0 Then
                    If Me.Callback Is Nothing Then
                        Return False
                    Else
                        Return True
                    End If
                Else
                    Return False
                End If
            End Get
        End Property
        Public Sub Invoke(operation As OperationID)
            Me.ID = operation
            If Not Me.Initialized Then
                DebugOut("Invoke failed because CopyState is not initialized.")
                Return
            End If
            Select Case operation
                Case OperationID.Export : Me.InvokeExport()
                Case OperationID.Import : Me.InvokeImport()
                Case OperationID.Test : Me.InvokeTest()
            End Select
        End Sub
        Private Sub InvokeTest()
            InfoBox("Test mode invoked.")
        End Sub
        Private Sub InvokeExport()
            Try
                Dim export As New PictureExporter
                export.Execute(Me.Pictures, Me.Callback)
            Catch ex As Exception
                SilentExceptionReport(ex)
                DebugOut("Failed to invoke PictureExporter thread.")
            End Try
        End Sub
        Private Sub InvokeImport()
            Try
                Dim import As New PictureImporter
                import.Execute(Me.Pictures, Me.Callback)
            Catch ex As Exception
                SilentExceptionReport(ex)
                DebugOut("Failed to invoke PictureImporter thread.")
            End Try
        End Sub
    End Class

    ' Internal state class
    Private Class InternalState
        Public Cancel As Boolean = False
        Public PercentComplete As Integer = 0
        Public Operation As OperationID = OperationID.Test
        Public Pictures As New StringList
        Private WorkerThread As New WorkerThreadState
        Public Function Initialize(frm As CopyProgressForm) As Boolean
            Me.Cancel = False
            If Not Me.WorkerThread.Initialize(Me.Pictures, AddressOf frm.ReportFileCopied) Then
                Return False
            End If
            Me.PercentComplete = 0
            Me.ShowOperationImage(frm.CopyActionButton)
            Return Me.Initialized
        End Function
        Public ReadOnly Property Initialized As Boolean
            Get
                Return Me.WorkerThread.Initialized
            End Get
        End Property
        Public Sub InvokeWorkerThread()
            If Me Is Nothing Then
                DebugOut("InternalState instance is not initialized.")
                Return
            End If
            If Me.WorkerThread Is Nothing Then
                DebugOut("WorkerThread instance is not initialized.")
                Return
            End If
            Me.WorkerThread.Invoke(Me.Operation)
        End Sub
        Public Sub ReportFailed(file As String)
            ' TODO... add to a string list for later review
            DebugOut("Failed to copy:")
            DebugOut(file)
        End Sub
        Private Sub ShowOperationImage(button As Windows.Forms.PictureBox)
            Select Case Me.Operation
                Case OperationID.Export
                    Dim export As New ExportAssistant
                    export.ShowImage(button)
                Case OperationID.Import
                    Dim import As New ImportAssistant
                    import.ShowImage(button)
            End Select
        End Sub
    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Initialization
    Private Sub Initialize()
        If Me.State.Initialize(Me) Then
            Me.PixieSays("Well I'm copying your files now. So please don't remove the device until I'm done.")
            Me.ProgressTimer.Enabled = False
            Me.OneShot.Enabled = True
            Return
        End If
        Throw New Exception("The internal state did not initialize.")
    End Sub

    ' Pixie says something
    Private Sub PixieSays(msg As String)
        Me.PixieSaysLabel.Text = msg
    End Sub

    ' Start the operation
    Private Sub StartOperation()
        Me.ProgressTimer.Enabled = True
        With Me.WorkerThread
            .RunWorkerAsync()
        End With
    End Sub

    ' Abort the operation
    Private Sub FinishOperation()
        Me.ProgressTimer.Enabled = False
        Me.Close()
        'Me.CopyProgress.Value = 100
        'Me.PixieSays("Wow! All done.")
    End Sub

    ' Abort the operation
    Private Sub AbortOperation()
        With Me.State
            .Cancel = True
        End With
    End Sub

    ' Set percent complete
    Private Sub SetPercentComplete(percent As Integer)
        Dim n As Integer = Math.Max(0, percent)
        Me.State.PercentComplete = Math.Min(100, n)
    End Sub

    ' Update progress bar
    Private Sub UpdateProgressBar()
        Try
            Me.CopyProgress.Value = Me.State.PercentComplete
            DebugOut("PROGRESS: " & Me.State.PercentComplete & "%")
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' File copied callback
    Public Function ReportFileCopied(args As FileOperationThread.HandlerArguments) As Boolean
        With Me.State
            .PercentComplete = args.Progress
            args.Cancel = .Cancel
        End With
        If args.Mode = FileOperationThread.Mode.SourceOnly Then
            DebugOut("SRC: " & args.Source)
        Else
            DebugOut("SRC: " & args.Source)
            DebugOut("DST: " & args.Target)
            If Not NCS.CopyFile(args.Source, args.Target) Then
                Me.State.ReportFailed(args.Source)
            End If
        End If
        ' Give the Form some CPU time
        System.Threading.Thread.Sleep(100)
        Return args.Cancel
    End Function

    ' Form Loaded
    Private Sub CopyProgressForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.Initialize()
        Catch ex As Exception
            SilentExceptionReport(ex)
            InfoBox("The copy progress form did not initialize.")
            Me.Close()
        End Try
    End Sub

    ' Button clicked
    Private Sub AbortButton_Click(sender As Object, e As EventArgs) Handles AbortButton.Click
        Try
            Me.AbortOperation()
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' One shot timer tick
    Private Sub OneShot_Tick(sender As Object, e As EventArgs) Handles OneShot.Tick
        Try
            Me.OneShot.Enabled = False
            Me.StartOperation()
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Progress timer tick
    Private Sub ProgressTimer_Tick(sender As Object, e As EventArgs) Handles ProgressTimer.Tick
        Try
            Me.UpdateProgressBar()
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Do work for the copier thread
    Private Sub WorkerThread_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles WorkerThread.DoWork
        Try
            If Me Is Nothing Then
                DebugOut("CopyProgressForm instance is Nothing.")
                Return
            End If
            If Me.State Is Nothing Then
                DebugOut("CopyProgressForm's State instance is Nothing.")
                Return
            End If
            With Me.State
                .InvokeWorkerThread()
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Copier thread progress changed
    Private Sub WorkerThread_ProgressChanged(sender As Object, e As System.ComponentModel.ProgressChangedEventArgs) Handles WorkerThread.ProgressChanged
        Try
            '
            ' TODO... figure out how thread raises this event
            '
            Me.SetPercentComplete(e.ProgressPercentage)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Copier thread completed
    Private Sub WorkerThread_RunWorkerCompleted(sender As Object, e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles WorkerThread.RunWorkerCompleted
        Try
            Me.FinishOperation()
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

End Class

Public Class Test

    Public Shared Function Invoke() As Boolean
        DebugOut("Hi handsome!")
        Return True
    End Function

End Class
