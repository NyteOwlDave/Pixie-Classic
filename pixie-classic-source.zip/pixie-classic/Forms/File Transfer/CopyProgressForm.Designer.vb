﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CopyProgressForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PixieIcon As System.Windows.Forms.PictureBox
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CopyProgressForm))
        Me.WorkerThread = New System.ComponentModel.BackgroundWorker()
        Me.OneShot = New System.Windows.Forms.Timer(Me.components)
        Me.CopyProgress = New System.Windows.Forms.ProgressBar()
        Me.PixieSaysLabel = New System.Windows.Forms.Label()
        Me.CopyActionButton = New System.Windows.Forms.PictureBox()
        Me.AbortButton = New System.Windows.Forms.PictureBox()
        Me.ProgressTimer = New System.Windows.Forms.Timer(Me.components)
        PixieIcon = New System.Windows.Forms.PictureBox()
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CopyActionButton, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AbortButton, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PixieIcon
        '
        PixieIcon.Image = Global.NCS.My.Resources.Resources.Pixie48
        PixieIcon.Location = New System.Drawing.Point(12, 28)
        PixieIcon.Name = "PixieIcon"
        PixieIcon.Size = New System.Drawing.Size(48, 48)
        PixieIcon.TabIndex = 18
        PixieIcon.TabStop = False
        '
        'WorkerThread
        '
        Me.WorkerThread.WorkerReportsProgress = True
        Me.WorkerThread.WorkerSupportsCancellation = True
        '
        'OneShot
        '
        Me.OneShot.Interval = 500
        '
        'CopyProgress
        '
        Me.CopyProgress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CopyProgress.Location = New System.Drawing.Point(12, 215)
        Me.CopyProgress.Name = "CopyProgress"
        Me.CopyProgress.Size = New System.Drawing.Size(426, 29)
        Me.CopyProgress.Step = 1
        Me.CopyProgress.TabIndex = 0
        '
        'PixieSaysLabel
        '
        Me.PixieSaysLabel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PixieSaysLabel.BackColor = System.Drawing.Color.LightBlue
        Me.PixieSaysLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PixieSaysLabel.Font = New System.Drawing.Font("Candara", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PixieSaysLabel.Location = New System.Drawing.Point(12, 79)
        Me.PixieSaysLabel.Name = "PixieSaysLabel"
        Me.PixieSaysLabel.Size = New System.Drawing.Size(426, 133)
        Me.PixieSaysLabel.TabIndex = 19
        Me.PixieSaysLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CopyActionButton
        '
        Me.CopyActionButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CopyActionButton.BackColor = System.Drawing.Color.Honeydew
        Me.CopyActionButton.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.CopyActionButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CopyActionButton.Location = New System.Drawing.Point(246, 12)
        Me.CopyActionButton.Name = "CopyActionButton"
        Me.CopyActionButton.Size = New System.Drawing.Size(192, 64)
        Me.CopyActionButton.TabIndex = 20
        Me.CopyActionButton.TabStop = False
        '
        'AbortButton
        '
        Me.AbortButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AbortButton.Location = New System.Drawing.Point(175, 12)
        Me.AbortButton.Name = "AbortButton"
        Me.AbortButton.Size = New System.Drawing.Size(64, 64)
        Me.AbortButton.TabIndex = 21
        Me.AbortButton.TabStop = False
        '
        'ProgressTimer
        '
        Me.ProgressTimer.Interval = 300
        '
        'CopyProgressForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CausesValidation = False
        Me.ClientSize = New System.Drawing.Size(450, 256)
        Me.Controls.Add(Me.AbortButton)
        Me.Controls.Add(Me.CopyActionButton)
        Me.Controls.Add(Me.PixieSaysLabel)
        Me.Controls.Add(PixieIcon)
        Me.Controls.Add(Me.CopyProgress)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CopyProgressForm"
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Copying Pictures"
        Me.TopMost = True
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CopyActionButton, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AbortButton, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents WorkerThread As System.ComponentModel.BackgroundWorker
    Friend WithEvents OneShot As System.Windows.Forms.Timer
    Friend WithEvents CopyProgress As System.Windows.Forms.ProgressBar
    Friend WithEvents PixieSaysLabel As System.Windows.Forms.Label
    Friend WithEvents CopyActionButton As System.Windows.Forms.PictureBox
    Friend WithEvents AbortButton As System.Windows.Forms.PictureBox
    Friend WithEvents ProgressTimer As System.Windows.Forms.Timer
End Class
