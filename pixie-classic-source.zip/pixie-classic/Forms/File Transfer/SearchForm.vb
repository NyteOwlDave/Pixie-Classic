﻿
Public Class SearchForm

    ' Operation ID codes
    Public Enum OperationID
        Test
        Import
        Export
    End Enum

    ' Set the operation ID (called from parent/assistant)
    Public Sub SetOperation(id As OperationID)
        With Me.State
            .Operation = id
        End With
    End Sub

    ' Access to located pictures
    Public ReadOnly Property Pictures As StringList
        Get
            Return Me.State.Pictures
        End Get
    End Property

    ' Internal state class
    Private Class InternalState
        Public Operation As OperationID = OperationID.Test
        Public Pictures As New StringList
        Private Device As New DeviceTypeAssistant
        Private Searcher As New SearchAssistant
        Public Function Initialize(frm As SearchForm) As Boolean
            If frm Is Nothing Then
                Return False
            End If
            Device.ShowImage(frm.DeviceIcon)
            Return Me.SearchFolderExists()
        End Function
        Public Function Search(callback As FolderSearcher.Located) As Boolean
            Select Case Me.Operation
                Case OperationID.Export
                    Me.Pictures = Me.Searcher.FindComputerPictures(callback)
                Case OperationID.Import
                    Me.Pictures = Me.Searcher.FindDevicePictures(callback)
                Case OperationID.Test
                    InfoBox("Test mode was invoked.")
            End Select
            Return True
        End Function
        Private Function SearchFolderExists() As Boolean
            Dim st As New PixieFolderState
            Dim folder As String
            Select Case Me.Operation
                Case OperationID.Export
                    folder = st.ImportFolder
                Case OperationID.Import
                    folder = st.DeviceFolder
                Case Else
                    folder = Me.GetTestFolder()
            End Select
            Return FolderExists(folder)
        End Function
        Private Function GetTestFolder()
            Return "V:\Assets"
        End Function
    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Initialization
    Private Sub Initialize()
        Me.PixieSays("Okay! I'm looking for pictures right now. Please don't remove the device until I'm done.")
        If Me.State.Initialize(Me) Then
            Me.PictureList.Items.Clear()
            ' Me.UseWaitCursor = True
            Me.OneShot.Interval = 2000
            Me.OneShot.Enabled = True
            Return
        End If
        Throw New Exception("Internal state did not initialize.")
    End Sub

    ' Pixie says something
    Private Sub PixieSays(msg As String)
        Me.PixieSaysLabel.Text = msg
    End Sub

    ' Add a picture to the list
    Private Sub AddPictureToList(name As String)
        Try
            With Me.PictureList
                If .SmallImageList Is Nothing Then
                    Me.PictureList.Items.Add(name)
                Else
                    Me.PictureList.Items.Add(name, 0)
                End If
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Located picture callback
    Private Function LocatedPictureCallback(name As String) As Boolean
        Try
            Me.AddPictureToList(name)
            Return True
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Form loaded
    Private Sub ImportForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.Initialize()
        Catch ex As Exception
            SilentExceptionReport(ex)
            InfoBox("The search form did not initialize.")
            Me.Close()
        End Try
    End Sub

    ' Search for pictures
    Private Sub OneShot_Tick(sender As Object, e As EventArgs) Handles OneShot.Tick
        Try
            Me.OneShot.Enabled = False
            ' Me.UseWaitCursor = False
            If Me.State.Search(AddressOf Me.LocatedPictureCallback) Then
                Dim count As Integer = Me.Pictures.Count
                If count < 1 Then
                    Me.PixieSays("I didn't find any pictures on this device. Sorry about that!")
                    Return
                Else
                    Dim msg As String
                    If count > 1 Then
                        msg = "I found " & count & " pictures."
                    Else
                        msg = "I found 1 picture."
                    End If
                    msg = msg & " Close this window when you're ready for me to copy them."
                    msg = msg & " Or you can double-click one to preview it."
                    Me.PixieSays(msg)
                    Return
                End If
            End If
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' List item double-clicked
    Private Sub PictureList_DoubleClick(sender As Object, e As EventArgs) Handles PictureList.DoubleClick
        Try
            With Me.PictureList
                If .SelectedItems.Count > 0 Then
                    Dim location As String = .SelectedItems(0).Text
                    ShellOpen(location)
                End If
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

End Class