﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SearchForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PixieIcon As System.Windows.Forms.PictureBox
        Dim ListPanel As System.Windows.Forms.Panel
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SearchForm))
        Me.PictureList = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PixieSaysLabel = New System.Windows.Forms.Label()
        Me.DeviceIcon = New System.Windows.Forms.PictureBox()
        Me.OneShot = New System.Windows.Forms.Timer(Me.components)
        PixieIcon = New System.Windows.Forms.PictureBox()
        ListPanel = New System.Windows.Forms.Panel()
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        ListPanel.SuspendLayout()
        CType(Me.DeviceIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PixieIcon
        '
        PixieIcon.Image = Global.NCS.My.Resources.Resources.Pixie48
        PixieIcon.Location = New System.Drawing.Point(12, 12)
        PixieIcon.Name = "PixieIcon"
        PixieIcon.Size = New System.Drawing.Size(48, 48)
        PixieIcon.TabIndex = 17
        PixieIcon.TabStop = False
        '
        'ListPanel
        '
        ListPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        ListPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        ListPanel.Controls.Add(Me.PictureList)
        ListPanel.Location = New System.Drawing.Point(66, 131)
        ListPanel.Name = "ListPanel"
        ListPanel.Size = New System.Drawing.Size(399, 193)
        ListPanel.TabIndex = 21
        '
        'PictureList
        '
        Me.PictureList.AutoArrange = False
        Me.PictureList.BackColor = System.Drawing.Color.Honeydew
        Me.PictureList.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.PictureList.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.PictureList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureList.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.PictureList.FullRowSelect = True
        Me.PictureList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.PictureList.LabelWrap = False
        Me.PictureList.Location = New System.Drawing.Point(0, 0)
        Me.PictureList.MultiSelect = False
        Me.PictureList.Name = "PictureList"
        Me.PictureList.ShowGroups = False
        Me.PictureList.Size = New System.Drawing.Size(395, 189)
        Me.PictureList.TabIndex = 19
        Me.PictureList.UseCompatibleStateImageBehavior = False
        Me.PictureList.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Pictures"
        Me.ColumnHeader1.Width = 367
        '
        'PixieSaysLabel
        '
        Me.PixieSaysLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PixieSaysLabel.BackColor = System.Drawing.Color.LightBlue
        Me.PixieSaysLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PixieSaysLabel.Font = New System.Drawing.Font("Candara", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PixieSaysLabel.Location = New System.Drawing.Point(66, 12)
        Me.PixieSaysLabel.Name = "PixieSaysLabel"
        Me.PixieSaysLabel.Size = New System.Drawing.Size(399, 116)
        Me.PixieSaysLabel.TabIndex = 18
        Me.PixieSaysLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DeviceIcon
        '
        Me.DeviceIcon.Location = New System.Drawing.Point(12, 131)
        Me.DeviceIcon.Name = "DeviceIcon"
        Me.DeviceIcon.Size = New System.Drawing.Size(48, 48)
        Me.DeviceIcon.TabIndex = 20
        Me.DeviceIcon.TabStop = False
        '
        'OneShot
        '
        Me.OneShot.Interval = 250
        '
        'ImportForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(477, 336)
        Me.Controls.Add(ListPanel)
        Me.Controls.Add(Me.DeviceIcon)
        Me.Controls.Add(Me.PixieSaysLabel)
        Me.Controls.Add(PixieIcon)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ImportForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Locating Pictures"
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).EndInit()
        ListPanel.ResumeLayout(False)
        CType(Me.DeviceIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PixieSaysLabel As System.Windows.Forms.Label
    Friend WithEvents PictureList As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents DeviceIcon As System.Windows.Forms.PictureBox
    Friend WithEvents OneShot As System.Windows.Forms.Timer
End Class
