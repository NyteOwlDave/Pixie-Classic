﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ActionGroup As System.Windows.Forms.GroupBox
        Dim DeviceTypeGroup As System.Windows.Forms.GroupBox
        Dim ComputerTypeGroup As System.Windows.Forms.GroupBox
        Dim HelpGroup As System.Windows.Forms.GroupBox
        Dim HelpCaptionLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.ExportActionButton = New System.Windows.Forms.PictureBox()
        Me.ImportActionButton = New System.Windows.Forms.PictureBox()
        Me.DeviceTypeButton = New System.Windows.Forms.PictureBox()
        Me.ComputerTypeButton = New System.Windows.Forms.PictureBox()
        Me.PixieSaysLabel = New System.Windows.Forms.Label()
        Me.PixieButton = New System.Windows.Forms.PictureBox()
        ActionGroup = New System.Windows.Forms.GroupBox()
        DeviceTypeGroup = New System.Windows.Forms.GroupBox()
        ComputerTypeGroup = New System.Windows.Forms.GroupBox()
        HelpGroup = New System.Windows.Forms.GroupBox()
        HelpCaptionLabel = New System.Windows.Forms.Label()
        ActionGroup.SuspendLayout()
        CType(Me.ExportActionButton, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ImportActionButton, System.ComponentModel.ISupportInitialize).BeginInit()
        DeviceTypeGroup.SuspendLayout()
        CType(Me.DeviceTypeButton, System.ComponentModel.ISupportInitialize).BeginInit()
        ComputerTypeGroup.SuspendLayout()
        CType(Me.ComputerTypeButton, System.ComponentModel.ISupportInitialize).BeginInit()
        HelpGroup.SuspendLayout()
        CType(Me.PixieButton, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ActionGroup
        '
        ActionGroup.Controls.Add(Me.ExportActionButton)
        ActionGroup.Controls.Add(Me.ImportActionButton)
        ActionGroup.Location = New System.Drawing.Point(12, 12)
        ActionGroup.Name = "ActionGroup"
        ActionGroup.Size = New System.Drawing.Size(205, 161)
        ActionGroup.TabIndex = 0
        ActionGroup.TabStop = False
        ActionGroup.Text = "Action"
        '
        'ExportActionButton
        '
        Me.ExportActionButton.BackColor = System.Drawing.Color.Honeydew
        Me.ExportActionButton.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ExportActionButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ExportActionButton.Location = New System.Drawing.Point(6, 89)
        Me.ExportActionButton.Name = "ExportActionButton"
        Me.ExportActionButton.Size = New System.Drawing.Size(192, 64)
        Me.ExportActionButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ExportActionButton.TabIndex = 1
        Me.ExportActionButton.TabStop = False
        '
        'ImportActionButton
        '
        Me.ImportActionButton.BackColor = System.Drawing.Color.Honeydew
        Me.ImportActionButton.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ImportActionButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ImportActionButton.Location = New System.Drawing.Point(6, 19)
        Me.ImportActionButton.Name = "ImportActionButton"
        Me.ImportActionButton.Size = New System.Drawing.Size(192, 64)
        Me.ImportActionButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ImportActionButton.TabIndex = 0
        Me.ImportActionButton.TabStop = False
        '
        'DeviceTypeGroup
        '
        DeviceTypeGroup.Controls.Add(Me.DeviceTypeButton)
        DeviceTypeGroup.Location = New System.Drawing.Point(12, 179)
        DeviceTypeGroup.Name = "DeviceTypeGroup"
        DeviceTypeGroup.Size = New System.Drawing.Size(95, 93)
        DeviceTypeGroup.TabIndex = 1
        DeviceTypeGroup.TabStop = False
        DeviceTypeGroup.Text = "Device Type"
        '
        'DeviceTypeButton
        '
        Me.DeviceTypeButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DeviceTypeButton.Location = New System.Drawing.Point(15, 19)
        Me.DeviceTypeButton.Name = "DeviceTypeButton"
        Me.DeviceTypeButton.Size = New System.Drawing.Size(64, 64)
        Me.DeviceTypeButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.DeviceTypeButton.TabIndex = 0
        Me.DeviceTypeButton.TabStop = False
        '
        'ComputerTypeGroup
        '
        ComputerTypeGroup.Controls.Add(Me.ComputerTypeButton)
        ComputerTypeGroup.Location = New System.Drawing.Point(115, 179)
        ComputerTypeGroup.Name = "ComputerTypeGroup"
        ComputerTypeGroup.Size = New System.Drawing.Size(95, 93)
        ComputerTypeGroup.TabIndex = 2
        ComputerTypeGroup.TabStop = False
        ComputerTypeGroup.Text = "Computer Type"
        '
        'ComputerTypeButton
        '
        Me.ComputerTypeButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComputerTypeButton.Location = New System.Drawing.Point(15, 19)
        Me.ComputerTypeButton.Name = "ComputerTypeButton"
        Me.ComputerTypeButton.Size = New System.Drawing.Size(64, 64)
        Me.ComputerTypeButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ComputerTypeButton.TabIndex = 0
        Me.ComputerTypeButton.TabStop = False
        '
        'HelpGroup
        '
        HelpGroup.Controls.Add(HelpCaptionLabel)
        HelpGroup.Controls.Add(Me.PixieSaysLabel)
        HelpGroup.Controls.Add(Me.PixieButton)
        HelpGroup.Location = New System.Drawing.Point(223, 12)
        HelpGroup.Name = "HelpGroup"
        HelpGroup.Size = New System.Drawing.Size(235, 260)
        HelpGroup.TabIndex = 3
        HelpGroup.TabStop = False
        HelpGroup.Text = "Help"
        '
        'HelpCaptionLabel
        '
        HelpCaptionLabel.Font = New System.Drawing.Font("Georgia", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        HelpCaptionLabel.Location = New System.Drawing.Point(69, 19)
        HelpCaptionLabel.Name = "HelpCaptionLabel"
        HelpCaptionLabel.Size = New System.Drawing.Size(154, 48)
        HelpCaptionLabel.TabIndex = 2
        HelpCaptionLabel.Text = "Your pixie says:"
        HelpCaptionLabel.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'PixieSaysLabel
        '
        Me.PixieSaysLabel.BackColor = System.Drawing.Color.LightBlue
        Me.PixieSaysLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PixieSaysLabel.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PixieSaysLabel.Location = New System.Drawing.Point(12, 70)
        Me.PixieSaysLabel.Name = "PixieSaysLabel"
        Me.PixieSaysLabel.Size = New System.Drawing.Size(211, 180)
        Me.PixieSaysLabel.TabIndex = 1
        Me.PixieSaysLabel.Text = "Point to something and I'll tell you what it does."
        Me.PixieSaysLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PixieButton
        '
        Me.PixieButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieButton.Image = Global.NCS.My.Resources.Resources.Pixie48
        Me.PixieButton.Location = New System.Drawing.Point(15, 19)
        Me.PixieButton.Name = "PixieButton"
        Me.PixieButton.Size = New System.Drawing.Size(48, 48)
        Me.PixieButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PixieButton.TabIndex = 0
        Me.PixieButton.TabStop = False
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CausesValidation = False
        Me.ClientSize = New System.Drawing.Size(473, 286)
        Me.Controls.Add(HelpGroup)
        Me.Controls.Add(ComputerTypeGroup)
        Me.Controls.Add(DeviceTypeGroup)
        Me.Controls.Add(ActionGroup)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pixie"
        ActionGroup.ResumeLayout(False)
        CType(Me.ExportActionButton, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ImportActionButton, System.ComponentModel.ISupportInitialize).EndInit()
        DeviceTypeGroup.ResumeLayout(False)
        CType(Me.DeviceTypeButton, System.ComponentModel.ISupportInitialize).EndInit()
        ComputerTypeGroup.ResumeLayout(False)
        CType(Me.ComputerTypeButton, System.ComponentModel.ISupportInitialize).EndInit()
        HelpGroup.ResumeLayout(False)
        CType(Me.PixieButton, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ExportActionButton As System.Windows.Forms.PictureBox
    Friend WithEvents ImportActionButton As System.Windows.Forms.PictureBox
    Friend WithEvents DeviceTypeButton As System.Windows.Forms.PictureBox
    Friend WithEvents ComputerTypeButton As System.Windows.Forms.PictureBox
    Friend WithEvents PixieSaysLabel As System.Windows.Forms.Label
    Friend WithEvents PixieButton As System.Windows.Forms.PictureBox

End Class
