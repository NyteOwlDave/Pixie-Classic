﻿
Public Class MainForm

    ' Internal class for assistants
    Private Class Assistants
        Public PixieSays As New PixieSaysAssistant
        Public Import As New ImportAssistant
        Public Export As New ExportAssistant
        Public Computer As New ComputerTypeAssistant
        Public Device As New DeviceTypeAssistant
    End Class

    ' Button ID codes
    Public Enum ButtonID
        Undefined
        Preview
        Import
        Export
        Computer
        Device
    End Enum

    ' Internal dispatch class
    Private Class Dispatcher
        Private Assistants As New Assistants
        Private Form As MainForm = Nothing
        Public Function Initialize(frm As MainForm) As Boolean
            Me.Form = frm
            If Me.Initialized Then
                Me.Assistants.PixieSays.Initialize(frm.PixieSaysLabel)
                Me.ShowImages()
                Return True
            Else
                Return False
            End If
        End Function
        Public ReadOnly Property Initialized As Boolean
            Get
                If Me.Form IsNot Nothing Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property
        Public Function Execute(id As ButtonID) As Boolean
            If Not Me.Initialized Then Return False
            Select Case id
                Case ButtonID.Computer : Me.InvokeComputerAssistant()
                Case ButtonID.Device : Me.InvokeDeviceAssistant()
                Case ButtonID.Export : Me.InvokeExportAssistant()
                Case ButtonID.Import : Me.InvokeImportAssistant()
                Case ButtonID.Preview : Me.InvokePreviewAssistant()
            End Select
            Return True
        End Function
        Public Sub ShowHelp(id As ButtonID)
            If Not Me.Initialized Then Return
            With Me.Assistants.PixieSays
                .SayHelp(id)
            End With
        End Sub
        Private Sub ShowImportImage()
            If Not Me.Initialized Then Return
            Me.Assistants.Import.ShowImage(Me.Form.ImportActionButton)
        End Sub
        Private Sub ShowExportImage()
            If Not Me.Initialized Then Return
            Me.Assistants.Export.ShowImage(Me.Form.ExportActionButton)
        End Sub
        Private Sub ShowComputerImage()
            If Not Me.Initialized Then Return
            Me.Assistants.Computer.ShowImage(Me.Form.ComputerTypeButton)
        End Sub
        Private Sub ShowDeviceImage()
            If Not Me.Initialized Then Return
            Me.Assistants.Device.ShowImage(Me.Form.DeviceTypeButton)
        End Sub
        Private Sub ShowImages()
            Me.ShowComputerImage()
            Me.ShowDeviceImage()
            Me.ShowExportImage()
            Me.ShowImportImage()
        End Sub
        Private Sub InvokeComputerAssistant()
            With Me.Assistants.Computer
                If .Invoke(.CurrentTypeID) Then
                    Me.ShowComputerImage()
                    Me.ShowExportImage()
                    Me.ShowImportImage()
                End If
            End With
        End Sub
        Private Sub InvokeDeviceAssistant()
            With Me.Assistants.Device
                If .Invoke(.CurrentTypeID) Then
                    Me.ShowDeviceImage()
                    Me.ShowExportImage()
                    Me.ShowImportImage()
                End If
            End With
        End Sub
        Private Sub InvokeExportAssistant()
            With Me.Assistants.Export
                .Invoke()
            End With
        End Sub
        Private Sub InvokeImportAssistant()
            With Me.Assistants.Import
                .Invoke()
            End With
        End Sub
        Private Sub InvokePreviewAssistant()
            My.Forms.PreviewForm.ShowDialog()
        End Sub
    End Class

    ' Internal dispatch instance
    Private Dispatch As New Dispatcher

    ' Initialization
    Private Sub Initialize()
        If Me.Dispatch.Initialize(Me) Then
            Return
        End If
        Throw New Exception("Failed to initialize command dispatcher.")
    End Sub

    ' Form loaded
    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.Initialize()
        Catch ex As Exception
            SilentExceptionReport(ex)
            InfoBox("The main form did not initialize.")
            Me.Close()
        End Try
    End Sub

    ' Button clicked
    Private Sub ImportActionButton_Click(sender As Object, e As EventArgs) Handles ImportActionButton.Click
        Try
            With Me.Dispatch
                .Execute(ButtonID.Import)
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Button clicked
    Private Sub ExportActionButton_Click(sender As Object, e As EventArgs) Handles ExportActionButton.Click
        Try
            With Me.Dispatch
                .Execute(ButtonID.Export)
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Button clicked
    Private Sub DeviceTypeButton_Click(sender As Object, e As EventArgs) Handles DeviceTypeButton.Click
        Try
            With Me.Dispatch
                .Execute(ButtonID.Device)
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Button clicked
    Private Sub ComputerTypeButton_Click(sender As Object, e As EventArgs) Handles ComputerTypeButton.Click
        Try
            With Me.Dispatch
                .Execute(ButtonID.Computer)
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Button clicked
    Private Sub PixieButton_Click(sender As Object, e As EventArgs) Handles PixieButton.Click
        Try
            With Me.Dispatch
                .Execute(ButtonID.Preview)
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Mouse entered any button
    Private Sub AnyButton_MouseEnter(sender As Object, e As EventArgs) _
        Handles ComputerTypeButton.MouseEnter, DeviceTypeButton.MouseEnter, _
        ExportActionButton.MouseEnter, ImportActionButton.MouseEnter, _
        PixieButton.MouseEnter

        Try

            Dim id As ButtonID = ButtonID.Undefined

            If sender Is Me.ComputerTypeButton Then
                id = ButtonID.Computer
            ElseIf sender Is Me.DeviceTypeButton Then
                id = ButtonID.Device
            ElseIf sender Is Me.ExportActionButton Then
                id = ButtonID.Export
            ElseIf sender Is Me.ImportActionButton Then
                id = ButtonID.Import
            ElseIf sender Is Me.PixieButton Then
                id = ButtonID.Preview
            End If

            With Me.Dispatch
                .ShowHelp(id)
            End With

        Catch ex As Exception

            SilentExceptionReport(ex)

        End Try

    End Sub

    ' Mouse left any button
    Private Sub AnyButton_MouseLeave(sender As Object, e As EventArgs) _
        Handles ComputerTypeButton.MouseLeave, DeviceTypeButton.MouseLeave, _
        ExportActionButton.MouseLeave, ImportActionButton.MouseLeave, _
        PixieButton.MouseLeave

        Try

            Dim id As ButtonID = ButtonID.Undefined

            With Me.Dispatch
                .ShowHelp(id)
            End With

        Catch ex As Exception

            SilentExceptionReport(ex)

        End Try

    End Sub

End Class

