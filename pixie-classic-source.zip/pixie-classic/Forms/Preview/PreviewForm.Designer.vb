﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PreviewForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DescriptionLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PreviewForm))
        Me.PixieIcon = New System.Windows.Forms.PictureBox()
        Me.DesktopIcon = New System.Windows.Forms.PictureBox()
        Me.LaptopIcon = New System.Windows.Forms.PictureBox()
        Me.FlashDriveIcon = New System.Windows.Forms.PictureBox()
        Me.SDCardIcon = New System.Windows.Forms.PictureBox()
        DescriptionLabel = New System.Windows.Forms.Label()
        CType(Me.PixieIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DesktopIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LaptopIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FlashDriveIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SDCardIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PixieIcon
        '
        Me.PixieIcon.BackColor = System.Drawing.Color.LightBlue
        Me.PixieIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PixieIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieIcon.Image = Global.NCS.My.Resources.Resources.Pixie64
        Me.PixieIcon.Location = New System.Drawing.Point(12, 12)
        Me.PixieIcon.Name = "PixieIcon"
        Me.PixieIcon.Size = New System.Drawing.Size(64, 64)
        Me.PixieIcon.TabIndex = 0
        Me.PixieIcon.TabStop = False
        '
        'DescriptionLabel
        '
        DescriptionLabel.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DescriptionLabel.Location = New System.Drawing.Point(60, 79)
        DescriptionLabel.Name = "DescriptionLabel"
        DescriptionLabel.Size = New System.Drawing.Size(256, 63)
        DescriptionLabel.TabIndex = 5
        DescriptionLabel.Text = "Click an icon to preview the full size art."
        DescriptionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DesktopIcon
        '
        Me.DesktopIcon.BackColor = System.Drawing.Color.LightBlue
        Me.DesktopIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DesktopIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DesktopIcon.Image = Global.NCS.My.Resources.Resources.Desktop64
        Me.DesktopIcon.Location = New System.Drawing.Point(82, 12)
        Me.DesktopIcon.Name = "DesktopIcon"
        Me.DesktopIcon.Size = New System.Drawing.Size(64, 64)
        Me.DesktopIcon.TabIndex = 6
        Me.DesktopIcon.TabStop = False
        '
        'LaptopIcon
        '
        Me.LaptopIcon.BackColor = System.Drawing.Color.LightBlue
        Me.LaptopIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LaptopIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LaptopIcon.Image = Global.NCS.My.Resources.Resources.Laptop64
        Me.LaptopIcon.Location = New System.Drawing.Point(152, 12)
        Me.LaptopIcon.Name = "LaptopIcon"
        Me.LaptopIcon.Size = New System.Drawing.Size(64, 64)
        Me.LaptopIcon.TabIndex = 7
        Me.LaptopIcon.TabStop = False
        '
        'FlashDriveIcon
        '
        Me.FlashDriveIcon.BackColor = System.Drawing.Color.LightBlue
        Me.FlashDriveIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.FlashDriveIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlashDriveIcon.Image = Global.NCS.My.Resources.Resources.FlashDrive64
        Me.FlashDriveIcon.Location = New System.Drawing.Point(222, 12)
        Me.FlashDriveIcon.Name = "FlashDriveIcon"
        Me.FlashDriveIcon.Size = New System.Drawing.Size(64, 64)
        Me.FlashDriveIcon.TabIndex = 8
        Me.FlashDriveIcon.TabStop = False
        '
        'SDCardIcon
        '
        Me.SDCardIcon.BackColor = System.Drawing.Color.LightBlue
        Me.SDCardIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SDCardIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SDCardIcon.Image = Global.NCS.My.Resources.Resources.SDCard64
        Me.SDCardIcon.Location = New System.Drawing.Point(292, 12)
        Me.SDCardIcon.Name = "SDCardIcon"
        Me.SDCardIcon.Size = New System.Drawing.Size(64, 64)
        Me.SDCardIcon.TabIndex = 9
        Me.SDCardIcon.TabStop = False
        '
        'PreviewForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(368, 146)
        Me.Controls.Add(Me.SDCardIcon)
        Me.Controls.Add(Me.FlashDriveIcon)
        Me.Controls.Add(Me.LaptopIcon)
        Me.Controls.Add(Me.DesktopIcon)
        Me.Controls.Add(DescriptionLabel)
        Me.Controls.Add(Me.PixieIcon)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "PreviewForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Preview Art"
        CType(Me.PixieIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DesktopIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LaptopIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FlashDriveIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SDCardIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PixieIcon As System.Windows.Forms.PictureBox
    Friend WithEvents DesktopIcon As System.Windows.Forms.PictureBox
    Friend WithEvents LaptopIcon As System.Windows.Forms.PictureBox
    Friend WithEvents FlashDriveIcon As System.Windows.Forms.PictureBox
    Friend WithEvents SDCardIcon As System.Windows.Forms.PictureBox
End Class
