﻿
Public Class PreviewForm

    ' Initialization
    Private Sub Initialize()
    End Sub

    ' Preview specified art
    Private Sub PreviewArt(id As PreviewAssistant.ImageID)
        Dim assist As New PreviewAssistant
        assist.Invoke(id)
    End Sub

    ' Form loaded
    Private Sub PreviewForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.Initialize()
        Catch ex As Exception
            SilentExceptionReport(ex)
            InfoBox("The Art Preview form did not initialize.")
            Me.Close()
        End Try
    End Sub

    ' Icon clicked
    Private Sub Pixie_Click(sender As Object, e As EventArgs) Handles PixieIcon.Click
        Try
            Me.PreviewArt(PreviewAssistant.ImageID.Pixie)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Icon clicked
    Private Sub Desktop_Click(sender As Object, e As EventArgs) Handles DesktopIcon.Click
        Try
            Me.PreviewArt(PreviewAssistant.ImageID.Desktop)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Icon clicked
    Private Sub Laptop_Click(sender As Object, e As EventArgs) Handles LaptopIcon.Click
        Try
            Me.PreviewArt(PreviewAssistant.ImageID.Laptop)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Icon clicked
    Private Sub FlashDrive_Click(sender As Object, e As EventArgs) Handles FlashDriveIcon.Click
        Try
            Me.PreviewArt(PreviewAssistant.ImageID.FlashDrive)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Icon clicked
    Private Sub SDCard_Click(sender As Object, e As EventArgs) Handles SDCardIcon.Click
        Try
            Me.PreviewArt(PreviewAssistant.ImageID.SDCard)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

End Class

