﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ChooseFolderForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PixieIcon As System.Windows.Forms.PictureBox
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ChooseFolderForm))
        Me.PixieSaysLabel = New System.Windows.Forms.Label()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.ExploreButton = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        PixieIcon = New System.Windows.Forms.PictureBox()
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PixieIcon
        '
        PixieIcon.Image = Global.NCS.My.Resources.Resources.Pixie48
        PixieIcon.Location = New System.Drawing.Point(13, 13)
        PixieIcon.Margin = New System.Windows.Forms.Padding(4)
        PixieIcon.Name = "PixieIcon"
        PixieIcon.Size = New System.Drawing.Size(64, 59)
        PixieIcon.TabIndex = 17
        PixieIcon.TabStop = False
        '
        'PixieSaysLabel
        '
        Me.PixieSaysLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PixieSaysLabel.BackColor = System.Drawing.Color.LightBlue
        Me.PixieSaysLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PixieSaysLabel.Font = New System.Drawing.Font("Candara", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PixieSaysLabel.Location = New System.Drawing.Point(85, 13)
        Me.PixieSaysLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PixieSaysLabel.Name = "PixieSaysLabel"
        Me.PixieSaysLabel.Size = New System.Drawing.Size(373, 101)
        Me.PixieSaysLabel.TabIndex = 18
        Me.PixieSaysLabel.Text = "Select the folder that contains the pictures you want to copy."
        Me.PixieSaysLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TreeView1
        '
        Me.TreeView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TreeView1.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView1.ImageIndex = 0
        Me.TreeView1.ImageList = Me.ImageList1
        Me.TreeView1.Location = New System.Drawing.Point(85, 117)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.SelectedImageIndex = 0
        Me.TreeView1.ShowLines = False
        Me.TreeView1.ShowPlusMinus = False
        Me.TreeView1.ShowRootLines = False
        Me.TreeView1.Size = New System.Drawing.Size(373, 206)
        Me.TreeView1.TabIndex = 19
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OK_Button.Location = New System.Drawing.Point(282, 329)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(75, 38)
        Me.OK_Button.TabIndex = 20
        Me.OK_Button.Text = "OK"
        Me.OK_Button.UseVisualStyleBackColor = True
        '
        'ExploreButton
        '
        Me.ExploreButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExploreButton.Location = New System.Drawing.Point(363, 329)
        Me.ExploreButton.Name = "ExploreButton"
        Me.ExploreButton.Size = New System.Drawing.Size(95, 38)
        Me.ExploreButton.TabIndex = 21
        Me.ExploreButton.Text = "Explore"
        Me.ExploreButton.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "Folder")
        Me.ImageList1.Images.SetKeyName(1, "Drive")
        '
        'ChooseFolderForm
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(471, 377)
        Me.Controls.Add(Me.ExploreButton)
        Me.Controls.Add(Me.OK_Button)
        Me.Controls.Add(Me.TreeView1)
        Me.Controls.Add(Me.PixieSaysLabel)
        Me.Controls.Add(PixieIcon)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(372, 370)
        Me.Name = "ChooseFolderForm"
        Me.Text = "Choose Folder"
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PixieSaysLabel As Label
    Friend WithEvents TreeView1 As TreeView
    Friend WithEvents OK_Button As Button
    Friend WithEvents ExploreButton As Button
    Friend WithEvents ImageList1 As ImageList
End Class
