﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DetectDeviceForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PixieIcon As System.Windows.Forms.PictureBox
        Me.PixieSaysLabel = New System.Windows.Forms.Label()
        Me.DeviceIcon = New System.Windows.Forms.PictureBox()
        Me.DetectTimer = New System.Windows.Forms.Timer(Me.components)
        PixieIcon = New System.Windows.Forms.PictureBox()
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DeviceIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PixieIcon
        '
        PixieIcon.Image = Global.NCS.My.Resources.Resources.Pixie48
        PixieIcon.Location = New System.Drawing.Point(12, 44)
        PixieIcon.Name = "PixieIcon"
        PixieIcon.Size = New System.Drawing.Size(48, 48)
        PixieIcon.TabIndex = 16
        PixieIcon.TabStop = False
        '
        'PixieSaysLabel
        '
        Me.PixieSaysLabel.BackColor = System.Drawing.Color.LightBlue
        Me.PixieSaysLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PixieSaysLabel.Font = New System.Drawing.Font("Candara", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PixieSaysLabel.Location = New System.Drawing.Point(12, 95)
        Me.PixieSaysLabel.Name = "PixieSaysLabel"
        Me.PixieSaysLabel.Size = New System.Drawing.Size(285, 116)
        Me.PixieSaysLabel.TabIndex = 17
        Me.PixieSaysLabel.Text = "Insert your device now. If your device is already in the computer remove it and r" & _
    "einsert it so I can see which one you wish to use."
        Me.PixieSaysLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'DeviceIcon
        '
        Me.DeviceIcon.BackColor = System.Drawing.SystemColors.Control
        Me.DeviceIcon.Cursor = System.Windows.Forms.Cursors.Default
        Me.DeviceIcon.Location = New System.Drawing.Point(217, 12)
        Me.DeviceIcon.Name = "DeviceIcon"
        Me.DeviceIcon.Size = New System.Drawing.Size(80, 80)
        Me.DeviceIcon.TabIndex = 13
        Me.DeviceIcon.TabStop = False
        '
        'DetectTimer
        '
        Me.DetectTimer.Interval = 1000
        '
        'DetectDeviceForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(310, 226)
        Me.Controls.Add(Me.PixieSaysLabel)
        Me.Controls.Add(PixieIcon)
        Me.Controls.Add(Me.DeviceIcon)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DetectDeviceForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Insert Device"
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DeviceIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DeviceIcon As System.Windows.Forms.PictureBox
    Friend WithEvents DetectTimer As System.Windows.Forms.Timer
    Friend WithEvents PixieSaysLabel As System.Windows.Forms.Label
End Class
