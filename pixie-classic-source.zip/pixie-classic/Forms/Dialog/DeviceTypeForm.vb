﻿
Public Class DeviceTypeForm

    ' Initialization
    Private Sub Initialize()
    End Sub

    ' Accept type and close form
    Public Sub TypeAccepted(id As DeviceTypeAssistant.DeviceTypeID)
        Dim assist As New DeviceTypeAssistant
        assist.CurrentTypeID = id
        DebugOut("Device type: " & id.ToString)
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    ' Form loaded
    Private Sub DeviceTypeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.Initialize()
        Catch ex As Exception
            SilentExceptionReport(ex)
            InfoBox("The device type form did not initialize.")
            Me.Close()
        End Try
    End Sub

    ' Icon clicked
    Private Sub FlashDriveIcon_Click(sender As Object, e As EventArgs) Handles FlashDriveIcon.Click
        Try
            Me.TypeAccepted(DeviceTypeAssistant.DeviceTypeID.FlashDrive)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Icon clicked
    Private Sub SDCardIcon_Click(sender As Object, e As EventArgs) Handles SDCardIcon.Click
        Try
            Me.TypeAccepted(DeviceTypeAssistant.DeviceTypeID.SDCard)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

End Class

