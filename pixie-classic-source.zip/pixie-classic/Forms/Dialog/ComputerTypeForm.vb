﻿
Public Class ComputerTypeForm

    ' Initialization
    Private Sub Initialize()
    End Sub

    ' Accept type and close form
    Public Sub TypeAccepted(id As ComputerTypeAssistant.ComputerTypeID)
        Dim assist As New ComputerTypeAssistant
        assist.CurrentTypeID = id
        DebugOut("Computer type: " & id.ToString)
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    ' Form loaded
    Private Sub ComputerTypeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.Initialize()
        Catch ex As Exception
            SilentExceptionReport(ex)
            InfoBox("The computer type form did not initialize.")
            Me.Close()
        End Try
    End Sub

    ' Icon clicked
    Private Sub LaptopIcon_Click(sender As Object, e As EventArgs) Handles LaptopIcon.Click
        Try
            Me.TypeAccepted(ComputerTypeAssistant.ComputerTypeID.Laptop)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Icon clicked
    Private Sub DesktopIcon_Click(sender As Object, e As EventArgs) Handles DesktopIcon.Click
        Try
            Me.TypeAccepted(ComputerTypeAssistant.ComputerTypeID.Desktop)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

End Class

