﻿
Public Class DetectDeviceForm

    ' Device that was detected
    Public ReadOnly Property DetectedDevice As IO.DriveInfo
        Get
            Return Me.State.Device
        End Get
    End Property

    ' Internal state class
    Private Class InternalState
        Public Device As IO.DriveInfo = Nothing
        Public Detector As New RemovableDeviceDetector
        Public Function Initialize(deviceIcon As Windows.Forms.PictureBox) As Boolean
            Me.Device = Nothing
            If deviceIcon Is Nothing Then
                Return False
            End If
            Me.ShowDeviceIcon(deviceIcon)
            Me.Detector.Initialize()
            Return True
        End Function
        Private Sub ShowDeviceIcon(deviceIcon As Windows.Forms.PictureBox)
            Dim assist As New DeviceTypeAssistant
            assist.ShowImage(deviceIcon)
        End Sub
    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Initialization
    Private Sub Initialize()
        If Me.State.Initialize(Me.DeviceIcon) Then
            Me.PixieSays(My.Settings.HelpMsgInsertDevice)
            Me.DetectTimer.Enabled = True
            Return
        End If
        Throw New Exception("Internal state did not initialize.")
    End Sub

    ' Device was detected
    Private Sub AcceptDevice(device As IO.DriveInfo)
        Me.State.Device = device
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    ' Show message from Pixie
    Private Sub PixieSays(msg As String)
        Me.PixieSaysLabel.Text = msg
    End Sub

    ' Form loaded
    Private Sub DetectDeviceForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.Initialize()
        Catch ex As Exception
            SilentExceptionReport(ex)
            InfoBox("The insert device form did not initialize.")
            Me.Close()
        End Try
    End Sub

    ' Timer tick
    Private Sub DetectTimer_Tick(sender As Object, e As EventArgs) Handles DetectTimer.Tick
        Try
            With Me.State.Detector
                .DetectDrives()
                If .CountChanged Then
                    If .CountDecreased Then
                        Me.PixieSays("Cool! Now insert the device again.")
                        Return
                    Else
                        Me.PixieSays("Okay... I'm working on it now!")
                        Me.DetectTimer.Enabled = False
                        System.Threading.Thread.Sleep(100)
                        Me.AcceptDevice(.GetDetectedDevice())
                    End If
                End If
            End With
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

End Class

