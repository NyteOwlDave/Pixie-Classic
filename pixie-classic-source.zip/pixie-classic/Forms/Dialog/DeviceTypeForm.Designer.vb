﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DeviceTypeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DescriptionLabel As System.Windows.Forms.Label
        Dim PixieIcon As System.Windows.Forms.PictureBox
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DeviceTypeForm))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SDCardIcon = New System.Windows.Forms.PictureBox()
        Me.FlashDriveIcon = New System.Windows.Forms.PictureBox()
        DescriptionLabel = New System.Windows.Forms.Label()
        PixieIcon = New System.Windows.Forms.PictureBox()
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SDCardIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FlashDriveIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DescriptionLabel
        '
        DescriptionLabel.BackColor = System.Drawing.Color.LightBlue
        DescriptionLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DescriptionLabel.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DescriptionLabel.Location = New System.Drawing.Point(51, 111)
        DescriptionLabel.Name = "DescriptionLabel"
        DescriptionLabel.Size = New System.Drawing.Size(195, 94)
        DescriptionLabel.TabIndex = 11
        DescriptionLabel.Text = "What type of device are you using?"
        DescriptionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PixieIcon
        '
        PixieIcon.Image = Global.NCS.My.Resources.Resources.Pixie32
        PixieIcon.Location = New System.Drawing.Point(13, 111)
        PixieIcon.Name = "PixieIcon"
        PixieIcon.Size = New System.Drawing.Size(32, 32)
        PixieIcon.TabIndex = 15
        PixieIcon.TabStop = False
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(98, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 80)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Click One"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SDCardIcon
        '
        Me.SDCardIcon.BackColor = System.Drawing.SystemColors.Control
        Me.SDCardIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SDCardIcon.Image = Global.NCS.My.Resources.Resources.SDCard80
        Me.SDCardIcon.Location = New System.Drawing.Point(165, 12)
        Me.SDCardIcon.Name = "SDCardIcon"
        Me.SDCardIcon.Size = New System.Drawing.Size(80, 80)
        Me.SDCardIcon.TabIndex = 13
        Me.SDCardIcon.TabStop = False
        '
        'FlashDriveIcon
        '
        Me.FlashDriveIcon.BackColor = System.Drawing.SystemColors.Control
        Me.FlashDriveIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlashDriveIcon.Image = Global.NCS.My.Resources.Resources.FlashDrive80
        Me.FlashDriveIcon.Location = New System.Drawing.Point(12, 12)
        Me.FlashDriveIcon.Name = "FlashDriveIcon"
        Me.FlashDriveIcon.Size = New System.Drawing.Size(80, 80)
        Me.FlashDriveIcon.TabIndex = 12
        Me.FlashDriveIcon.TabStop = False
        '
        'DeviceTypeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(258, 216)
        Me.Controls.Add(PixieIcon)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.SDCardIcon)
        Me.Controls.Add(Me.FlashDriveIcon)
        Me.Controls.Add(DescriptionLabel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DeviceTypeForm"
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Device Type"
        CType(PixieIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SDCardIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FlashDriveIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents SDCardIcon As System.Windows.Forms.PictureBox
    Friend WithEvents FlashDriveIcon As System.Windows.Forms.PictureBox
End Class
