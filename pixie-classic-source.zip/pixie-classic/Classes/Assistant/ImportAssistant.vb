﻿
Public Class ImportAssistant
    Inherits TransferAssistant

    ' Invoke
    Public Sub Invoke()

        Try

            ' Detect the external device
            If Not MyBase.DetectDeviceFolder() Then Return

            ' List of pictures to transfer
            Dim list As StringList

            ' Obtain a list of path names for pictures to be imported
            With My.Forms.SearchForm
                .SetOperation(SearchForm.OperationID.Import)
                .ShowDialog()
                list = .Pictures
            End With

            ' Empty list?
            If list.Count < 1 Then
                Return
            End If

            ' Create the folder on the computer to receive imported pictures
            If Not MyBase.Folders.CreateImportFolder(Now) Then
                InfoBox("Pixie couldn't create a folder on your computer to receive new pictures.")
                Return
            End If

            ' Import them files!
            With My.Forms.CopyProgressForm
                .SetOperation(CopyProgressForm.OperationID.Import, list)
                .ShowDialog()
            End With

        Catch ex As Exception

            SilentExceptionReport(ex)
            InfoBox(ex.Message)

        End Try

    End Sub

    ' Show export image in picture box control
    Public Sub ShowImage(control As Windows.Forms.PictureBox)

        If control Is Nothing Then Return

        Dim assistComputer As New ComputerTypeAssistant
        Dim computerType As ComputerTypeAssistant.ComputerTypeID = assistComputer.CurrentTypeID

        Dim assistDevice As New DeviceTypeAssistant
        Dim deviceType As DeviceTypeAssistant.DeviceTypeID = assistDevice.CurrentTypeID

        Select Case deviceType
            Case DeviceTypeAssistant.DeviceTypeID.FlashDrive
                Select Case computerType
                    Case ComputerTypeAssistant.ComputerTypeID.Desktop
                        control.Image = My.Resources.FlashToDesktop
                    Case ComputerTypeAssistant.ComputerTypeID.Laptop
                        control.Image = My.Resources.FlashToLaptop
                End Select
            Case DeviceTypeAssistant.DeviceTypeID.SDCard
                Select Case computerType
                    Case ComputerTypeAssistant.ComputerTypeID.Desktop
                        control.Image = My.Resources.SDToDesktop
                    Case ComputerTypeAssistant.ComputerTypeID.Laptop
                        control.Image = My.Resources.SDToLaptop
                End Select
        End Select

    End Sub

End Class
