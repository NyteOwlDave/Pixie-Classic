﻿
Public Class PixieSaysAssistant

    ' Where to display the messages
    Private Control As New Windows.Forms.Label

    ' Internal color setting class
    Private Class ColorSetting
        Public Const Prefix As String = "RGBA"
        Public Const Splitter As String = ":"
        Public Color As System.Drawing.Color
        Public Sub Clear()
            Me.Color = System.Drawing.Color.FromArgb(Me.DefaultColor)
        End Sub
        Public Function Compose() As String
            Dim rrr As String = CStr(Me.Color.R)
            Dim ggg As String = CStr(Me.Color.G)
            Dim bbb As String = CStr(Me.Color.B)
            Dim aaa As String = CStr(Me.Color.A)
            Return Prefix & Splitter & rrr & Splitter & ggg & Splitter & bbb & Splitter & aaa
        End Function
        Public Sub Parse(c As String)
            If c.StartsWith(Prefix) Then
                Dim sa() As String = c.Split(Splitter)
                If sa.Count <> 5 Then
                    DebugOut("Wrong number of RGBA elements.")
                    Me.Clear()
                    Return
                End If
            Else
                DebugOut("Wrong RGBA prefix.")
                Me.Clear()
            End If
        End Sub
        Public ReadOnly Property DefaultColor As Integer
            Get
                ' Fully transparent magenta
                Return System.Drawing.Color.FromArgb(0, 255, 0, 255).ToArgb
            End Get
        End Property
        Public ReadOnly Property IsDefaultColor As Boolean
            Get
                If Me.DefaultColor = Me.Color.ToArgb Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property
        Public Sub Initialize(r As Integer, g As Integer, b As Integer, a As Integer)
            Me.Color = System.Drawing.Color.FromArgb(a, r, g, b)
        End Sub
    End Class

    ' Initialize the helper
    Public Sub Initialize(label As Windows.Forms.Label, Optional setup As Boolean = False)
        If label Is Nothing Then Return
        Me.Control = label
        If setup Then Me.LoadSettings()
    End Sub

    ' Invoke the helper
    Public Sub SayHelp(id As MainForm.ButtonID)
        Select Case id
            Case MainForm.ButtonID.Computer
                Me.Say(My.Settings.HelpMsgComputerType)
            Case MainForm.ButtonID.Device
                Me.Say(My.Settings.HelpMsgDeviceType)
            Case MainForm.ButtonID.Export
                Me.Say(My.Settings.HelpMsgExport)
            Case MainForm.ButtonID.Import
                Me.Say(My.Settings.HelpMsgImport)
            Case MainForm.ButtonID.Preview
                Me.Say(My.Settings.HelpMsgPreviewArt)
            Case Else
                Me.Say(My.Settings.HelpMsgDefault)
        End Select
    End Sub

    ' Pixie says something
    Public Sub Say(msg As String)
        Me.Control.Text = msg
    End Sub

    ' Load settings for the control
    Public Sub LoadSettings()

        Dim fontName As String
        Dim fontSize As Single

        Dim foreColor As New ColorSetting
        Dim backColor As New ColorSetting

        With My.Settings
            fontName = .PixieFontName
            fontSize = .PixieFontSize
            foreColor.Parse(.PixieForeColor)
            backColor.Parse(.PixieBackColor)
        End With

        If foreColor.IsDefaultColor Then
            foreColor.Color = Color.DarkOliveGreen
        End If

        If backColor.IsDefaultColor Then
            backColor.Color = Color.Honeydew
        End If

        With Me.Control

            Try
                .Font = New Font(fontName, fontSize)
            Catch ex As Exception
                SilentExceptionReport(ex)
            End Try

            Try
                .ForeColor = foreColor.Color
            Catch ex As Exception
                SilentExceptionReport(ex)
            End Try

            Try
                .BackColor = backColor.Color
            Catch ex As Exception
                SilentExceptionReport(ex)
            End Try

        End With

    End Sub

    ' Save settings for the control
    Public Sub SaveSettings()

        Dim fontName As String
        Dim fontSize As Single

        Dim foreColor As New ColorSetting
        Dim backColor As New ColorSetting

        With Me.Control
            foreColor.Color = .ForeColor
            backColor.Color = .BackColor
            With .Font
                fontName = .Name
                fontSize = .Size
            End With
        End With

        With My.Settings
            .PixieFontName = fontName
            .PixieFontSize = fontSize
            .PixieForeColor = foreColor.Compose()
            .PixieBackColor = backColor.Compose()
        End With

    End Sub

    ' Load pixie image into picture box
    Public Sub LoadImage(box As Windows.Forms.PictureBox)
        If box Is Nothing Then Return
        Dim width As Integer = box.Width
        Select Case width
            Case 256
                box.Image = My.Resources.Pixie
            Case 80
                box.Image = My.Resources.Pixie80
            Case 64
                box.Image = My.Resources.Pixie64
            Case 48
                box.Image = My.Resources.Pixie48
            Case 32
                box.Image = My.Resources.Pixie32
            Case 24
                box.Image = My.Resources.Pixie24
            Case 16
                box.Image = My.Resources.Pixie16
            Case Else
                DebugOut("Invalid pixie image size: " & width)
                box.Image = Nothing
        End Select
    End Sub

End Class
