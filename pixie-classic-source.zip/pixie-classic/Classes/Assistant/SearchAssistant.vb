﻿
Public Class SearchAssistant

    Private Folders As New PixieFolderState

    ' Locate all picture files on current removable device
    Public Function FindDevicePictures(callback As FolderSearcher.Located) As StringList

        ' Get the device folder
        Dim folder As String = Me.Folders.DeviceFolder
        If Not FolderExists(folder) Then
            InfoBox("Pixie can't find the device folder.")
            Return Nothing
        End If

        ' Get the device drive info
        Dim info As IO.DriveInfo = SearchAssistant.GetDriveInfo(folder)
        If (info Is Nothing) Then
            InfoBox("Pixie can't get information about the device drive.")
            Return Nothing
        End If

        ' Verify device is removable type
        If info.DriveType <> IO.DriveType.Removable Then
            InfoBox("Pixie can only import from removable devices.")
            Return Nothing
        End If

        ' Verify device is ready for access
        If Not info.IsReady Then
            InfoBox("The device is not ready. Please try again.")
            Return Nothing
        End If

        ' Seach for picture files
        Return SearchAssistant.Discover(folder, callback)

    End Function

    ' Locate all picture files in current folder on the computer
    Public Function FindComputerPictures(callback As FolderSearcher.Located) As StringList

        ' Get the computer folder
        Dim folder As String = Me.Folders.ImportFolder
        If Not FolderExists(folder) Then
            InfoBox("Pixie can't find the computer folder.")
            Return Nothing
        End If

        ' Get the computer drive info
        Dim info As IO.DriveInfo = SearchAssistant.GetDriveInfo(folder)
        If (info Is Nothing) Then
            InfoBox("Pixie can't get information about the computer drive.")
            Return Nothing
        End If

        ' Verify device is ready for access
        If Not info.IsReady Then
            InfoBox("The device is not ready. Please try again.")
            Return Nothing
        End If

        ' Seach for picture files
        Return SearchAssistant.Discover(folder, callback)

    End Function

    ' Discover pictures in specified folder
    Public Shared Function Discover(folder As String, callback As FolderSearcher.Located) As StringList

        Dim search As New PictureSearcher
        Return search.Execute(folder, callback)

    End Function

    ' Get device info
    Public Shared Function GetDriveInfo(folder As String) As IO.DriveInfo

        Return My.Computer.FileSystem.GetDriveInfo(folder)

    End Function

End Class
