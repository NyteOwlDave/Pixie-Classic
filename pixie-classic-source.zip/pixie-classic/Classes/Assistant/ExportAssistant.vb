﻿
Public Class ExportAssistant
    Inherits TransferAssistant

    ' Invoke
    Public Sub Invoke()

        ' Choose the source folder
        If Not MyBase.ChooseComputerFolder() Then
            Return
        End If

        ' Do the import form
        Try

            Dim list As StringList

            ' Obtain a list of path names for pictures to be exported
            With My.Forms.SearchForm
                .SetOperation(SearchForm.OperationID.Export)
                .ShowDialog()
                list = .Pictures
            End With

            ' Empty list?
            If list.Count < 1 Then
                Return
            End If

            ' Detect the external device
            If Not MyBase.DetectDeviceFolder() Then Return

            ' Create the folder on the removable device to receive exported pictures
            If Not MyBase.Folders.CreateExportFolder(Now) Then
                InfoBox("Pixie couldn't create a folder on your device to receive pictures.")
                Return
            End If

            ' Import them files!
            With My.Forms.CopyProgressForm
                .SetOperation(CopyProgressForm.OperationID.Export, list)
                .ShowDialog()
            End With

        Catch ex As Exception

            SilentExceptionReport(ex)
            InfoBox(ex.Message)

        End Try

    End Sub

    ' Show export image in picture box control
    Public Sub ShowImage(control As Windows.Forms.PictureBox)

        If control Is Nothing Then Return

        Dim assistComputer As New ComputerTypeAssistant
        Dim computerType As ComputerTypeAssistant.ComputerTypeID = assistComputer.CurrentTypeID

        Dim assistDevice As New DeviceTypeAssistant
        Dim deviceType As DeviceTypeAssistant.DeviceTypeID = assistDevice.CurrentTypeID

        Select Case computerType
            Case ComputerTypeAssistant.ComputerTypeID.Desktop
                Select Case deviceType
                    Case DeviceTypeAssistant.DeviceTypeID.FlashDrive
                        control.Image = My.Resources.DesktopToFlash
                    Case DeviceTypeAssistant.DeviceTypeID.SDCard
                        control.Image = My.Resources.DesktopToSD
                End Select
            Case ComputerTypeAssistant.ComputerTypeID.Laptop
                Select Case deviceType
                    Case DeviceTypeAssistant.DeviceTypeID.FlashDrive
                        control.Image = My.Resources.LaptopToFlash
                    Case DeviceTypeAssistant.DeviceTypeID.SDCard
                        control.Image = My.Resources.LaptopToSD
                End Select
        End Select

    End Sub

End Class
