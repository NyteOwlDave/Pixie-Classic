﻿
Public Class ComputerTypeAssistant

    ' Computer type ID codes
    Public Enum ComputerTypeID
        Laptop
        Desktop
    End Enum

    ' Invoke
    Public Function Invoke(id As ComputerTypeID) As Boolean
        Try
            Dim result = My.Forms.ComputerTypeForm.ShowDialog()
            If (result <> DialogResult.OK) Then Return False
            Return True
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Current computer type ID
    Public Property CurrentTypeID As ComputerTypeAssistant.ComputerTypeID
        Get
            Return CType(My.Settings.ComputerType, ComputerTypeAssistant.ComputerTypeID)
        End Get
        Set(value As ComputerTypeAssistant.ComputerTypeID)
            My.Settings.ComputerType = CInt(value)
        End Set
    End Property

    ' Show image in picture box control
    Public Sub ShowImage(control As Windows.Forms.PictureBox)
        If control Is Nothing Then Return
        Select Case Me.CurrentTypeID
            Case ComputerTypeID.Desktop
                Select Case control.Width
                    Case 256 : control.Image = My.Resources.Desktop : Return
                    Case 80 : control.Image = My.Resources.Desktop80 : Return
                    Case 64 : control.Image = My.Resources.Desktop64 : Return
                    Case 48 : control.Image = My.Resources.Desktop48 : Return
                End Select
            Case ComputerTypeID.Laptop
                Select Case control.Width
                    Case 256 : control.Image = My.Resources.Laptop : Return
                    Case 80 : control.Image = My.Resources.Laptop80 : Return
                    Case 64 : control.Image = My.Resources.Laptop64 : Return
                    Case 48 : control.Image = My.Resources.Laptop48 : Return
                End Select
            Case Else
                control.Image = Nothing
                DebugOut("Invalid COMPUTER type: " & Me.CurrentTypeID)
                Return
        End Select
        control.Image = Nothing
        DebugOut("Invalid COMPUTER control width: " & control.Width)
    End Sub

End Class

