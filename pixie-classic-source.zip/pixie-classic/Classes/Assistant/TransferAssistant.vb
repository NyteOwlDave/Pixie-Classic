﻿
Public Class TransferAssistant

    ' Pixie folder state instance
    Friend Folders As New PixieFolderState

    ' Detect the external device
    Friend Function DetectDeviceFolder() As Boolean

        Try

            With My.Forms.DetectDeviceForm

                ' Do the detection form
                Dim result = .ShowDialog
                If (result <> DialogResult.OK) Then
                    Return False
                End If

                ' Capture the device that was detected
                Dim device As IO.DriveInfo = .DetectedDevice
                If (device Is Nothing) Then
                    Return False
                End If

                ' Save the device folder to settings
                Me.Folders.DeviceFolder = device.RootDirectory.FullName
                Return True

            End With

        Catch ex As Exception

            SilentExceptionReport(ex)
            InfoBox(ex.Message)
            Return False

        End Try

    End Function

    ' Choose a folder on the computer
    Friend Function ChooseComputerFolder() As Boolean

        Try

            ' Do folder browser dialog
            Dim dlg = Me.CreateFolderBrowserDialog()
            Dim result = dlg.ShowDialog()
            If (result <> DialogResult.OK) Then
                Return False
            End If

            ' Success
            Return True

        Catch ex As Exception

            SilentExceptionReport(ex)
            InfoBox(ex.Message)
            Return False

        End Try

    End Function

    ' Create folder browser dialog
    Private Function CreateFolderBrowserDialog() As ChooseFolderForm

        ' Get most recent source folder location
        Dim folder As String = Me.Folders.ImportFolder
        If Not FolderExists(folder) Then
            folder = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures)
        End If

        ' Initialize the dialog
        Dim dlg As New ChooseFolderForm
        With dlg
            .Message = "Choose Pictures Folder"
        End With

        ' Return the dialog
        Return dlg

    End Function

End Class
