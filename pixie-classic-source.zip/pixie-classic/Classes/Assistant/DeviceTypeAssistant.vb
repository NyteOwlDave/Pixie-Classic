﻿
Public Class DeviceTypeAssistant

    ' Device type ID codes
    Public Enum DeviceTypeID
        FlashDrive
        SDCard
    End Enum

    ' Invoke the form
    Public Function Invoke(id As DeviceTypeID) As Boolean
        Try
            Dim result = My.Forms.DeviceTypeForm.ShowDialog()
            If (result <> DialogResult.OK) Then Return False
            Return True
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Current device type ID
    Public Property CurrentTypeID As DeviceTypeAssistant.DeviceTypeID
        Get
            Return CType(My.Settings.DeviceType, DeviceTypeAssistant.DeviceTypeID)
        End Get
        Set(value As DeviceTypeAssistant.DeviceTypeID)
            My.Settings.DeviceType = CInt(value)
        End Set
    End Property

    ' Show image in picture box control
    Public Sub ShowImage(control As Windows.Forms.PictureBox)
        If control Is Nothing Then Return
        Select Case Me.CurrentTypeID
            Case DeviceTypeID.FlashDrive
                Select Case control.Width
                    Case 256 : control.Image = My.Resources.FlashDrive : Return
                    Case 80 : control.Image = My.Resources.FlashDrive80 : Return
                    Case 64 : control.Image = My.Resources.FlashDrive64 : Return
                    Case 48 : control.Image = My.Resources.FlashDrive48 : Return
                End Select
            Case DeviceTypeID.SDCard
                Select Case control.Width
                    Case 256 : control.Image = My.Resources.SDCard : Return
                    Case 80 : control.Image = My.Resources.SDCard80 : Return
                    Case 64 : control.Image = My.Resources.SDCard64 : Return
                    Case 48 : control.Image = My.Resources.SDCard48 : Return
                End Select
            Case Else
                control.Image = Nothing
                DebugOut("Invalid DEVICE type: " & Me.CurrentTypeID)
                Return
        End Select
        control.Image = Nothing
        DebugOut("Invalid DEVICE control width: " & control.Width)
    End Sub

End Class

