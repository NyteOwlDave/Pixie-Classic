﻿
Public Class PreviewAssistant

    Public Enum ImageID
        Pixie
        Desktop
        Laptop
        FlashDrive
        SDCard
    End Enum

    Public Sub Invoke(id As ImageID)
        Select Case id
            Case ImageID.Desktop
                My.Forms.PreviewDesktopForm.ShowDialog()
            Case ImageID.FlashDrive
                My.Forms.PreviewFlashDriveForm.ShowDialog()
            Case ImageID.Laptop
                My.Forms.PreviewLaptopForm.ShowDialog()
            Case ImageID.Pixie
                My.Forms.PreviewPixieForm.ShowDialog()
            Case ImageID.SDCard
                My.Forms.PreviewSDCardForm.ShowDialog()
        End Select
    End Sub

End Class
