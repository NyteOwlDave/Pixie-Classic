﻿
Public Class PictureExporter

    ' Invoke the export thread
    Public Sub Execute(pathNames As StringList, callback As FileOperationThread.Handler)
        Dim thread As New FileBatchThread
        Dim folders As New PixieFolderState
        Dim target As String = folders.ExportFolder
        thread.Invoke(pathNames, target, callback)
    End Sub

End Class
