﻿
Public Class PictureImporter

    ' Invoke the import thread
    Public Sub Execute(pathNames As StringList, callback As FileOperationThread.Handler)
        Dim thread As New FileBatchThread
        Dim folders As New PixieFolderState
        Dim target As String = folders.ImportFolder
        thread.Invoke(pathNames, target, callback)
    End Sub

End Class
