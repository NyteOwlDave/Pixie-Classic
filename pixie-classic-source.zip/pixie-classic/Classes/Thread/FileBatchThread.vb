﻿
Public NotInheritable Class FileBatchThread

    ' Internal state class
    Private Class InternalState
        Private Progress As Integer
        Private Operation As New FileOperationThread
        Private Arguments As New FileOperationThread.HandlerArguments
        Private TargetFolder As String
        Private Location As New FileLocation
        Public Function Initialize(target As String, callback As FileOperationThread.Handler) As Boolean
            Me.Progress = 0
            Me.TargetFolder = target
            If Not FolderExists(target) Then
                DebugOut("The target folder does not exist.")
                Return False
            End If
            Return Me.Operation.Initialize(callback)
        End Function
        Public Function Process(source As String) As Boolean
            Dim target As String
            With Me.Location
                .PathName = source
                .Folder = Me.TargetFolder
                target = .PathName
            End With
            With Me.Arguments
                .Initialize(FileOperationThread.Mode.SourceAndTarget, source, target, Me.Progress)
            End With
            Return Me.Operation.Invoke(Me.Arguments)
        End Function
        Public Property ProgressPercent As Integer
            Get
                Return Me.Progress
            End Get
            Set(value As Integer)
                Me.Progress = value
            End Set
        End Property
        Public Sub Cancel()
            With Me.Operation
                .Cancel()
            End With
        End Sub
    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Invoke the thread's operation
    Public Sub Invoke(pathNames As StringList, targetFolder As String, callback As FileOperationThread.Handler)
        If Me.State.Initialize(targetFolder, callback) Then
            Dim progress As New ProgressCounter(pathNames.Count)
            For Each file As String In pathNames
                With Me.State
                    progress.Increment()
                    .ProgressPercent = progress.Percent
                    If Not .Process(file) Then
                        Return
                    End If
                End With
            Next
        End If
    End Sub

    ' Explicitly cancel the operation
    Public Sub Cancel()
        With Me.State
            .Cancel()
        End With
    End Sub

    ' Progress counter
    Private Class ProgressCounter

        Private Index As Double
        Private Count As Double

        Public Sub New(count As Integer)
            Me.Initialize(count)
        End Sub

        Public ReadOnly Property Percent As Integer
            Get
                Dim ratio As Double = Me.Index / Me.Count
                Return CInt(ratio * 100)
            End Get
        End Property

        Public Sub Increment()
            If Me.Index < Me.Count Then
                Me.Index += 1
            End If
        End Sub

        Public Sub Clear()
            Me.Index = 0
        End Sub

        Public Sub Initialize(count As Integer)
            Me.Index = 0
            Me.Count = Math.Max(count, 1)
        End Sub

    End Class

End Class
