﻿
Public NotInheritable Class FileOperationThread

    ' Mode for handler callback
    Public Enum Mode
        SourceOnly
        SourceAndTarget
    End Enum

    ' Arguments for handler callback
    Public Class HandlerArguments
        Public Cancel As Boolean
        Private Structure InternalState
            Private ProgressPercent As Integer
            Public Mode As FileOperationThread.Mode
            Public Source As String
            Public Target As String
            Public Property Progress As Integer
                Get
                    Return Me.ProgressPercent
                End Get
                Set(value As Integer)
                    Dim pct As Integer = Math.Min(100, value)
                    Me.ProgressPercent = Math.Max(pct, 0)
                End Set
            End Property
        End Structure
        Private State As New InternalState
        Public Sub Initialize(mode As FileOperationThread.Mode, source As String, target As String, progress As Integer)
            Me.Cancel = False
            With Me.State
                .Mode = mode
                .Source = source
                .Target = target
                .Progress = progress
            End With
        End Sub
        Public ReadOnly Property Mode As FileOperationThread.Mode
            Get
                With Me.State
                    Return .Mode
                End With
            End Get
        End Property
        Public ReadOnly Property Source As String
            Get
                With Me.State
                    Return .Source
                End With
            End Get
        End Property
        Public ReadOnly Property Target As String
            Get
                With Me.State
                    Return .Target
                End With
            End Get
        End Property
        Public ReadOnly Property Progress As Integer
            Get
                With Me.State
                    Return .Progress
                End With
            End Get
        End Property
    End Class

    ' Callback for reporting a file system object has been processed
    Public Delegate Sub Handler(args As FileOperationThread.HandlerArguments)

    ' Internal state class
    Private Class InternalState

        ' Instance of the callback function
        Private Callback As Handler = Nothing

        ' Initialize the state
        Public Function Initialize(callbackAddress As Handler) As Boolean
            Me.Callback = callbackAddress
            Return Me.Initialized
        End Function

        ' Whether the state has been initialized yet
        Public ReadOnly Property Initialized As Boolean
            Get
                ' Letting the callback reference serve also as a boolean flag
                '  is more efficient ;)
                If Me.Callback Is Nothing Then
                    Return False
                Else
                    Return True
                End If
            End Get
        End Property

        ' Invoke the handler function
        Public Function InvokeHandler(args As FileOperationThread.HandlerArguments) As Boolean

            Try

                ' If the instance has been initialized
                If Me.Initialized Then

                    ' Call back the handler
                    Me.Callback(args)

                    ' If the handler cancelled the operation
                    If args.Cancel Then

                        ' Cancel the operation
                        Me.Cancel()

                        ' Tell the debugger what happened
                        DebugOut("The handler function terminated the file operation")
                        DebugOut(" (possibly due to user interaction)")

                    Else

                        ' Return TRUE to indicate that the handler wants the
                        ' operation to continue
                        Return True

                    End If

                End If

            Catch ex As Exception

                ' Tell the debugger what happened
                DebugOut("The handler function threw an exception:")
                SilentExceptionReport(ex)

            End Try

            ' Return false to indicate that the calling operation should be terminated
            Return False

        End Function

        ' Cancel the operation
        Public Sub Cancel()

            ' This implicitly forces the Initialized property to FALSE
            ' We do this merely to avoid using a separate boolean flag
            Me.Callback = Nothing

        End Sub

    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Constructor
    Public Sub New()
    End Sub

    ' Constructor
    Public Sub New(callbackAddress As Handler)
        Me.Initialize(callbackAddress)
    End Sub

    ' Initialization
    Public Function Initialize(callbackAddress As Handler) As Boolean
        With Me.State
            Return .Initialize(callbackAddress)
        End With
    End Function

    ' Report that a file system transaction has been processed
    ' This invokes the callback, which may terminate the operation
    ' The return value is TRUE if the operation should continue
    ' The return value is FALSE if the operation should terminate
    Public Function Invoke(args As FileOperationThread.HandlerArguments) As Boolean
        With Me.State
            Return .InvokeHandler(args)
        End With
    End Function

    ' Explicitly terminate the operation
    Public Sub Cancel()
        With Me.State
            .Cancel()
        End With
    End Sub

End Class
