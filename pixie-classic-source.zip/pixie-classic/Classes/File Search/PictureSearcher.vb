﻿
Public Class PictureSearcher

    ' Execute the search for pictures
    Public Function Execute(folder As String, callback As FolderSearcher.Located) As StringList

        Dim aid As New FolderSearcher

        With aid.Extensions
            .Add("png")
            .Add("jpg")
            .Add("jpeg")
            .Add("gif")
            .Add("bmp")
            .Add("tif")
            .Add("tiff")
        End With

        Return aid.Execute(folder, callback)

    End Function

End Class

