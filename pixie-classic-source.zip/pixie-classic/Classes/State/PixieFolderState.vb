﻿
Public Class PixieFolderState

    ' Date title class
    Private Structure DateTitle
        Public Year As Integer
        Public Month As Integer
        Public Day As Integer
        Public Sub Initialize(targetDate As Date)
            Me.Year = targetDate.Year
            Me.Month = targetDate.Month
            Me.Day = targetDate.Day
        End Sub
        Public Function Compose() As String
            Dim yyyy As String = RSet(Me.Year.ToString, 4)
            Dim mm As String = Me.GetMonthName()
            Dim dd As String = RSet(Me.Day.ToString, 2)
            Return yyyy & "-" & mm & "-" & dd
        End Function
        Public Function GetMonthName() As String
            Select Case Me.Month
                Case 12 : Return "DEC"
                Case 11 : Return "NOV"
                Case 10 : Return "OCT"
                Case 9 : Return "SEP"
                Case 8 : Return "AUG"
                Case 7 : Return "JUL"
                Case 6 : Return "JUN"
                Case 5 : Return "MAY"
                Case 4 : Return "APR"
                Case 3 : Return "MAR"
                Case 2 : Return "FEB"
                Case Else : Return "JAN"
            End Select
        End Function
    End Structure

    ' Device folder
    Public Property DeviceFolder As String
        Get
            Return My.Settings.DeviceFolder
        End Get
        Set(value As String)
            My.Settings.DeviceFolder = value
        End Set
    End Property

    ' Import folder
    Public Property ImportFolder As String
        Get
            Dim folder As String = My.Settings.ImportFolder
            If "?" = folder Then
                folder = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures)
                My.Settings.ImportFolder = folder
            End If
            Return folder
        End Get
        Set(value As String)
            My.Settings.ImportFolder = value
        End Set
    End Property

    ' Export folder
    Public Property ExportFolder As String
        Get
            Return My.Settings.ExportFolder
        End Get
        Set(value As String)
            My.Settings.ExportFolder = value
        End Set
    End Property

    ' Compose full pathname for folder on the computer (My Pictures)
    Public Shared Function ComposeImportFolder(title As String) As String
        Dim loc As New FileLocation
        loc.Folder = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures)
        loc.TitleAndExtension = "Pixie"
        Dim folder As String = loc.PathName
        loc.Folder = folder
        loc.TitleAndExtension = title
        Return loc.PathName
    End Function

    ' Compose full pathname for folder on the removable device
    Public Shared Function ComposeExportFolder(title As String) As String
        Dim loc As New FileLocation
        loc.Folder = My.Settings.DeviceFolder
        loc.TitleAndExtension = "Pixie"
        Dim folder As String = loc.PathName
        loc.Folder = folder
        loc.TitleAndExtension = title
        Return loc.PathName
    End Function

    ' Compose full pathname for folder containing most recently transfered files
    Public Shared Function ComposeTitle(day As Date) As String
        Dim title As New DateTitle
        title.Initialize(day)
        Return title.Compose()
    End Function

    ' Create a location on the computer to receive imported pictures
    Public Function CreateImportFolder(day As Date) As Boolean

        ' Compose title for folder on the computer
        Dim title As String = PixieFolderState.ComposeTitle(day)

        ' Create folder on the local computer (for an import operation)
        Dim folder As String = PixieFolderState.ComposeImportFolder(title)

        ' Create the location and remember it for later
        If NCS.CreateFolder(folder) Then
            Me.ImportFolder = folder
            Return True
        Else
            Return False
        End If

    End Function

    ' Create a location on the removable device to receive exported pictures
    Public Function CreateExportFolder(day As Date) As Boolean

        ' Compose title for folder on the computer
        Dim title As String = PixieFolderState.ComposeTitle(day)

        ' Create folder on the removable drive (for an export operation)
        Dim folder As String = PixieFolderState.ComposeExportFolder(title)

        ' Create the location and remember it for later
        If NCS.CreateFolder(folder) Then
            Me.ExportFolder = folder
            Return True
        Else
            Return False
        End If

    End Function

    ' Test
    Public Shared Sub Test()
        Dim title As String = ComposeTitle(Now)
        DebugOut(ComposeImportFolder(title))
        DebugOut(ComposeExportFolder(title))
    End Sub

End Class
