﻿
'
' StreamBlockTransfer class
'
' Provides a mechanism for transferring data from one stream to another in blocks
' of an arbitrary size, with progress reporting and optional cancellation between
' each transferred block.
'
' This class is for bulk transfers which might take a long time and possibly need
' to be cancelled for one reason or another. As such the minimum block size is
' set to 256 bytes.
'
' Even so, any length stream can be handled, including zero length. For the sake
' of efficient use of working RAM, and user sensitivity, the maximum block size
' is limited to 64kb.
'
' On entry, both streams must be open and ready to transfer data in the correct
' direction. Neither stream is closed on output - whether an error occurs or not.
' The caller is responsible for closing each stream.
'

Public Class StreamBlockTransfer
    Implements IProgress

    ' Minimum block size
    Public Const BlockSizeMinimum As Integer = 2 ^ 8

    ' Maximum block size
    Public Const BlockSizeDefault As Integer = 2 ^ 12

    ' Maximum block size
    Public Const BlockSizeMaximum As Integer = 2 ^ 16

    ' Progress report interface
    Public Interface IProgress
        ReadOnly Property BlockSize As Integer
        ReadOnly Property BytesTotal As Long
        ReadOnly Property BytesRemaining As Long
        ReadOnly Property BytesTransferred As Long
        Property Cancel As Boolean
    End Interface

    ' Progress report event
    Public Event ProgressChanged(progress As IProgress)

    ' Internal state class
    Private Class InternalState
        Public Cancel As Boolean
        Public SourceStream As IO.Stream
        Public TargetStream As IO.Stream
        Public BlockSize As Integer
        Public BytesTotal As Long
        Public BytesRemaining As Long
        Public ErrorMessage As String = String.Empty
        Public ReadOnly Property BytesTransferred As Long
            Get
                Return Me.BytesTotal - Me.BytesRemaining
            End Get
        End Property
        Public Sub Initialize(src As IO.Stream, dst As IO.Stream)
            Me.Cancel = False
            Me.SourceStream = src
            Me.TargetStream = dst
            Me.BlockSize = 0
            Me.BytesTotal = 0
            Me.BytesRemaining = 0
            If Not Me.Initialized Then
                Throw New Exception("Unable to initialize the stream block transfer.")
            End If
        End Sub
        Public ReadOnly Property Initialized As Boolean
            Get
                If (Me.SourceStream IsNot Nothing) And (Me.TargetStream IsNot Nothing) Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property
    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Construction
    Public Sub New(source As IO.Stream, target As IO.Stream)
        Me.State.Initialize(source, target)
    End Sub

    ' Transfer the information
    Public Function Transfer(Optional blockSize As Integer = BlockSizeDefault) As Boolean

        Try

            ' Clamp and store the block size
            blockSize = Math.Min(BlockSizeMaximum, blockSize)
            blockSize = Math.Max(BlockSizeMinimum, blockSize)
            Me.State.BlockSize = blockSize

            ' Allocation buffer for transfer of blocks
            Dim buf(blockSize - 1) As Byte

            ' Get the streams that were provided during construction
            Dim src As IO.Stream = Me.State.SourceStream
            Dim dst As IO.Stream = Me.State.TargetStream

            ' Get and store the total number of bytes to transfer
            ' and initialize the number of bytes remaining
            Dim cnt As Long = src.Length
            Me.State.BytesTotal = cnt
            Me.State.BytesRemaining = cnt

            ' Move one block at a time
            Do While cnt > 0

                ' Determine how many bytes to move (may be less that block size)
                Dim xfr As Integer = CInt(Math.Min(blockSize, cnt))

                ' Do the transfer of the next block
                src.Read(buf, 0, xfr)
                dst.Write(buf, 0, xfr)

                ' Deduct the transfered byte count and save the result for the
                ' progress report
                cnt -= xfr
                Me.State.BytesRemaining = cnt

                ' Do the progress report
                Try
                    RaiseEvent ProgressChanged(Me)
                Catch ex As Exception
                    SilentExceptionReport(ex)
                End Try

                ' If cancelled... well, you get it! ;)
                If Me.Cancel Then
                    Me.State.ErrorMessage = "Stream block transfer cancelled."
                    Return False
                End If

            Loop

            ' Success
            Me.State.ErrorMessage = "Successful."
            Return True

        Catch ex As Exception

            ' Oops!
            Me.State.ErrorMessage = ex.Message
            Return False

        End Try

    End Function

    ' Cancel flag
    Public Property Cancel As Boolean Implements IProgress.Cancel
        Get
            Return Me.State.Cancel
        End Get
        Set(value As Boolean)
            Me.State.Cancel = value
        End Set
    End Property

    ' Error message
    Public ReadOnly Property ErrorMessage As String
        Get
            Return Me.State.ErrorMessage
        End Get
    End Property

    ' Block size
    Public ReadOnly Property BlockSize As Integer Implements IProgress.BlockSize
        Get
            Return Me.State.BlockSize
        End Get
    End Property

    ' Bytes remaining
    Public ReadOnly Property BytesRemaining As Long Implements IProgress.BytesRemaining
        Get
            Return Me.State.BytesRemaining
        End Get
    End Property

    ' Bytes total
    Public ReadOnly Property BytesTotal As Long Implements IProgress.BytesTotal
        Get
            Return Me.State.BytesTotal
        End Get
    End Property

    ' Bytes transferred
    Public ReadOnly Property BytesTransferred As Long Implements IProgress.BytesTransferred
        Get
            Return Me.State.BytesTransferred
        End Get
    End Property

End Class

