﻿
Public Enum LocationType
    InternetURL
    InternetIP
    LocalApplication
    LocalShare
    LocalFolder
    Unknown
End Enum

Public Class LoginRecord

    Public ID As Guid = Guid.NewGuid
    Public FriendlyName As String
    Public Location As String
    Public LocationType As NCS.LocationType

    Public Sub Parse(value As String)
        ' TODO - LoginRecord.Parse()
    End Sub

    Public Function DetectLocationType(value As String) As NCS.LocationType
        ' TODO - LoginRecord.DetectLocationType()
        Return NCS.LocationType.Unknown
    End Function

    Public Function Exists() As Boolean

        Select Case Me.LocationType
            Case NCS.LocationType.InternetIP
                Return InternetIP_Exists(Me.Location)
            Case NCS.LocationType.InternetURL
                Return InternetURL_Exists(Me.Location)
            Case NCS.LocationType.LocalApplication
                Return LocalApplication_Exists(Me.Location)
            Case NCS.LocationType.LocalFolder
                Return LocalFolder_Exists(Me.Location)
            Case NCS.LocationType.LocalShare
                Return LocalShare_Exists(Me.Location)
            Case Else
                Return False
        End Select

    End Function

    Public Function IsLocationAvailable() As String

        ' TODO - LoginRecord.IsLocationAvailable()
        Return False

    End Function

    Public Function IsLocationTypeConsistent() As String

        ' TODO - LoginRecord.IsLocationTypeConsistent()
        Return Not (Nothing = Me.LocationType)

    End Function

    Public Shared Function InternetIP_Exists(address As String) As Boolean
        ' TODO - verify Internet IP address exists
        Return False
    End Function

    Public Shared Function InternetURL_Exists(address As String) As Boolean
        ' TODO - verify Internet URL exists
        Return False
    End Function

    Public Shared Function LocalApplication_Exists(address As String) As Boolean
        Return FileIO.FileSystem.FileExists(address)
    End Function

    Public Shared Function LocalFolder_Exists(address As String) As Boolean
        Return FileIO.FileSystem.FileExists(address)
    End Function

    Public Shared Function LocalShare_Exists(address As String) As Boolean
        ' TODO - verify local share exists
        Return False
    End Function

End Class

