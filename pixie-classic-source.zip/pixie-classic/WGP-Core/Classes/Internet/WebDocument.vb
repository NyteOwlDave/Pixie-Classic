﻿
Public Class WebDocument

End Class
