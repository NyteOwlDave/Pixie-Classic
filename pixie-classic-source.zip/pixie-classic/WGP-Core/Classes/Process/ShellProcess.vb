﻿
Imports System.Runtime.InteropServices

Public Class ShellProcess

    ' Win32 API call for executing via the Shell module
    <DllImport("shell32.dll", CharSet:=CharSet.Unicode)> _
    Private Shared Function ShellExecuteW _
        (ByVal hwnd As IntPtr, _
         <MarshalAs(UnmanagedType.LPWStr)> verb As String, _
         <MarshalAs(UnmanagedType.LPWStr)> target As String, _
         <MarshalAs(UnmanagedType.LPWStr)> args As String, _
         <MarshalAs(UnmanagedType.LPWStr)> folder As String, _
         ByVal showCmd As Int32) _
     As IntPtr
    End Function

    ' Show command ID codes
    Public Enum ShowCommandID
        Hidden = 0 ' SW_HIDE
        Normal = 1 ' SW_SHOWNORMAL
        Minimized = 2 ' SW_SHOWMINIMIZED
        Maximized = 3 ' SW_SHOWMAXIMIZED
        Arbitrary = 10 ' SW_SHOWDEFAULT
    End Enum

    ' Internal state class
    Private Class InternalState
        Public InstanceHandle As IntPtr = IntPtr.Zero
        Public WindowHandle As IntPtr = IntPtr.Zero
        Public Verb As String
        Public Target As String
        Public Arguments As String
        Public Folder As String
        Public ShowCommand As ShowCommandID
        Public Sub New(target As String)
            Me.Verb = "open"
            Me.Target = target
            Me.Arguments = ""
            Me.Folder = ""
            Me.ShowCommand = ShellProcess.ShowCommandID.Normal
        End Sub
        Public Sub New(target As String, verb As String)
            Me.Verb = verb
            Me.Target = target
            Me.Arguments = ""
            Me.Folder = ""
            Me.ShowCommand = ShellProcess.ShowCommandID.Normal
        End Sub
        Public Sub New(target As String, verb As String, args As String)
            Me.Verb = verb
            Me.Target = target
            Me.Arguments = args
            Me.Folder = ""
            Me.ShowCommand = ShellProcess.ShowCommandID.Normal
        End Sub
        Public Function Invoke() As Boolean
            Try
                Dim result As IntPtr
                result = ShellProcess.ShellExecuteW _
                    (Me.WindowHandle, Me.Verb, Me.Target, Me.Arguments, Me.Folder, Me.ShowCommand)
                Me.InstanceHandle = result
                If result.ToInt32 < 33 Then
                    Return False
                Else
                    Return True
                End If
            Catch ex As Exception
                SilentExceptionReport(ex)
                Return False
            End Try
        End Function
    End Class

    ' Internal state instance
    Private State As InternalState = Nothing

    ' Constructor
    Public Sub New(target As String)
        Me.State = New InternalState(target)
    End Sub

    ' Constructor
    Public Sub New(target As String, verb As String)
        Me.State = New InternalState(target, verb)
    End Sub

    ' Constructor
    Public Sub New(target As String, verb As String, arguments As String)
        Me.State = New InternalState(target, verb, arguments)
    End Sub

    ' Whether we are initialized
    Public ReadOnly Property Initialized As Boolean
        Get
            If Me.State Is Nothing Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    ' Access to target proprety
    Public ReadOnly Property Target As String
        Get
            If Me.Initialized Then
                Return Me.State.Target
            Else
                Return ""
            End If
        End Get
    End Property

    ' Access to verb proprety
    Public Property Verb As String
        Get
            If Me.Initialized Then
                Return Me.State.Verb
            Else
                Return ""
            End If
        End Get
        Set(value As String)
            If Me.Initialized Then
                Me.State.Verb = value
            End If
        End Set
    End Property

    ' Access to arguments proprety
    Public Property Arguments As String
        Get
            If Me.Initialized Then
                Return Me.State.Arguments
            Else
                Return ""
            End If
        End Get
        Set(value As String)
            If Me.Initialized Then
                Me.State.Arguments = value
            End If
        End Set
    End Property

    ' Access to folder proprety
    Public Property Folder As String
        Get
            If Me.Initialized Then
                Return Me.State.Folder
            Else
                Return ""
            End If
        End Get
        Set(value As String)
            If Me.Initialized Then
                Me.State.Folder = value
            End If
        End Set
    End Property

    ' Access to target proprety
    Public Property ShowCommand As ShowCommandID
        Get
            If Me.Initialized Then
                Return Me.State.ShowCommand
            Else
                Return ""
            End If
        End Get
        Set(value As ShowCommandID)
            If Me.Initialized Then
                Me.State.ShowCommand = value
            End If
        End Set
    End Property

    ' Execute
    Public Function Execute() As Boolean
        If Me.Initialized Then
            Return Me.State.Invoke()
        Else
            Return False
        End If
    End Function

    ' Execute
    Public Function Execute(arguments As String) As Boolean
        If Me.Initialized Then
            Me.State.Arguments = arguments
            Return Me.State.Invoke()
        Else
            Return False
        End If
    End Function

    ' Execute
    Public Function Execute(arguments As String, show As ShowCommandID) As Boolean
        If Me.Initialized Then
            With Me.State
                .Arguments = arguments
                .ShowCommand = show
                Return .Invoke()
            End With
        Else
            Return False
        End If
    End Function

    ' Execute
    Public Function Execute(arguments As String, folder As String) As Boolean
        If Me.Initialized Then
            With Me.State
                .Arguments = arguments
                .Folder = folder
                Return .Invoke()
            End With
        Else
            Return False
        End If
    End Function

    ' Execute
    Public Function Execute(arguments As String, folder As String, show As ShowCommandID) As Boolean
        If Me.Initialized Then
            With Me.State
                .Arguments = arguments
                .Folder = folder
                .ShowCommand = show
                Return .Invoke()
            End With
        Else
            Return False
        End If
    End Function

End Class

