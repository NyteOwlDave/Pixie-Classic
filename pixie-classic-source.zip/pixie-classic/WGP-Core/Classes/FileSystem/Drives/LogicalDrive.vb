﻿
'
' LogicalDrive class
'
' Exposes static functions for managing logical drive letters.
'

Imports System.Runtime.InteropServices

Public Class LogicalDrive

    <DllImport("Kernel32.dll", CharSet:=CharSet.Unicode)> _
    Private Shared Function DefineDosDeviceW(<MarshalAs(UnmanagedType.U4)> flags As ManageFlags, _
                                             <MarshalAs(UnmanagedType.LPWStr)> name As String, _
                                             <MarshalAs(UnmanagedType.LPWStr)> path As String) As Integer
    End Function

    <DllImport("Kernel32.dll", CharSet:=CharSet.Unicode)> _
    Private Shared Function QueryDosDeviceW(<MarshalAs(UnmanagedType.LPWStr)> name As String, _
                                            <MarshalAs(UnmanagedType.LPWStr)> path As String, _
                                            <MarshalAs(UnmanagedType.U4)> maxChars As Int32) As Integer

    End Function

    Public Enum ManageFlags
        Create = 0
        RawPath = 1
        Remove = 2
        ExactMatch = 4
        NoBroadcast = 8
    End Enum

    ' Manage logical drive
    Public Shared Function Manage(letter As Char, path As String, flags As ManageFlags) As Boolean
        Try
            Dim drive As String = letter & ":"
            Return DefineDosDeviceW(flags, drive, path)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Create logical drive
    Public Shared Function Create(letter As Char, path As String, Optional raw As Boolean = False) As Boolean
        If raw Then
            Return Manage(letter, path, ManageFlags.Create Or ManageFlags.RawPath)
        Else
            Return Manage(letter, path, ManageFlags.Create)
        End If
    End Function

    ' Remove logical drive
    Public Shared Function Remove(letter As Char, path As String, Optional raw As Boolean = False) As Boolean
        If raw Then
            Return Manage(letter, path, ManageFlags.Remove Or ManageFlags.ExactMatch Or raw)
        Else
            Return Manage(letter, path, ManageFlags.Remove Or ManageFlags.ExactMatch)
        End If
    End Function

    ' Query logical drive
    Public Shared Function Query(letter As Char) As String
        Try
            Const MAX_PATH As Integer = UInt16.MaxValue
            Dim drive As String = letter & ":"
            Dim path As String = Space(MAX_PATH)
            If QueryDosDeviceW(drive, path, MAX_PATH) Then
                Return Trim(path).Replace("\??\", "")
            Else
                Return String.Empty
            End If
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return String.Empty
        End Try
    End Function

End Class
