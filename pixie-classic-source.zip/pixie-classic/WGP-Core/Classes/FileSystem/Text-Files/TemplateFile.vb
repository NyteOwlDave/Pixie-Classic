﻿
Public Class TemplateFile
    Inherits TextFile

    Public Function CopyTo(fileTitle As String) As Boolean

        Dim target As New NCS.TextFile
        target.Content = Me.Content
        target.Location.Title = fileTitle
        Return target.Write()

    End Function

End Class
