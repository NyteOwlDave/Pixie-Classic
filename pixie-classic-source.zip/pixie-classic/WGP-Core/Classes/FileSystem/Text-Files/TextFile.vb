﻿
Public Class TextFile

    ' The file's content
    Public Property Content As String

    ' The pathname where the file is or should be located
    Public Property Location As New NCS.FileLocation

    ' Location as a string
    Public Property LocationString As String
        Get
            Return Me.Location.PathName
        End Get
        Set(value As String)
            Me.Location.PathName = value
        End Set
    End Property

    ' Read the file
    Public Function Read() As Boolean

        Try
            Me.Content = System.IO.File.ReadAllText(Me.LocationString)
            Return True
        Catch ex As Exception
            HandleException(ex)
            Return False
        End Try

    End Function

    ' Write the file
    Public Function Write() As Boolean

        Try
            System.IO.File.WriteAllText(Me.LocationString, Me.Content)
            Return True
        Catch ex As Exception
            HandleException(ex)
            Return False
        End Try

    End Function

    ' Read the file from a specified location
    Public Function Read(location As String) As Boolean
        Me.LocationString = location
        Return Me.Read()
    End Function

    ' Write the file to a specified location
    Public Function Write(location As String) As Boolean
        Me.LocationString = location
        Return Me.Write()
    End Function

    ' Handle exceptions quietly
    Private Sub HandleException(ex As Exception)
        Debug.Print(ex.Message)
    End Sub

End Class

