﻿
Public Class CodeFile
    Inherits ListFile

    ' Prefix for stripping away comments
    Public Property CommentPrefix As String = ""

    ' Strip away comments and return pure source code
    Public Function GetContentWithoutComments(Optional commentPrefix As String = "") As String

        ' Choose the best comment prefix
        Dim prefix As String = Me.ChooseCommentPrefix(commentPrefix)

        ' Split content into a string list object
        Dim lines As NCS.StringList = MyBase.SplitLines()

        ' Start with no code (content)
        Dim code As String = ""

        ' Walk the list of lines
        For Each line As String In lines

            ' Remove whitespace
            line = line.Trim()

            ' Keep only lines that aren't empty
            If (line.Length > 0) Then

                ' If this is not a commented line...
                If Not CodeFile.IsCommentLine(line, prefix) Then

                    ' Add it to the output code content
                    code = code + line + vbCrLf

                End If

            End If

        Next

        ' Return the result
        Return code

    End Function

    ' Determine if a line is a comment
    Public Shared Function IsCommentLine(line As String, commentPrefix As String) As Boolean

        Return line.StartsWith(commentPrefix)

    End Function

    ' Try to choose a suitable (non empty) prefix for filtering comments
    Public Function ChooseCommentPrefix(commentPrefix As String) As String

        ' If the arg prefix isn't empty, use it
        Dim prefix As String = commentPrefix
        If (prefix.Length > 0) Then Return prefix

        ' Try the object's default prefix
        prefix = Me.CommentPrefix
        If (prefix.Length > 0) Then Return prefix

        ' Look for a prefix based on the file name extension
        Return CodeFile.GetCommentPrefix(MyBase.Location.Extension)

    End Function

    ' Return canonical filename extension
    Public Shared Function GetCanonicalExtension(fileExtension As String) As String

        Dim ext = fileExtension.Trim.ToLower

        If Left(ext, 1) = "." Then
            If (ext.Length < 2) Then Return ""
            Return Mid(ext, 2)
        Else
            Return ext
        End If

    End Function

    ' Get the prefix commonly used to denote commments in various file formats
    Public Shared Function GetCommentPrefix(fileExtension As String) As String

        Dim lang = CodeFile.GetCanonicalExtension(fileExtension)

        Select Case lang

            Case "vb" : Return "'"
            Case "vbs" : Return "'"
            Case "c" : Return "//"
            Case "java" : Return "//"
            Case "js" : Return "//"
            Case "c#" : Return "//"
            Case "cpp" : Return "//"
            Case "c++" : Return "//"
            Case "tao" : Return ">>"
            Case "wgp" : Return ">>"
            Case "ncs" : Return ">>"
            Case "cmd" : Return "rem "
            Case "ini" : Return "?"
            Case "inf" : Return "?"
            Case Else : Return ""

        End Select

    End Function

End Class
