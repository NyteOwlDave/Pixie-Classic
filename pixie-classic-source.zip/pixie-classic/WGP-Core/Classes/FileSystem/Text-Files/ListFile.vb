﻿
Public Class ListFile
    Inherits TextFile

    Public Sub New()
    End Sub

    Public Overridable Function SplitLines() As NCS.StringList

        Dim list As New NCS.StringList

        Dim lines As String() = Split(MyBase.Content, vbLf)

        For Each line As String In lines

            Dim s = line.Trim()
            If (s.Length > 0) Then
                list.Add(s)
            End If

        Next

        Return list

    End Function

    Public Overridable Function MergeLines(lines As NCS.StringList) As Integer

        Dim content As String = ""

        For Each line As String In lines

            content = content + line + vbCrLf

        Next

        MyBase.Content = content

        Return content.Count

    End Function

End Class

