﻿
Public Class FileDescriptor

    Public Info As IO.FileInfo

    Public ReadOnly Property Name() As String
        Get
            Return Me.Info.Name.ToLower()
        End Get
    End Property

    Public Function IsIdenticalWith(otherFile As FileDescriptor) As String

        ' Compare dates
        Dim dateA = Me.Info.LastWriteTime
        Dim dateB = otherFile.Info.LastWriteTime
        If Not (dateA = dateB) Then Return False

        ' Compare sizes
        Dim sizeA = Me.Info.Length
        Dim sizeB = otherFile.Info.Length
        If Not (sizeA = sizeB) Then Return False

        ' Files are assumed identical
        Return True

    End Function

End Class
