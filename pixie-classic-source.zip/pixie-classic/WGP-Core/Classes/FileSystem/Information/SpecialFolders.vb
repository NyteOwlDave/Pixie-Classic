﻿
Namespace SpecialFolders

    ' Special folder ID codes
    Public Enum Kind
        CurrentUser
        AllUsers
        LocalMachine
        Software
        CloudLocal
        CloudRoaming
    End Enum

    ' Class for current user folders
    Public Class CurrentUser

        ' Friendly name
        Public Const FriendlyName As String = "Current User"

        ' User desktop folder location
        Public ReadOnly Property Desktop As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
            End Get
        End Property

        ' Location for My Documents
        Public ReadOnly Property Documents As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
            End Get
        End Property

        ' Location for My Pictures
        Public ReadOnly Property Pictures As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.MyPictures)
            End Get
        End Property

        ' Location for My Music
        Public ReadOnly Property Music As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.MyMusic)
            End Get
        End Property

        ' Location for My Videos
        Public ReadOnly Property Videos As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.MyVideos)
            End Get
        End Property

        ' User favorites location
        Public ReadOnly Property Favorites As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Favorites)
            End Get
        End Property

        ' User personal location
        Public ReadOnly Property Personal As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Personal)
            End Get
        End Property

        ' User profile location
        Public ReadOnly Property Profile As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
            End Get
        End Property

    End Class

    ' Class for common user folders
    Public Class AllUsers

        ' Friendly name
        Public Const FriendlyName As String = "All Users"

        ' Common desktop folder location
        Public ReadOnly Property Desktop As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory)
            End Get
        End Property

        ' Common documents location
        Public ReadOnly Property Documents As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments)
            End Get
        End Property

        ' Common music location
        Public ReadOnly Property Music As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonMusic)
            End Get
        End Property

        ' Common pictures location
        Public ReadOnly Property Pictures As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonPictures)
            End Get
        End Property

        ' Common videos location
        Public ReadOnly Property Videos As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonVideos)
            End Get
        End Property

    End Class

    ' Class for current user folders
    Public Class LocalMachine

        ' Friendly name
        Public Const FriendlyName As String = "Local Machine"

        ' User desktop location
        Public ReadOnly Property Desktop As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
            End Get
        End Property

        ' My Computer location
        Public ReadOnly Property Computer As String
            Get
                Dim folder As String = Environment.GetFolderPath(Environment.SpecialFolder.MyComputer)
                DebugOut("MY COMPUTER")
                DebugOut(folder)
                Return folder
            End Get
        End Property

        ' System fonts location
        Public ReadOnly Property Fonts As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Fonts)
            End Get
        End Property

        ' Resources location
        Public ReadOnly Property Resources As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Resources)
            End Get
        End Property

        ' Localized resources location
        Public ReadOnly Property LocalizedResources As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.LocalizedResources)
            End Get
        End Property

        ' Common programs location
        Public ReadOnly Property Programs As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms)
            End Get
        End Property

        ' Common Start Menu location
        Public ReadOnly Property StartMenu As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu)
            End Get
        End Property

        ' Common startup location
        Public ReadOnly Property Startup As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup)
            End Get
        End Property

        ' Common templates location
        Public ReadOnly Property Templates As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonTemplates)
            End Get
        End Property

        ' Common OEM links location
        Public ReadOnly Property Links As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonOemLinks)
            End Get
        End Property

        ' Common administrative tools location
        Public ReadOnly Property Tools As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonAdminTools)
            End Get
        End Property

        ' Common application data location
        Public ReadOnly Property Data As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData)
            End Get
        End Property

    End Class

    ' Class for software folders
    Public Class Software

        ' Friendly name
        Public Const FriendlyName As String = "Software"

        ' System OS location
        Public ReadOnly Property System32 As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.System)
            End Get
        End Property

        ' System OS X86 location
        Public ReadOnly Property System As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.SystemX86)
            End Get
        End Property

        ' Windows OS location
        Public ReadOnly Property Windows As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Windows)
            End Get
        End Property

        ' System program files location
        Public ReadOnly Property ProgramFiles As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)
            End Get
        End Property

        ' System program files X86 location
        Public ReadOnly Property ProgramFiles86 As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86)
            End Get
        End Property

        ' Common program files location
        Public ReadOnly Property CommonProgramFiles As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles)
            End Get
        End Property

        ' Common program files X86 location
        Public ReadOnly Property CommonProgramFiles86 As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFilesX86)
            End Get
        End Property

    End Class

    ' Class for cloud local folders
    Public Class CloudLocal

        ' Friendly name
        Public Const FriendlyName As String = "Cloud Local"

        ' Local application data location
        Public ReadOnly Property Data As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
            End Get
        End Property

        ' System CD burning location
        Public ReadOnly Property Burning As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.CDBurning)
            End Get
        End Property

        ' Browser history location
        Public ReadOnly Property History As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.History)
            End Get
        End Property

        ' Browser cache location
        Public ReadOnly Property Cache As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.InternetCache)
            End Get
        End Property

    End Class

    ' Class for cloud roaming folders
    Public Class CloudRoaming

        ' Friendly name
        Public Const FriendlyName As String = "Cloud Roaming"

        ' System programs location
        Public ReadOnly Property Programs As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Programs)
            End Get
        End Property

        ' Local application data location
        Public ReadOnly Property Data As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
            End Get
        End Property

        ' User recent files location
        Public ReadOnly Property Recent As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Recent)
            End Get
        End Property

        ' System templates location
        Public ReadOnly Property Templates As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Templates)
            End Get
        End Property

        ' System startup location
        Public ReadOnly Property Startup As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Startup)
            End Get
        End Property

        ' System Start Menu location
        Public ReadOnly Property StartMenu As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.StartMenu)
            End Get
        End Property

        ' System administrative tools location
        Public ReadOnly Property Tools As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.AdminTools)
            End Get
        End Property

        ' My Network location
        Public ReadOnly Property Network As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.NetworkShortcuts)
            End Get
        End Property

        ' My Printers location
        Public ReadOnly Property Printers As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.PrinterShortcuts)
            End Get
        End Property

        ' System send to location
        Public ReadOnly Property SendTo As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.SendTo)
            End Get
        End Property

        ' Browser cookies location
        Public ReadOnly Property Cookies As String
            Get
                Return Environment.GetFolderPath(Environment.SpecialFolder.Cookies)
            End Get
        End Property

    End Class

End Namespace

