﻿
Public Class FileLocation

    Public Folder As String = ""
    Public Title As String = ""
    Public Extension As String = ""

    Public Sub New()
    End Sub

    Public Sub New(ByVal pathName As String)
        Me.Split(pathName)
    End Sub

    Public Sub Split(ByVal location As String)
        Me.Folder = FileIO.FileSystem.GetParentPath(location)
        Dim spl As New FileNameSplitter
        spl.TitleAndExtension = FileIO.FileSystem.GetName(location)
        Me.Title = spl.Title
        Me.Extension = spl.Extension
    End Sub

    Public Function Merge(ByVal folder As String, ByVal titleAndExtension As String) As String
        Return FileIO.FileSystem.CombinePath(folder, titleAndExtension)
    End Function

    Public Property PathName As String
        Get
            Dim spl As New FileNameSplitter
            spl.Title = Me.Title
            spl.Extension = Me.Extension
            Dim folder = Me.Folder
            If (folder.Length < 1) Then Return spl.TitleAndExtension
            Return Me.Merge(folder, spl.TitleAndExtension)
        End Get
        Set(value As String)
            Me.Split(value)
        End Set
    End Property

    Public Property TitleAndExtension As String
        Get
            Dim spl As New FileNameSplitter
            spl.Title = Me.Title
            spl.Extension = Me.Extension
            Return spl.TitleAndExtension
        End Get
        Set(value As String)
            Dim spl As New FileNameSplitter
            spl.TitleAndExtension = value
            Me.Title = spl.Title
            Me.Extension = spl.Extension
        End Set
    End Property

End Class
