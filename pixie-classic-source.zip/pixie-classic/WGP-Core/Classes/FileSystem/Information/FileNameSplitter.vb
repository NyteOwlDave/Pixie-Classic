﻿
Public Class FileNameSplitter

    Private Const _splitter As String = "."
    Private _Title As String = ""
    Private _Extension As String = ""

    Public Property Title As String
        Get
            Return Me._Title
        End Get
        Set(value As String)
            Me._Title = Trim(value)
        End Set
    End Property

    Public Property Extension As String
        Get
            Return Me._Extension
        End Get
        Set(value As String)
            Me._Extension = CodeFile.GetCanonicalExtension(value)
        End Set
    End Property

    Public Sub New()
    End Sub

    Public Sub New(name As String)
        Me.TitleAndExtension = name
    End Sub

    Public Property TitleAndExtension As String
        Get
            If (Len(Me.Extension) < 1) Then Return Me.Title
            Return Me.Title + _splitter + Me.Extension
        End Get
        Set(value As String)
            If value.Contains(".") Then
                Me.Title = Me.GetName(value)
                Me.Extension = Me.GetExtension(value)
            Else
                Me.Title = value
                Me.Extension = ""
            End If
        End Set
    End Property

    Private Function GetName(fileName As String) As String
        Dim n As Integer = fileName.LastIndexOf(_splitter)
        If (n < 0) Then Return fileName
        If (n < 1) Then Return ""
        Return Left(fileName, n)
    End Function

    Private Function GetExtension(fileName As String) As String
        Dim n As Integer = fileName.LastIndexOf(_splitter)
        If (n < 0) Then Return ""
        Return fileName.Substring(n + 1)
    End Function

End Class

