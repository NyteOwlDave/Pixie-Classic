﻿
Public Class FileConflictResolver

    Public FileGroupA As New Dictionary(Of String, FileDescriptor)
    Public FileGroupB As New Dictionary(Of String, FileDescriptor)

    Public Sub ProcessFiles()
        '
        ' TODO... process BOTH groups
        '
        ' As each item in groupA is resolved, it can be removed from groupB
        ' we can then process what's left over in groupB...
        '
    End Sub

    Private Sub CopyAtoB(fileName As String)

        Dim descA = FileGroupA.Item(fileName)
        Dim descB = FileGroupB.Item(fileName)

        Dim pathNameA = descA.Info.FullName
        Dim pathNameB = descB.Info.FullName

        FileIO.FileSystem.CopyFile(pathNameA, pathNameB)

    End Sub

    Private Sub CopyBtoA(fileName As String)

        Dim descA = FileGroupA.Item(fileName)
        Dim descB = FileGroupB.Item(fileName)

        Dim pathNameA = descA.Info.FullName
        Dim pathNameB = descB.Info.FullName

        FileIO.FileSystem.CopyFile(pathNameB, pathNameA)

    End Sub

    Private Sub ProcessFile(fileName As String)

        Dim existsInA As Boolean = FileExistsInA(fileName)
        Dim existsInB As Boolean = FileExistsInB(fileName)
        Dim conflict As Boolean = False

        If existsInA And existsInB Then
            If Not FilesConflict(fileName) Then Return
            ResolveConflict(fileName)
            Return
        End If

        If existsInA Then
            CopyAtoB(fileName)
        Else
            CopyBtoA(fileName)
        End If

    End Sub

    Private Sub ResolveConflict(fileName As String)
        '
        ' TODO --- the tricky part!!!
        '
    End Sub

    Private Sub RenameFile(desc As FileDescriptor)

        Dim oldPathName As String = desc.Info.FullName
        Dim newPathName As String = GenerateSafePathName(oldPathName)
        FileIO.FileSystem.RenameFile(oldPathName, newPathName)

    End Sub

    Private Function FilesConflict(fileName As String) As Boolean

        Dim descA = FileGroupA.Item(fileName)
        Dim descB = FileGroupB.Item(fileName)
        Return descA.IsIdenticalWith(descB)

    End Function

    Private Function GenerateSafePathName(pathName As String) As String
        ' TODO --- safe pathname algorithm
        Return pathName + ".saved"
    End Function

    Private Function FileExistsInA(fileName As String) As Boolean

        Return FileGroupA.ContainsKey(fileName)

    End Function

    Private Function FileExistsInB(fileName As String) As Boolean

        Return FileGroupB.ContainsKey(fileName)

    End Function

    Private Function FileExistsInBoth(fileName As String) As Boolean

        Return FileExistsInA(fileName) And FileExistsInB(fileName)

    End Function

End Class
