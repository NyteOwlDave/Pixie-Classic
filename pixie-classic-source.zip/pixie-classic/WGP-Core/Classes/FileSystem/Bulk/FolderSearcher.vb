﻿
Imports System.Collections.ObjectModel

Public Class FolderSearcher

    ' Delegate for calling back located picture files
    Public Delegate Function Located(pathName As String) As Boolean

    ' Internal state class
    Private Class InternalState
        Public List As New StringList
        Public Extensions As New FileExtensionList
        Public Recursive As Boolean
        Private Callback As Located = Nothing
        Private Location As New FileLocation
        Private IgnoreExtensions As Boolean
        Public Function Initialize(callback As Located) As Boolean
            Me.Callback = callback
            Me.List.Clear()
            If Me.Extensions.Count > 0 Then
                Me.IgnoreExtensions = False
            Else
                Me.IgnoreExtensions = True
            End If
            Return Me.Initialized
        End Function
        Public ReadOnly Property Initialized As Boolean
            Get
                If Me.Callback Is Nothing Then
                    Return False
                Else
                    Return True
                End If
            End Get
        End Property
        Public Function Add(file As String) As Boolean
            ' Returning FALSE indicates that the search operation should terminate
            If Not Me.Initialized Then Return False
            ' Speed things up by skipping the code that validates the extension when
            ' the list of extensions is previously known to be empty; using a boolean
            ' flag is much faster than checking the count each time, and MEGA-faster
            ' than parsing the path and checking an empty list of extensions! ;)
            If Not Me.IgnoreExtensions Then
                ' The PathName property is volatile and for general purpose use
                Me.Location.PathName = file
                ' Obtain a canonicalized extension (lowercase and without the dot prefix)
                Dim ext As String = Me.Location.Extension
                ' See if the extension is contained in the list of desired extensions
                If Not Me.Extensions.Contains(ext) Then
                    ' Returning TRUE here means only that the search should continue
                    ' even though the file was NOT added to the list or reported...
                    Return True
                End If
            End If
            ' Add to the list
            Me.List.Add(file)
            ' Report that the file was located and give the callback the opportunity
            ' to abort the operation by returning FALSE
            If Me.Callback(file) Then
                ' The callback says the operation can continue
                Return True
            Else
                ' This causes the search to stop and the recursive call stack to unwind.
                ' It forces the Initialized property to FALSE implicitly, which results
                ' in an immediate cessation of all other activities within the state and
                ' within the outer FolderSearcher class itself (via the Finished property).
                Me.Callback = Nothing
                ' Returning FALSE means that the operation is being aborted
                Return False
            End If
        End Function
    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Access to file extensions list
    Public ReadOnly Property Extensions As FileExtensionList
        Get
            Return Me.State.Extensions
        End Get
    End Property

    ' Execute the search
    ' The Extensions list MUST be previously initialized
    ' The callback MUST return TRUE after each located file report or the search ends
    ' The return value references the internal list, so it CAN be modified externally
    Public Function Execute(folder As String, callback As Located, Optional recursive As Boolean = True) As StringList
        With Me.State
            .Recursive = recursive
            If .Initialize(callback) Then
                Me.SearchFolder(folder)
            End If
            Return .List
        End With
    End Function

    ' Whether the search is complete
    Private ReadOnly Property Finished As Boolean
        Get
            With Me.State
                ' Note that the .Initialized property is FALSE when the .Callback property
                ' has been set to Nothing - this avoids using extra flags or conditional
                ' tests to determine when the search should end
                Return Not .Initialized
            End With
        End Get
    End Property

    ' Recursively search a folder (files and all subfolders)
    Private Sub SearchFolder(folder As String)
        If Me.Finished Then Return
        Me.SearchFiles(folder)
        If Me.State.Recursive Then Me.SearchSubFolders(folder)
    End Sub

    ' Recursively search all subfolders for a given folder
    Private Sub SearchSubFolders(folder)
        If Me.Finished Then Return
        Dim folders = Me.GetSubFolders(folder)
        If folders Is Nothing Then Return
        For Each item In folders
            SearchFolder(item)
        Next
    End Sub

    ' Search all files in a given folder
    Private Sub SearchFiles(folder)
        If Me.Finished Then Return
        Dim files = Me.GetFiles(folder)
        If files Is Nothing Then Return
        For Each file As String In files
            With Me.State
                ' The Add function returns false when the callback returns false
                ' This allows the callback to abort the search operation after each
                ' located file is added to the list.
                If Not .Add(file) Then Return
            End With
        Next
    End Sub

    ' Obtain a readonly list of pathname strings for files
    ' NOTE: Returns Nothing to indicate an Exception was handled internally
    Private Function GetFiles(folder As String) As ReadOnlyCollection(Of String)

        Try
            Return My.Computer.FileSystem.GetFiles(folder)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return Nothing
        End Try

    End Function

    ' Obtain a readonly list of pathname strings for subfolders
    ' NOTE: Returns Nothing to indicate an Exception was handled internally
    Private Function GetSubFolders(folder As String) As ReadOnlyCollection(Of String)

        Try
            Return My.Computer.FileSystem.GetDirectories(folder)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return Nothing
        End Try

    End Function

End Class

