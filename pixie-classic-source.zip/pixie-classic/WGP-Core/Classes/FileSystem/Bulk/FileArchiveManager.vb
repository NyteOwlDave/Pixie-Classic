﻿
Public Class FileArchiveManager

    ' TODO - Implement the archive manager class...

    ' Backup files
    Public Function Backup() As Boolean
        DebugReportNotImplemented("Backup()")
        Return False
    End Function

    ' Restore files
    Public Function Restore() As Boolean
        DebugReportNotImplemented("Restore()")
        Return False
    End Function

    ' Flatten the file system
    Public Function Flatten() As Boolean
        DebugReportNotImplemented("Flatten()")
        Return False
    End Function

End Class

