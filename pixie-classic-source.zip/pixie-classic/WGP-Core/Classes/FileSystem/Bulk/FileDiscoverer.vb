﻿
Public Class FileDiscoverer

    Public Resolver As New FileConflictResolver

    Private Sub DiscoverGroupA(pathName As String)

        Dim files = FileIO.FileSystem.GetFiles(pathName)

        With Resolver.FileGroupA

            .Clear()

            For Each file As String In files

                Dim desc As New FileDescriptor
                desc.Info = FileIO.FileSystem.GetFileInfo(file)

                .Add(desc.Name, desc)

            Next

        End With

    End Sub

    Private Sub DiscoverGroupB(pathName As String)

        Dim files = FileIO.FileSystem.GetFiles(pathName)

        With Resolver.FileGroupB

            .Clear()

            For Each file As String In files

                Dim desc As New FileDescriptor
                desc.Info = FileIO.FileSystem.GetFileInfo(file)

                .Add(desc.Name, desc)

            Next

        End With

    End Sub

    Sub Discover(pathA As String, pathB As String)

        DiscoverGroupA(pathA)
        DiscoverGroupB(pathB)

    End Sub

End Class
