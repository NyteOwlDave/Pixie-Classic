﻿
Public Class ActivityCheckList

    Private _ok As Boolean = True

    Public Const MessageUnknown As String = "<?>"
    Public Property Message As String = MessageUnknown

    Public ReadOnly Property Succeeded As Boolean
        Get
            Return Me._ok
        End Get
    End Property

    Public Function AndThis(ByVal ok As Boolean) As Boolean
        Me._ok = Me._ok And ok
        Return Me._ok
    End Function

    Public Function OrThis(ByVal ok As Boolean) As Boolean
        Me._ok = Me._ok Or ok
        Return Me._ok
    End Function

    Public Function NotThis(ByVal ok As Boolean) As Boolean
        Me._ok = Me._ok And Not ok
        Return Me._ok
    End Function

    Public Function Report(ByVal ok As Boolean) As Boolean
        Me.AndThis(ok)
        DebugModule.DebugCheckListItem(Me.Message, ok)
        Return Me._ok
    End Function

    Public Sub New()
    End Sub

    Public Sub New(ByVal message As String)
        Me.Message = message
    End Sub

End Class

