﻿
'
' AssemblyRegistrar class
'
' Manages registry information about an arbitrary collection of Assemblies
'

Imports Microsoft.Win32

' Assembly registrar class
Public Class AssemblyRegistrar
    Implements IRegistryKey

    ' Assistant class
    Public Class Assistant
        Private MyName As String
        Public Sub New(assemblyName As String)
            Me.MyName = assemblyName
        End Sub
        Public Function Load() As Reflection.Assembly
            Try
                Dim target As String = GetRegisteredLocation()
                Return Reflection.Assembly.LoadFile(target)
            Catch ex As Exception
                TraceException(ex)
                Return Nothing
            End Try
        End Function
        Public Function Execute() As Boolean
            Dim proc As New ShellProcess(GetRegisteredLocation())
            Return proc.Execute()
        End Function
        Public Function ExploreFolder() As Boolean
            Dim target As New FileLocation(GetRegisteredLocation())
            Dim proc As New ShellProcess(target.Folder)
            Return proc.Execute()
        End Function
        Public Function GetRegisteredLocation() As String
            Try
                Dim reg As New RegistryKeyState
                Dim root As RegistryKey = reg.Key
                Dim key As RegistryKey = root.OpenSubKey(Me.MyName)
                Return key.GetValue(ValueName.Location.ToString()).ToString
            Catch ex As Exception
                TraceException(ex)
                Return String.Empty
            End Try
        End Function
        Public Shared Function GetRegisteredNames() As NamedStringList.IReadOnlyItems
            Try
                Dim results As New NamedStringList.Items("NCS Registered Assemblies")
                Dim reg As New RegistryKeyState
                Dim root As RegistryKey = reg.Key
                Dim names As String() = root.GetSubKeyNames()
                For Each item As String In names
                    results.Add(item)
                Next
                Return results
            Catch ex As Exception
                TraceException(ex)
                Return Nothing
            End Try
        End Function
        Public Shared Function BrowseCodeBase(Optional assembly As Reflection.Assembly = Nothing) As Boolean
            If assembly Is Nothing Then
                assembly = Reflection.Assembly.GetCallingAssembly()
            End If
            Dim proc As New ShellProcess(assembly.CodeBase)
            Return proc.Execute()
        End Function
    End Class

    ' Registry value names
    Public Enum ValueName
        Location
    End Enum

    ' Internal instance of assembly
    Private MyAssembly As Reflection.Assembly

    ' Construction
    Public Sub New(Optional assembly As Reflection.Assembly = Nothing)
        If assembly Is Nothing Then
            Me.MyAssembly = Reflection.Assembly.GetCallingAssembly()
        Else
            Me.MyAssembly = assembly
        End If
    End Sub

    ' Register the associated assembly
    Public Function Register() As Boolean
        Try
            Me.WriteValue(ValueName.Location.ToString(), Me.AssemblyLocation)
            Return True
        Catch ex As Exception
            TraceException(ex)
            Return False
        End Try
    End Function

    ' Register the associated assembly
    Public Function Deregister() As Boolean
        Try
            Dim key As RegistryKey = Me.ParentKey
            key.DeleteSubKey(Me.AssemblyName)
            Return True
        Catch ex As Exception
            TraceException(ex)
            Return False
        End Try
    End Function

    ' Registered location
    Public ReadOnly Property RegisteredLocation As String
        Get
            Return Me.ReadValue(ValueName.Location.ToString())
        End Get
    End Property

    ' Access to the associated assembly
    Public ReadOnly Property Assembly As Reflection.Assembly
        Get
            Return Me.MyAssembly
        End Get
    End Property

    ' Access to the associated assembly's name
    Public ReadOnly Property AssemblyName As String
        Get
            Dim target As New FileLocation(Me.AssemblyLocation)
            Return target.Title
        End Get
    End Property

    ' Access to the associated assembly's folder
    Public ReadOnly Property AssemblyFolder As String
        Get
            Dim target As New FileLocation(Me.AssemblyLocation)
            Return target.Folder
        End Get
    End Property

    ' Access to the associated assembly's location
    Public ReadOnly Property AssemblyLocation As String
        Get
            Return Me.MyAssembly.Location
        End Get
    End Property

    ' Returns the registry key for the associated assembly
    Public ReadOnly Property ParentKey As RegistryKey
        Get
            Try
                Dim root As New RegistryKeyState
                Return root.CreateSoftwareRootKey()
            Catch ex As Exception
                TraceException(ex)
                Return Nothing
            End Try
        End Get
    End Property

    ' Returns the registry key for the associated assembly
    Public ReadOnly Property Key As RegistryKey Implements IRegistryKey.Key
        Get
            Try
                Dim root As RegistryKey = Me.ParentKey
                Return root.CreateSubKey(Me.AssemblyName)
            Catch ex As Exception
                TraceException(ex)
                Return Nothing
            End Try
        End Get
    End Property

    ' Writes a string value to the registry key
    Public Function ReadValue(name As String) As String Implements IRegistryKey.ReadValue
        Dim key As RegistryKey = Me.Key
        Return key.GetValue(name).ToString
    End Function

    ' Reads a string value from the registry key
    Public Sub WriteValue(name As String, value As String) Implements IRegistryKey.WriteValue
        Dim key As RegistryKey = Me.Key
        key.SetValue(name, value)
    End Sub

End Class


