﻿
'
' RegistryKeyState class
'
' Maintains state information about a registry key
'

Imports Microsoft.Win32

Public Class RegistryKeyState
    Implements IRegistryKey

    ' Root key for NCS entries listed under HKCU\Software
    Public Const SoftwareRootKey As String = "NyteOwl.Computer.Software"

    ' Create the root key
    Public Function CreateSoftwareRootKey() As RegistryKey
        Try
            Return My.Computer.Registry.CurrentUser.CreateSubKey("Software\" & SoftwareRootKey)
        Catch ex As Exception
            TraceException(ex)
            Return Nothing
        End Try
    End Function

    ' Create sub software subkey
    Public Function CreateSoftwareSubKey(name As String) As RegistryKey
        Try
            Return Me.Key.CreateSubKey(name)
        Catch ex As Exception
            TraceException(ex)
            Return Nothing
        End Try
    End Function

    ' Return the registry key (open)
    Public ReadOnly Property Key As RegistryKey Implements IRegistryKey.Key
        Get
            Return Me.CreateSoftwareRootKey()
        End Get
    End Property

    ' Read a registry value
    Public Function ReadValue(name As String) As String Implements IRegistryKey.ReadValue
        Try
            Dim key As RegistryKey = Me.Key
            Return key.GetValue(name).ToString()
        Catch ex As Exception
            TraceException(ex)
            Return String.Empty
        End Try
    End Function

    ' Write a registry value
    Public Sub WriteValue(name As String, value As String) Implements IRegistryKey.WriteValue
        Try
            Dim key As RegistryKey = Me.Key
            key.SetValue(name, value)
        Catch ex As Exception
            TraceException(ex)
        End Try
    End Sub

End Class

