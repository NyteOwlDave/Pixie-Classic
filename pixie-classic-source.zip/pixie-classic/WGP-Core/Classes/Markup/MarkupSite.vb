﻿
Public Class MarkupSite

    ' Asset identifier codes
    Public Enum AssetKind
        Unknown
        Audio
        Image
        List
        Page
        Script
        Style
        Video
    End Enum

    ' Asset class
    Public Class Asset

        ' Internal data state structure
        Private Structure DataState
            Public Kind As AssetKind
            Public ID As String
            Public Title As String
            Public Extension As String
            Public Folder As String
            Public Location As String
            Public Sub Initialize(kind As AssetKind, id As String, title As String, ext As String)
                Me.Kind = kind
                Me.ID = id
                Me.Title = title
                Me.DetectExtension(ext)
                Me.DetectFolder()
                Me.DetectLocation()
            End Sub
            Private Sub DetectExtension(ext As String)
                If (ext.Length > 0) Then
                    Me.Extension = ext
                    Return
                End If
                Select Case Me.Kind
                    Case AssetKind.Audio
                        Me.Extension = "mp3"
                    Case AssetKind.Image
                        Me.Extension = "png"
                    Case AssetKind.List
                        Me.Extension = "list"
                    Case AssetKind.Page
                        Me.Extension = "xml"
                    Case AssetKind.Script
                        Me.Extension = "js"
                    Case AssetKind.Style
                        Me.Extension = "css"
                    Case AssetKind.Video
                        Me.Extension = "mp4"
                    Case Else
                        Me.Extension = ""
                End Select
            End Sub
            Private Sub DetectFolder()
                Me.Folder = Asset.GetFolder(Me.Kind)
            End Sub
            Private Sub DetectLocation()
                Dim loc As New FileLocation
                loc.Folder = Me.Folder
                loc.Title = Me.Title
                loc.Extension = Me.Extension
                Me.Location = loc.PathName
            End Sub
        End Structure

        ' Internal data state instance
        Private State As DataState

        ' Initialization
        Public Sub Initialize(kind As AssetKind, id As String, title As String, ext As String)
            Me.State.Initialize(kind, id, title, ext)
        End Sub

        ' Access to kind property
        Public ReadOnly Property Kind As AssetKind
            Get
                Return Me.State.Kind
            End Get
        End Property

        ' Access to ID property
        Public ReadOnly Property ID As String
            Get
                Return Me.State.ID
            End Get
        End Property

        ' Access to Title property
        Public ReadOnly Property Title As String
            Get
                Return Me.State.Title
            End Get
        End Property

        ' Access to Extension property
        Public ReadOnly Property Extension As String
            Get
                Return Me.State.Extension
            End Get
        End Property

        ' Access to Folder property
        Public ReadOnly Property Folder As String
            Get
                Return Me.State.Folder
            End Get
        End Property

        ' Access to location property
        Public ReadOnly Property Location As String
            Get
                Return Me.State.Location
            End Get
        End Property

        ' Whether asset file exists
        Public ReadOnly Property Exists As Boolean
            Get
                Return FileExists(Me.Location)
            End Get
        End Property

        ' Import from folder
        Public Function Import(folder As String) As Boolean
            Dim dst As String = Me.Location
            Dim src As String = Me.ReplaceFolder(dst, folder)
            Return CopyFile(src, dst)
        End Function

        ' Export to folder
        Public Function Export(folder As String) As Boolean
            Dim src As String = Me.Location
            Dim dst As String = Me.ReplaceFolder(src, folder)
            Return CopyFile(src, dst)
        End Function

        ' Replace folder in path name
        Private Function ReplaceFolder(pathName As String, folder As String) As String
            Dim loc As New NCS.FileLocation(pathName)
            loc.Folder = folder
            Return loc.PathName
        End Function

        ' Get asset folder name
        Public Shared Function GetFolder(kind As AssetKind) As String
            Dim site As New MarkupSite
            Dim loc As New FileLocation
            loc.Folder = site.Location
            loc.TitleAndExtension = kind.ToString
            Return loc.PathName
        End Function

    End Class

    ' Access to location property
    Public ReadOnly Property Location As String
        Get
            Dim loc As New FileLocation
            loc.Folder = My.Application.Info.DirectoryPath
            loc.TitleAndExtension = "Assets"
            Return loc.PathName
        End Get
    End Property

    ' Get asset names
    Public Function GetAssetNames(kind As AssetKind) As NCS.StringList

        Dim names As New NCS.StringList

        Dim folder As String = Asset.GetFolder(kind)

        If FolderExists(folder) Then

            Dim loc As New NCS.FileLocation
            Dim files = My.Computer.FileSystem.GetFiles(folder)

            For Each file As String In files
                loc.PathName = file
                names.Add(loc.TitleAndExtension)
            Next

        Else

            CreateFolder(folder)

        End If

        Return names

    End Function

    ' Create site folders
    Public Function CreateLocation() As Boolean

        ' Get site folder
        Dim siteFolder As String = Me.Location

        ' Create site folder if missing
        If Not FolderExists(siteFolder) Then
            If Not CreateFolder(siteFolder) Then
                DebugOut("Unable to create markup site folder.")
                Return False
            End If
        End If

        ' Assign new folder as current site
        Return Me.CreateAssetFolders()

    End Function

    ' Create all asset folders
    Private Function CreateAssetFolders() As Boolean

        Dim ok As Boolean = True

        ok = Me.CreateAssetFolder(AssetKind.Audio) And ok
        ok = Me.CreateAssetFolder(AssetKind.Image) And ok
        ok = Me.CreateAssetFolder(AssetKind.List) And ok
        ok = Me.CreateAssetFolder(AssetKind.Page) And ok
        ok = Me.CreateAssetFolder(AssetKind.Script) And ok
        ok = Me.CreateAssetFolder(AssetKind.Style) And ok
        ok = Me.CreateAssetFolder(AssetKind.Video) And ok

        Return ok

    End Function

    ' Create an asset folder
    Private Function CreateAssetFolder(kind As AssetKind) As Boolean

        Dim folder As String = Asset.GetFolder(kind)
        If FolderExists(folder) Then Return True
        Return CreateFolder(folder)

    End Function

End Class
