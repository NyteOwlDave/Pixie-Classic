﻿
Public Class MarkupAttribute

    ' Key (a.k.a. Name)
    Private Key As String

    ' Item (a.k.a. Value)
    Private Item As String = ""

    ' Constructor
    Public Sub New()
        Me.Name = ""
        Me.Clear()
    End Sub

    ' Constructor
    Public Sub New(name As String)
        Me.Name = name
        Me.Clear()
    End Sub

    ' Constructor
    Public Sub New(name As String, value As String)
        Me.Name = name
        Me.Value = value
    End Sub

    ' Access to attribute name
    Public Property Name As String
        Get
            Return Me.Key
        End Get
        Set(value As String)
            Dim n As String = value.Trim.ToLower
            If n.Length > 0 Then
                Me.Key = n
            Else
                Me.Key = "name"
            End If
        End Set
    End Property

    ' Access to attribute value
    Public Property Value As String
        Get
            Return Me.Item
        End Get
        Set(value As String)
            Me.Item = value
        End Set
    End Property

    ' Clear value
    Public Sub Clear()
        Me.Value = ""
    End Sub

    ' Read attribute from XML element
    Public Function Read(elem As Xml.XmlElement) As Boolean
        Try
            Me.Item = elem.Attributes(Me.Key).Value
            Return True
        Catch ex As Exception
            Me.Item = ""
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Write attribute to XML element
    Public Function Write(elem As Xml.XmlElement) As Boolean
        Try
            elem.Attributes(Me.Key).Value = Me.Item
            Return True
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Determine if attribute is contained by XML element
    Public Function ContainedBy(elem As Xml.XmlElement) As Boolean
        Try
            Dim node = elem.Attributes(Me.Key)
            If (node IsNot Nothing) Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Add attribute to XML element
    Public Function Add(elem As Xml.XmlElement) As Boolean
        Try
            Dim node = elem.OwnerDocument.CreateAttribute(Me.Key)
            node.Value = Me.Item
            elem.Attributes.Append(node)
            Return True
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Remove attribute from XML element
    Public Function Remove(elem As Xml.XmlElement) As Boolean
        Try
            Dim node = elem.Attributes(Me.Key)
            elem.Attributes.Remove(node)
            Return True
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Replace attribute in XML element
    Public Function Replace(elem As Xml.XmlElement) As Boolean
        Try
            Me.Remove(elem)
            Return Me.Add(elem)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

End Class
