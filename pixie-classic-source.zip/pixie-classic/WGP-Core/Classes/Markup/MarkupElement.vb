﻿
Public Class MarkupElement

    ' Symbol ID codes
    Public Enum SymbolID
        Paragraph
        Caption
        Button
        Title
        Asset
        XmlPage
    End Enum

    ' Internal state structure
    Private Structure InternalState
        Public ID As SymbolID
        Public Content As String
        Private Attributes As System.Collections.Generic.Dictionary(Of String, MarkupAttribute)
        Public Function Initialize(id As SymbolID) As Boolean
            Me.Content = ""
            Me.Attributes = New System.Collections.Generic.Dictionary(Of String, MarkupAttribute)
            Return True
        End Function
        Public ReadOnly Property Name As String
            Get
                Return Me.ID.ToString.ToLower
            End Get
        End Property
        Public ReadOnly Property AttributeCount As Integer
            Get
                Try
                    Return Me.Attributes.Count
                Catch ex As Exception
                    Return 0
                End Try
            End Get
        End Property
        Public Sub ClearAttributes()
            If Me.Attributes IsNot Nothing Then
                Me.Attributes.Clear()
            End If
        End Sub
        Public Function GetAttribute(name As String) As MarkupAttribute
            With Me.Attributes
                If .ContainsKey(name) Then
                    Return .Item(name)
                Else
                    Return Nothing
                End If
            End With
        End Function
        Public Function GetAttributes() As Collection
            Dim coll As New Collection
            Dim item As System.Collections.Generic.KeyValuePair(Of String, MarkupAttribute)
            For Each item In Me.Attributes
                Try
                    coll.Add(item.Value)
                Catch ex As Exception
                    SilentExceptionReport(ex)
                End Try
            Next
            Return coll
        End Function
        Public Function GetAttributeNames() As NCS.StringList
            Dim list As New NCS.StringList
            Dim item As System.Collections.Generic.KeyValuePair(Of String, MarkupAttribute)
            For Each item In Me.Attributes
                Try
                    list.Add(item.Key)
                Catch ex As Exception
                    SilentExceptionReport(ex)
                End Try
            Next
            Return list
        End Function
        Public Function CreateAttribute(name As String, value As String) As Boolean
            Try
                Dim attr As MarkupAttribute = New MarkupAttribute(name, value)
                Me.Attributes.Add(name, attr)
                Return True
            Catch ex As Exception
                SilentExceptionReport(ex)
                Return False
            End Try
        End Function
        Public Function RemoveAttribute(name As String) As Boolean
            Try
                Return Me.Attributes.Remove(name)
            Catch ex As Exception
                Return False
            End Try
        End Function
        Public Function ContainsAttribute(name As String) As Boolean
            If Me.Attributes IsNot Nothing Then
                Return Me.Attributes.ContainsKey(name)
            Else
                Return False
            End If
        End Function
        Public Function CreateXml(doc As Xml.XmlDocument) As Xml.XmlElement
            Dim elem As Xml.XmlElement = doc.CreateElement(Me.Name)
            Me.WriteAttributes(elem)
            If Me.Content.Length > 0 Then
                elem.InnerText = Me.Content
            End If
            Return elem
        End Function
        Public Function WriteAttributes(elem As Xml.XmlElement) As Boolean
            Dim ok As Boolean = True
            Dim item As System.Collections.Generic.KeyValuePair(Of String, MarkupAttribute)
            Try
                For Each item In Me.Attributes
                    ok = item.Value.Write(elem) And ok
                Next
            Catch ex As Exception
                ok = False
            End Try
            Return ok
        End Function
    End Structure

    ' Internal state structure
    Private State As InternalState

    ' Initialize
    Public Function Initialize(id As SymbolID) As Boolean
        Return Me.State.Initialize(id)
    End Function

    ' Create XML element
    Public Function CreateXml(doc As Xml.XmlDocument) As Xml.XmlElement
        Return Me.State.CreateXml(doc)
    End Function

    ' Generate paragraph
    Public Function GenerateParagraph(content As String) As Boolean
        If Me.Initialize(SymbolID.Paragraph) Then
            Me.State.Content = content
            Return True
        End If
        Return False
    End Function

    ' Generate caption
    Public Function GenerateCaption(content As String) As Boolean
        If Me.Initialize(SymbolID.Caption) Then
            Me.State.Content = content
            Return True
        End If
        Return False
    End Function

    ' Generate button
    Public Function GenerateButton(title As String) As Boolean
        If Me.Initialize(SymbolID.Button) Then
            Return Me.State.CreateAttribute("title", title)
        End If
        Return False
    End Function

    ' Generate title
    Public Function GenerateTitle(content As String) As Boolean
        If Me.Initialize(SymbolID.Title) Then
            Me.State.Content = content
            Return True
        End If
        Return False
    End Function

    ' Generate asset
    Public Function GenerateAsset(asset As MarkupSite.Asset) As Boolean
        If Me.Initialize(SymbolID.Asset) Then
            With Me.State
                Dim s As String = asset.ID
                If (s.Length > 0) Then
                    .CreateAttribute("id", s)
                End If
                .CreateAttribute("kind", asset.Kind.ToString.ToLower)
                .CreateAttribute("title", asset.Title)
                .CreateAttribute("extension", asset.Extension)
            End With
            Return True
        End If
        Return False
    End Function

End Class
