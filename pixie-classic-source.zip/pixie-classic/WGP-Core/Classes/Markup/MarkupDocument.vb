﻿
Public Class MarkupDocument

    ' Internal root element
    Private Root As New MarkupElement

    ' Internal collection of Elements
    Private Elements As System.Collections.Generic.List(Of MarkupElement)

    ' Internal XML document
    Private XmlDoc As New Xml.XmlDocument

    ' Constructor
    Sub New()
        Me.Root.Initialize(MarkupElement.SymbolID.XmlPage)
    End Sub

    ' Clear
    Public Sub Clear()
        Me.Elements.Clear()
    End Sub

    ' Access to element count
    Public ReadOnly Property Count As Integer
        Get
            Return Me.Elements.Count
        End Get
    End Property

    ' Add an element
    Public Sub Add(elem As MarkupElement)
        Me.Elements.Add(elem)
    End Sub

    ' Remove an element
    Public Function Remove(elem As MarkupElement) As Boolean
        Return Me.Elements.Remove(elem)
    End Function

    ' Remove an element
    Public Sub RemoveAt(index As Integer)
        Try
            Me.Elements.RemoveAt(index)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Compose
    Public Function Compose() As String
        Me.XmlDoc.RemoveAll()
        Dim elemRoot As Xml.XmlElement = Me.Root.CreateXml(Me.XmlDoc)
        Me.XmlDoc.AppendChild(elemRoot)
        Dim item As MarkupElement
        For Each item In Me.Elements
            Dim elemNode As Xml.XmlElement = item.CreateXml(Me.XmlDoc)
            elemRoot.AppendChild(elemNode)
        Next
        Return Me.XmlDoc.OuterXml()
    End Function

    ' Interpret
    Public Function Interpret(source As String) As Boolean
        ' TODO...
        Return False
    End Function

End Class

