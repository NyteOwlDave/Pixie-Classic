﻿
'
' StringList class
'
' Implements a simple named read/write list of strings.
'
' For a read-only list builder, see NamedStringList instead.
'

Public Class StringList
    Inherits System.Collections.Generic.List(Of String)

    ' Name of the string list
    Public Property Name As String

    ' Read only collection of items (interface)
    Public Interface IReadOnlyItems
        ReadOnly Property Count As Integer
        ReadOnly Property Item(index As Integer) As String
    End Interface

    ' Read only collection of items (implementation)
    Public Class Items
        Implements IReadOnlyItems
        Implements IEnumerable(Of String)

        ' Internal string list instance
        Private MyList As NCS.StringList

        ' Construction
        Public Sub New(Optional list As NCS.StringList = Nothing)
            If list Is Nothing Then
                Me.MyList = New NCS.StringList()
            Else
                Me.MyList = list
            End If
        End Sub

        ' Return the number of items in the string list
        Public ReadOnly Property Count As Integer Implements IReadOnlyItems.Count
            Get
                Return Me.MyList.Count
            End Get
        End Property

        ' Return an item from the string list
        Public ReadOnly Property Item(index As Integer) As String Implements IReadOnlyItems.Item
            Get
                Return Me.MyList(index)
            End Get
        End Property

        ' Add an item
        Public Sub Add(item As String)
            Me.MyList.Add(item.ToString)
        End Sub

        ' Add items from an enumerable type
        Public Sub AddFrom(items As IEnumerable)
            If items Is Nothing Then Return
            Dim e As IEnumerator = items.GetEnumerator()
            Do While e.MoveNext()
                Me.MyList.Add(e.Current.ToString)
            Loop
        End Sub

        ' Get string enumerator
        Public Function GetEnumerator() As IEnumerator(Of String) Implements IEnumerable(Of String).GetEnumerator
            Return Me.MyList.GetEnumerator()
        End Function

        ' Get object enumerator
        Public Function GetObjectEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
            Return Me.MyList.GetEnumerator()
        End Function

    End Class

    ' Construction
    Public Sub New(Optional name As String = "")
        Me.Name = name
    End Sub

    ' Construction
    Public Sub New(source As NamedStringList.IReadOnlyItems)
        If source IsNot Nothing Then
            Me.Name = source.Title
            Me.AddFrom(source)
        Else
            Me.Name = String.Empty
        End If
    End Sub

    ' Construction
    Public Sub New(source As System.Collections.ObjectModel.ReadOnlyCollection(Of String))
        Me.Name = String.Empty
        Me.AddFrom(source)
    End Sub

    ' Construction
    Public Sub New(source As String())
        Me.Name = String.Empty
        Me.AddFrom(source)
    End Sub

    ' Add from readonly collection of string
    Public Sub AddFrom(source As System.Collections.ObjectModel.ReadOnlyCollection(Of String))
        If source IsNot Nothing Then
            For Each s As String In source
                Me.Add(s)
            Next
        End If
    End Sub

    ' Add from unnamed string list
    Public Sub AddFrom(source As StringList.IReadOnlyItems)
        If source IsNot Nothing Then
            Dim count As Integer = source.Count
            For n As Integer = 1 To count
                MyBase.Add(source.Item(n - 1))
            Next
        Else
            Me.Name = String.Empty
        End If
    End Sub

    ' Add from named string list
    Public Sub AddFrom(source As NamedStringList.IReadOnlyItems)
        If source IsNot Nothing Then
            Dim count As Integer = source.Count
            For n As Integer = 1 To count
                MyBase.Add(source.Item(n - 1))
            Next
        Else
            Me.Name = String.Empty
        End If
    End Sub

    ' Add from string array
    Public Sub AddFrom(source As String())
        If source IsNot Nothing Then
            For Each s As String In source
                MyBase.Add(s)
            Next
        End If
    End Sub

End Class

