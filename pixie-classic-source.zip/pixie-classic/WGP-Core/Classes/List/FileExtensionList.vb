﻿
Public Class FileExtensionList
    Implements NamedStringList.IReadOnlyItems

    ' Internal list of extensions
    Private Extensions As New System.Collections.Generic.List(Of String)

    ' Name property
    Private MyName As String

    ' Construction
    Public Sub New(Optional name As String = "")
        Me.MyName = ""
    End Sub

    ' Clear the list
    Public Sub Clear()
        Me.Extensions.Clear()
    End Sub

    ' Number of extensions on the list
    Public ReadOnly Property Count As Integer Implements NamedStringList.IReadOnlyItems.Count
        Get
            Return Me.Extensions.Count
        End Get
    End Property

    ' Get the item at the specified index
    Public ReadOnly Property Item(index As Integer) As String Implements NamedStringList.IReadOnlyItems.Item
        Get
            If Me.IsIndexValid(index) Then
                Return Me.Extensions(index)
            Else
                Return String.Empty
            End If
        End Get
    End Property

    ' Access to name
    Public ReadOnly Property Name As String Implements NamedStringList.IReadOnlyItems.Title
        Get
            If Me.MyName.Length > 0 Then
                Return Me.MyName
            Else
                Return "Unnamed Extension List"
            End If
        End Get
    End Property

    ' Determine if an extension is contained in the list
    Public Function Contains(ext As String) As Boolean
        Dim item As String = Me.GetCanonicalExtension(ext)
        With Me.Extensions
            Return .Contains(item)
        End With
    End Function

    ' Add an extension to the list
    Public Sub Add(ext As String)
        Dim item As String = Me.GetCanonicalExtension(ext)
        With Me.Extensions
            If Not .Contains(item) Then
                .Add(item)
            End If
        End With
    End Sub

    ' Add from string array
    Public Sub Add(list() As String)
        If Not list Is Nothing Then
            For Each ext As String In list
                Me.Add(ext)
            Next
        End If
    End Sub

    ' Add from string list
    Public Sub Add(list As StringList)
        If Not list Is Nothing Then
            For Each ext As String In list
                Me.Add(ext)
            Next
        End If
    End Sub

    ' Add from another file extension list
    Public Sub Add(list As FileExtensionList)
        If Not list Is Nothing Then
            Dim count As Integer = list.Count
            Dim index As Integer
            For index = 0 To count - 1
                Me.Extensions.Add(list.Extensions.Item(index))
            Next
        End If
    End Sub

    ' Add an extension to the list, from a path name
    Public Sub AddFromPath(pathName As String)
        Dim loc As New FileLocation
        Try
            loc.PathName = pathName
            Me.Add(loc.Extension)
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

    ' Remove an extension from the list
    Public Sub Remove(ext As String)
        Dim item As String = Me.GetCanonicalExtension(ext)
        With Me.Extensions
            If .Contains(item) Then
                .Remove(item)
            End If
        End With
    End Sub

    ' Get canonicalized extension
    Public Function GetCanonicalExtension(ext As String) As String
        Return NCS.CodeFile.GetCanonicalExtension(ext)
    End Function

    ' Determine if index is valid
    Public Function IsIndexValid(index As Integer) As Boolean
        If (index < 0) Then Return False
        With Me.Extensions
            If (index >= .Count) Then
                Return False
            End If
        End With
        Return True
    End Function

    ' Append to string list
    Public Sub AppendTo(list As StringList)
        If Not list Is Nothing Then
            For Each ext In Me.Extensions
                list.Add(ext)
            Next
        End If
    End Sub

End Class

