﻿
'
' FileListBuilder class
'
' Builds a list of file or folder names (without recursion).
' Results can optionally be filtered by file name extension.
' Caller can choose which elements of location path names are returned.
'

Public Class FileListBuilder

    ' Flags
    Public Enum OptionKind
        FullPath
        TitleOnly
        TitleAndExtension
        ExtensionOnly
    End Enum

    ' Delegate for adding an item
    Private Delegate Sub AddItemHandler(list As NamedStringList.Items, pathName As String)

    ' Create a list of pathnames for files in a folder (optional extension filter)
    Public Shared Function Invoke(folder As String, kind As OptionKind, findSubfolders As Boolean, Optional filterExtension As String = "") _
        As NamedStringList.IReadOnlyItems
        Dim items As New NamedStringList.Items
        Try
            Dim ignoreExt As Boolean = True
            Dim ext As String = CanonicalizeExtension(filterExtension)
            If ext.Length > 0 Then
                ignoreExt = False
            End If
            Dim handler As AddItemHandler
            Select Case kind
                Case OptionKind.ExtensionOnly
                    If Not ignoreExt Then
                        Throw New Exception("ExtensionOnly option can't be used with an extension filter.")
                    End If
                    handler = AddressOf FileListBuilder.AddExtensionOnly
                Case OptionKind.FullPath
                    handler = AddressOf FileListBuilder.AddFullPath
                Case OptionKind.TitleAndExtension
                    handler = AddressOf FileListBuilder.AddTitleAndExtension
                Case OptionKind.TitleOnly
                    handler = AddressOf FileListBuilder.AddTitleOnly
                Case Else
                    Throw New Exception("Unhandled option kind : " & kind.ToString)
            End Select
            Dim files As System.Collections.ObjectModel.ReadOnlyCollection(Of String)
            If findSubfolders Then
                files = My.Computer.FileSystem.GetDirectories(folder)
            Else
                files = My.Computer.FileSystem.GetFiles(folder)
            End If
            For Each file In files
                If ignoreExt Then
                    handler.Invoke(items, file)
                Else
                    Dim fileExt As String = ExtractExtensionOnly(file)
                    If ext.CompareTo(fileExt) = 0 Then
                        handler.Invoke(items, file)
                    End If
                End If
            Next
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
        Return items
    End Function

    ' Add full path
    Private Shared Sub AddFullPath(list As NamedStringList.Items, pathName As String)
        list.Add(pathName)
    End Sub

    ' Add title only
    Private Shared Sub AddTitleOnly(list As NamedStringList.Items, pathName As String)
        list.Add(ExtractTitleOnly(pathName))
    End Sub

    ' Add title and extension
    Private Shared Sub AddTitleAndExtension(list As NamedStringList.Items, pathName As String)
        list.Add(ExtractTitleAndExtension(pathName))
    End Sub

    ' Add extension only
    Private Shared Sub AddExtensionOnly(list As NamedStringList.Items, pathName As String)
        list.Add(ExtractExtensionOnly(pathName))
    End Sub

    ' Extract folder
    Public Shared Function ExtractFolder(pathName As String) As String
        Try
            Return My.Computer.FileSystem.GetParentPath(pathName)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return String.Empty
        End Try
    End Function

    ' Extract title only
    Public Shared Function ExtractTitleOnly(pathName As String) As String
        Try
            Dim s As String = My.Computer.FileSystem.GetName(pathName)
            Dim pos As Integer = s.LastIndexOf(".")
            If pos >= 0 Then
                Return Left(s, pos)
            Else
                Return s
            End If
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return String.Empty
        End Try
    End Function

    ' Extract title and extension
    Public Shared Function ExtractTitleAndExtension(pathName As String) As String
        Try
            Return My.Computer.FileSystem.GetName(pathName)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return String.Empty
        End Try
    End Function

    ' Extract extension only
    Public Shared Function ExtractExtensionOnly(pathName As String) As String
        Try
            Dim pos As Integer = pathName.LastIndexOf(".")
            If pos >= 0 Then
                Return pathName.Remove(0, 1 + pos).ToLower()
            Else
                Return String.Empty
            End If
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return String.Empty
        End Try
    End Function

    ' Canonicalize extension
    Public Shared Function CanonicalizeExtension(extension As String) As String
        Try
            If extension.StartsWith(".") Then
                Return extension.Remove(0, 1).ToLower()
            Else
                Return extension.ToLower()
            End If
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return String.Empty
        End Try
    End Function

End Class

