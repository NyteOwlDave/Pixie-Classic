﻿
'
' AssemblyListBuilder
'
' Builds a list of .NET assembly names.
'

Public Class AssemblyListBuilder

    ' OptionFlags
    <Flags> Public Enum OptionFlags
        None = &H0
        FullName = &H1
    End Enum

    ' Invoke the list builder
    Public Shared Function Invoke(names As System.Reflection.AssemblyName(), flags As OptionFlags) _
        As NamedStringList.IReadOnlyItems
        Dim items As New NamedStringList.Items("Referenced Assemblies")
        Try
            For Each name In names
                If flags And OptionFlags.FullName Then
                    items.Add(name.FullName)
                Else
                    items.Add(name.Name)
                End If
            Next
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
        Return items
    End Function

    ' Get referenced assembly names
    Public Shared Function GetReferencedAssemblyNames(assy As System.Reflection.Assembly) As System.Reflection.AssemblyName()
        Try
            Return assy.GetReferencedAssemblies()
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return Nothing
        End Try
    End Function

    ' Internal assembly instance
    Private MyAssembly As System.Reflection.Assembly = Nothing

    ' Create new assembly list builder
    Public Sub New()
        Me.MyAssembly = System.Reflection.Assembly.GetCallingAssembly()
    End Sub

    ' Create new assembly list builder
    Public Sub New(assy As System.Reflection.Assembly)
        Me.MyAssembly = assy
        If Not Me.Initialized Then
            Me.MyAssembly = System.Reflection.Assembly.GetCallingAssembly()
        End If
    End Sub

    ' Whether an assembly instance is attached
    Public ReadOnly Property Initialized As Boolean
        Get
            If Me.MyAssembly Is Nothing Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    ' Currently attached assembly
    Public ReadOnly Property Assembly As System.Reflection.Assembly
        Get
            Return Me.MyAssembly
        End Get
    End Property

    ' Get referenced assemblies
    Public ReadOnly Property ReferencedAssemblies As System.Reflection.AssemblyName()
        Get
            Return AssemblyListBuilder.GetReferencedAssemblyNames(Me.Assembly)
        End Get
    End Property

    ' Invoke the builder
    Public Function Invoke(flags As OptionFlags) As NamedStringList.IReadOnlyItems
        Return AssemblyListBuilder.Invoke(Me.ReferencedAssemblies, flags)
    End Function

End Class

