﻿
'
' ReflectionListBuilder class
'
' Provides the basic mechanism for building a read-only list of members of an object type.
' Makes use of the System.Reflection namespace.
'

Public Class ReflectionListBuilder

    ' Invoke the builder
    Public Shared Function Invoke(type As System.Type, memberType As System.Reflection.MemberTypes) _
        As NamedStringList.IReadOnlyItems
        Try
            Dim results As New NamedStringList.Items(type.FullName)
            Dim e As IEnumerator
            e = type.GetMembers().GetEnumerator()
            Do While e.MoveNext()
                Dim info As System.Reflection.MemberInfo
                info = CType(e.Current, System.Reflection.MemberInfo)
                If info.MemberType = memberType Then
                    results.Add(info.Name)
                End If
            Loop
            Return results
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return Nothing
        End Try
    End Function

#If DEBUG Then

    ' Sample class
    Private Class SampleClass
        Public Property Dave As String
        Public Property Is_Really As Integer
        Public Property The_Awesome As Object
        Public Property NyteOwl As Object
        Dim Nope As String
        Public Sub ThisShouldNotAppear()
            DebugOut("Bummer")
        End Sub
        Public Function ThisShouldNotAppearEither()
            Return Nothing
        End Function
        Const NorThis As Integer = 0
    End Class

    ' Invoke the test
    Public Shared Sub InvokeTest()

        Dim list As NamedStringList.IReadOnlyItems
        list = ReflectionListBuilder.Invoke(GetType(SampleClass), Reflection.MemberTypes.Property)
        NamedStringList.EnumerateDump(list)

    End Sub

#End If

End Class
