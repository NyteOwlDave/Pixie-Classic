﻿
'
' PathListBuilder class
'
' Builds a list of hierarchical path names.
'
' This is pretty slick in that it uses the .NET nested class hierarchy as a model
' for a file system path name or other type of hierarchical symbolic path name.
' It basically crawls the hierarchy of nested types within a class or structure
' and emits a path for the names of each located enumeration member.
'
' For an example class that can be used to build the list, try the ExampleHierachy
' nested class.
'

Public Class PathListBuilder

    ' Option flags
    <Flags> Enum OptionFlags
        None = &H0
        LocationFromType = &H1
        FullName = &H2
    End Enum

#If DEBUG Then

    ' Example class
    Public Class ExampleHierarchy
        Structure FirstNestedStructure
            Enum MembersToEmit
                FirstMember
                SecondMember
            End Enum
            Structure SecondNestedStructure
                Enum MoreMembersToEmit
                    ThirdMember
                    FourthMember
                End Enum
            End Structure
        End Structure
    End Class

    ' Do an example
    Public Shared Function InvokeExample() As NamedStringList.IReadOnlyItems
        Dim builder As New PathListBuilder(".")
        Dim example As New PathListBuilder.ExampleHierarchy
        Dim exampleType As System.Type = example.GetType()
        Return builder.Invoke(exampleType.Name, exampleType)
    End Function

    ' Dump example
    Public Shared Sub TestExample()
        Dim results As NamedStringList.IReadOnlyItems = InvokeExample()
        Dim count As Integer = results.Count
        For n As Integer = 1 To count
            DebugOut("[TITLE] : " & results.Title)
            DebugOut(results.Item(n - 1))
        Next
    End Sub

#End If

    ' Pathname splitter
    Public Splitter As String = String.Empty

    ' Construction
    Public Sub New(Optional pathSplitter As String = "\")
        Me.Splitter = pathSplitter
    End Sub

    ' Primary entry point
    Public Function Invoke(location As String, baseType As Type, Optional flags As OptionFlags = OptionFlags.None) _
        As NamedStringList.IReadOnlyItems
        Dim root As String
        If flags And OptionFlags.LocationFromType Then
            If flags And OptionFlags.FullName Then
                root = baseType.FullName
            Else
                root = baseType.Name
            End If
        Else
            root = Trim(location)
        End If
        Dim list As New NamedStringList.Items(root)
        Me.CrawlNestedMembers(list, root, baseType)
        Return list
    End Function

    ' Create folders whose names are members of an enumerated Type
    Private Function CreateEnumFolders(list As NamedStringList.Items, location As String, enumType As Type) As Boolean
        Try
            Dim members As String()
            members = enumType.GetEnumNames()
            For Each name In members
                Dim folder As String = location & Me.Splitter & name
                list.Add(folder)
            Next
            Return True
        Catch ex As Exception
            SilentExceptionReport(ex)
            DebugOut("Failed to get enumeration members : " & enumType.FullName)
            Return False
        End Try
    End Function

    ' Crawl the hierarchy of nested Types and create folders for all enumerations
    Private Function CrawlNestedMembers(list As NamedStringList.Items, location As String, otherType As Type) As Boolean
        Try
            Dim ok As Boolean = True
            Dim members As System.Reflection.MemberInfo() = Nothing
            members = otherType.GetMembers()
            For Each info In members
                If IsNestedType(info) Then
                    Dim childName As String = info.Name
                    Dim childFolder As String
                    If location.Length > 0 Then
                        childFolder = location & Me.Splitter & childName
                    Else
                        childFolder = childName
                    End If
                    Dim childType As String = otherType.FullName & "+" & childName
                    Dim child As Object = otherType.Assembly.CreateInstance(childType)
                    Dim createdType As Type = child.GetType()
                    If createdType.IsEnum Then
                        ok = Me.CreateEnumFolders(list, location, createdType) And ok
                    Else
                        ok = Me.CrawlNestedMembers(list, childFolder, createdType) And ok
                    End If
                End If
            Next
            Return ok
        Catch ex As Exception
            SilentExceptionReport(ex)
            DebugOut("Failed to get class members : " & otherType.FullName)
            Return False
        End Try
    End Function

    ' Determine if a Type is a nested type
    Private Function IsNestedType(member As System.Reflection.MemberInfo) As Boolean
        Return member.MemberType And Reflection.MemberTypes.NestedType
    End Function

End Class

