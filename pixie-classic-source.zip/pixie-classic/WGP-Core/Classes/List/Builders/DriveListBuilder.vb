﻿
'
' DriveListBuilder class
'
' Provides the mechamism for building a readonly list of attached logical drives.
'

Public Class DriveListBuilder

    ' Create a list of pathnames for files in a folder (optional extension filter)
    Public Shared Function Invoke() _
        As NamedStringList.IReadOnlyItems
        Dim items As New NamedStringList.Items("Logical Drives")
        Dim drives = My.Computer.FileSystem.Drives
        For Each drive In drives
            items.Add(CanonicalizeDrive(drive.RootDirectory.FullName))
        Next
        Return items
    End Function

    ' Canonicalize drive name
    Public Shared Function CanonicalizeDrive(drive As String) As String
        Try
            Dim s As String = Trim(drive)
            If s.Length < 1 Then
                Throw New Exception("Drive string is empty.")
            End If
            If Not Char.IsLetter(s(0)) Then
                Throw New Exception("First character isn't alphabetic.")
            End If
            If s.Length < 2 Then
                Return Left(s, 1).ToLower() & ":"
            End If
            If s(1) <> ":" Then
                Throw New Exception("Second character isn't ':'.")
            End If
            Return Left(s, 2).ToLower()
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return String.Empty
        End Try
    End Function

#If DEBUG Then

    ' Invoke debug test
    Public Shared Sub InvokeTest()
        NamedStringList.EnumerateDump(DriveListBuilder.Invoke())
    End Sub

#End If

End Class

