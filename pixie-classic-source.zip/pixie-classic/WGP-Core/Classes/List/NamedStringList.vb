﻿
'
' NamedStringList class
'
' Provides the basic mechanism for generating read-only string lists.
'

Public NotInheritable Class NamedStringList

    ' Enumeration callback delegate
    Public Delegate Function EnumerationCallback(name As String) As Boolean

    ' Read only collection of item
    Public Interface IReadOnlyItems
        ReadOnly Property Title As String
        ReadOnly Property Count As Integer
        ReadOnly Property Item(index As Integer) As String
    End Interface

    ' List of strings
    Public Class Items
        Implements NamedStringList.IReadOnlyItems
        Implements INamedItemProperties
        Implements IEnumerable(Of String)

        ' Internal key instance
        Private MyKey As Guid = Guid.Empty

        ' Internal title instance
        Private MyTitle As String = String.Empty

        ' Members of the collection
        Private Members As New System.Collections.Generic.List(Of String)

        ' Construction
        Public Sub New(Optional title As String = "")
            Me.Rename(title)
            Me.MyKey = Guid.NewGuid()
        End Sub

        ' Construction
        Public Sub New(title As String, key As Guid)
            Me.Rename(title)
            Me.MyKey = key
        End Sub

        ' Clear the list
        Public Sub Clear()
            Me.Members.Clear()
        End Sub

        ' Add a member
        Public Sub Add(text As String)
            Me.Members.Add(Trim(text))
        End Sub

        ' Rename the list
        Public Sub Rename(title As String)
            Me.MyTitle = Trim(title)
        End Sub

        ' Access to the key
        Public ReadOnly Property ID As Guid Implements INamedItemProperties.Key
            Get
                Return Me.MyKey
            End Get
        End Property

        ' Number of members
        Public ReadOnly Property Count As Integer _
            Implements NamedStringList.IReadOnlyItems.Count
            Get
                Return Me.Members.Count
            End Get
        End Property

        ' Access to a member
        Public ReadOnly Property Item(index As Integer) As String _
            Implements NamedStringList.IReadOnlyItems.Item
            Get
                Try
                    Return Me.Members(index)
                Catch ex As Exception
                    Return String.Empty
                End Try
            End Get
        End Property

        ' Access title property
        Public ReadOnly Property Title As String Implements _
            NamedStringList.IReadOnlyItems.Title, INamedItemProperties.Name
            Get
                If Me.MyTitle.Length > 0 Then
                    Return Me.MyTitle
                Else
                    Return "Unnamed List"
                End If
            End Get
        End Property

        ' Access initialized property
        Public ReadOnly Property Initialized As Boolean Implements INamedItemProperties.Initialized
            Get
                If Me.ID <> Guid.Empty Then
                    Return True
                Else
                    Return False
                End If
            End Get
        End Property

        ' Enumerator for strings
        Public Function GetEnumerator() As IEnumerator(Of String) Implements IEnumerable(Of String).GetEnumerator
            Return Me.Members.GetEnumerator()
        End Function

        ' Enumerator for objects
        Public Function GetObjectEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
            Return Me.Members.GetEnumerator()
        End Function

    End Class

    ' Clone another read-only string list
    Public Shared Function Build(source As NamedStringList.IReadOnlyItems) As NamedStringList.IReadOnlyItems
        If source IsNot Nothing Then
            Dim result As New NamedStringList.Items(source.Title)
            Dim count As Integer = source.Count
            For n As Integer = 1 To count
                result.Add(source.Item(n - 1))
            Next
            Return result
        Else
            Return Nothing
        End If
    End Function

    ' Clone another read-only string list
    Public Shared Function Build(source As StringList.IReadOnlyItems, name As String) As NamedStringList.IReadOnlyItems
        If source IsNot Nothing Then
            Dim result As New NamedStringList.Items(name)
            Dim count As Integer = source.Count
            For n As Integer = 1 To count
                result.Add(source.Item(n - 1))
            Next
            Return result
        Else
            Return Nothing
        End If
    End Function

    ' Clone another read-only string list
    Public Shared Function Build(source As IEnumerable, name As String) As NamedStringList.IReadOnlyItems
        If source IsNot Nothing Then
            Dim result As New NamedStringList.Items(name)
            For Each item In source
                result.Add(item.ToString)
            Next
            Return result
        Else
            Return Nothing
        End If
    End Function

    ' Enumerate list
    Public Shared Sub Enumerate(list As NamedStringList.IReadOnlyItems, callback As NamedStringList.EnumerationCallback)
        Try
            Dim count As Integer = list.Count
            For n As Integer = 1 To count
                If Not callback.Invoke(list.Item(n - 1)) Then
                    Return
                End If
            Next
        Catch ex As Exception
            SilentExceptionReport(ex)
        End Try
    End Sub

#If DEBUG Then

    ' Enumerate list to debug listener
    Public Shared Sub EnumerateDump(list As NamedStringList.IReadOnlyItems)
        NamedStringList.Enumerate(list, AddressOf NamedStringList.EnumerateDumpHandler)
    End Sub

    ' Handler for enumeration to debug listener
    Private Shared Function EnumerateDumpHandler(name As String) As Boolean
        Debug.Print(name)
        Return True
    End Function

#End If

End Class

