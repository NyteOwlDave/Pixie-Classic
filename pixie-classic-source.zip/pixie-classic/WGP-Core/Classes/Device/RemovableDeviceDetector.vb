﻿
Public Class RemovableDeviceDetector

    ' Internal class for converting drive letters to integers
    Private Class DriveList
        Private ID As New System.Collections.Generic.List(Of Integer)
        Public Sub Initialize(driveList As IO.DriveInfo())
            Me.ID.Clear()
            If driveList Is Nothing Then Return
            Dim count As Integer = driveList.Count
            Me.ID.Capacity = count
            For Each drive In driveList
                Me.ID.Add(Me.GetDriveID(drive))
            Next
        End Sub
        Public Function GetDriveID(drive As IO.DriveInfo) As Integer
            Dim root As String = drive.RootDirectory.FullName.ToLower
            Dim letter As Char = root(0)
            Return CInt(AscW(letter))
        End Function
        Public Function ContainsID(id As Integer) As Boolean
            Return Me.ID.Contains(id)
        End Function
        Public ReadOnly Property Count As Integer
            Get
                Return Me.ID.Count
            End Get
        End Property
        Public ReadOnly Property Item(index) As Integer
            Get
                Try
                    Return Me.ID.Item(index)
                Catch ex As Exception
                    Return 0
                End Try
            End Get
        End Property
    End Class

    ' The list of drives previously attached
    Private PreviousDrives As IO.DriveInfo() = Nothing

    ' The list of drives currently attached
    Private CurrentDrives As IO.DriveInfo() = Nothing

    ' Initialization
    Public Sub Initialize()
        Me.PreviousDrives = IO.DriveInfo.GetDrives()
        Me.CurrentDrives = Me.PreviousDrives
    End Sub

    ' Detect all attached drives
    Public Sub DetectDrives()
        Me.PreviousDrives = Me.CurrentDrives
        Me.CurrentDrives = IO.DriveInfo.GetDrives()
    End Sub

    ' Whether the instance has been initialized
    Public ReadOnly Property Initialized As Boolean
        Get
            If Me.PreviousDrives Is Nothing Then Return False
            If Me.CurrentDrives Is Nothing Then Return False
            Return True
        End Get
    End Property

    ' The number of drives changed since the last check
    Public ReadOnly Property CountChanged As Boolean
        Get
            If Not Me.Initialized Then Return False
            Dim countOld As Integer = Me.PreviousDrives.Count
            Dim countNew As Integer = Me.CurrentDrives.Count
            If countOld <> countNew Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    ' The number of drives increased since the last check
    Public ReadOnly Property CountIncreased As Boolean
        Get
            If Not Me.Initialized Then Return False
            Dim countOld As Integer = Me.PreviousDrives.Count
            Dim countNew As Integer = Me.CurrentDrives.Count
            If countOld < countNew Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    ' The number of drives decreased since the last check
    Public ReadOnly Property CountDecreased As Boolean
        Get
            If Not Me.Initialized Then Return False
            Dim countOld As Integer = Me.PreviousDrives.Count
            Dim countNew As Integer = Me.CurrentDrives.Count
            If countOld > countNew Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    ' Get the device that was detected
    Public Function GetDetectedDevice() As IO.DriveInfo
        If Not Me.CountIncreased Then Return Nothing
        Dim oldDrives As New DriveList
        oldDrives.Initialize(Me.PreviousDrives)
        Dim newDrives As New DriveList
        newDrives.Initialize(Me.CurrentDrives)
        Dim count As Integer = newDrives.Count
        Dim index As Integer
        Dim id As Integer
        For index = 1 To count
            id = newDrives.Item(index - 1)
            If Not oldDrives.ContainsID(id) Then
                Dim drive As IO.DriveInfo = Me.CurrentDrives(index - 1)
                If drive.DriveType <> IO.DriveType.Removable Then
                    DebugOut("WARNING: Detected device is not a removable drive.")
                End If
                Return drive
            End If
        Next
        Return Nothing
    End Function

End Class
