﻿Public Class DeviceGroup

End Class
