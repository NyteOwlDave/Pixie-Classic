﻿
'
' TraceListener class
'
' Provides a thread safe implemenation of ITraceListener which caches
' messages in a StringList for later retrieval using IReadOnlyItems.
'

Public Class TraceListener
    Implements ITraceListener

    ' Busy Flag
    Private MyBusyFlag As Boolean = False

    ' Cached messages
    Private MyMessages As New StringList

    ' Wait for busy flag to clear
    Private Sub Wait()
        While Me.Busy
            System.Threading.Thread.Sleep(1)
        End While
    End Sub

    ' Clear all messages
    Public Sub Clear()
        Me.Wait()
        Try
            Me.MyBusyFlag = True
            Me.MyMessages.Clear()
        Finally
            Me.MyBusyFlag = False
        End Try
    End Sub

    ' Whether the 
    Public ReadOnly Property Busy As Boolean
        Get
            Return Me.MyBusyFlag
        End Get
    End Property

    ' Report a message
    Public Sub Report(message As String) Implements ITraceListener.Report
        Me.Wait()
        Try
            Me.MyBusyFlag = True
            Me.MyMessages.Add(message)
        Finally
            Me.MyBusyFlag = False
        End Try
    End Sub

    ' Get cached messages
    Public Function GetCachedMessages() As StringList.IReadOnlyItems
        Me.Wait()
        Try
            Me.MyBusyFlag = True
            Dim results As New StringList.Items(Me.MyMessages)
            Me.MyMessages.Clear()
            Return results
        Finally
            Me.MyBusyFlag = False
        End Try
    End Function

End Class

