﻿
'
' TraceReporter class
'
' Provides a basic mechanism for wrapping calls to an ITraceListener
' in an exception handler. This quietly handles any exceptions that
' the ITraceListener might throw by catching them and reporting their
' message to the Debug window instead.
'

Public Class TraceReporter

    ' Instance of trace listener to report to
    Private Tracer As ITraceListener

    ' Construction
    Public Sub New(listen As ITraceListener)
        Me.Tracer = listen
    End Sub

    ' Safely do the report
    Public Sub Report(message As String)
        If Me.Tracer IsNot Nothing Then
            Try
                Me.Tracer.Report(message)
            Catch ex As Exception
                SilentExceptionReport(ex)
            End Try
        End If
    End Sub

End Class

