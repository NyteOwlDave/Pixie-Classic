﻿
'
' NetworkDownload class
'
' Provides an advanced mechanism for downloading a file from a URI source
' to a folder on the local file system.
'
' Provides an event for progress reporting/cancellation.
'
' Optionally writes textual messages to an ITraceListener instance.
'

Public Class NetworkDownload

    ' Progress report event
    Public Event ProgressChanged(sender As NetworkDownload, status As StreamBlockTransfer.IProgress)

    ' Progess reporting
    Private WithEvents StreamBlockTransferInstance As StreamBlockTransfer = Nothing

    ' Internal state class
    Private Class InternalState
        Private Reporter As TraceReporter = Nothing
        Public SourceUri As Uri = Nothing
        Public TargetLocation As String = String.Empty
        Public TransferLength As Integer = 0
        Public TransferContentType As String = String.Empty
        Public Sub ReportMessagesTo(listen As ITraceListener)
            Me.Reporter = New TraceReporter(listen)
        End Sub
        Public Sub Report(message As String)
            ' Debug.Print("[NETWORK DOWNLOAD MESSAGE] :: " & message)
            If Me.Reporter IsNot Nothing Then
                Me.Reporter.Report(message)
            End If
        End Sub
    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Report a message to the trace listener (if any)
    Public Sub Report(message As String)
        Me.State.Report(message)
    End Sub

    ' Access to content type (after download)
    Public ReadOnly Property ContentType As String
        Get
            Return Me.State.TransferContentType
        End Get
    End Property

    ' Access to target file location (after download)
    Public ReadOnly Property TargetLocation As String
        Get
            Return Me.State.TargetLocation
        End Get
    End Property

    ' Construction
    Public Sub New(Optional listener As ITraceListener = Nothing)
        Me.State.ReportMessagesTo(listener)
    End Sub

    ' Download the file
    Public Function Download(sourceUri As Uri, targetFolder As String) As Boolean

        ' Result of the operation
        Dim ok As Boolean = False

        Try

            ' Begin the transfer
            Me.ReportCaption("begin download")

            ' Initialize the internal state
            With Me.State
                .SourceUri = sourceUri
                .TargetLocation = String.Empty
            End With

            ' Check the source Uri
            If sourceUri Is Nothing Then
                Me.Report("The source URI reference can't be null.")
                Return False
            End If

            ' Report source file location
            Me.Report("Source file location : " & sourceUri.AbsoluteUri)

            ' Check the target folder
            targetFolder = Trim(targetFolder)
            If Not NCS.FolderExists(targetFolder) Then
                Me.Report("The target folder doesn't exist : " & targetFolder)
                Return False
            End If

            ' Compose the target pathname
            Try
                With My.Computer.FileSystem
                    Dim sourceTitleAndExtension As String
                    sourceTitleAndExtension = .GetName(sourceUri.AbsolutePath)
                    Dim file As String = NCS.UriCodec.FilterEscapedCharacters(sourceTitleAndExtension)
                    Me.State.TargetLocation = .CombinePath(targetFolder, file)
                    Me.Report("Target file location : " & Me.State.TargetLocation)
                End With
            Catch ex As Exception
                Me.Report("Error composing target pathname : " & ex.Message)
                Return False
            End Try

            ' Create the web request object
            Dim request As Net.WebRequest = Net.WebRequest.Create(sourceUri)

            ' Create the web response object
            Dim response As Net.WebResponse = request.GetResponse()

            Try

                ' Get the source stream
                Dim source As IO.Stream = response.GetResponseStream

                ' Get the transfer length
                Dim length As Long = response.ContentLength
                Me.State.TransferLength = length

                ' Get the transfer type
                Dim content As String = response.ContentType
                Me.State.TransferContentType = content

                ' Report length and type
                Me.Report("Content length : " & length.ToString)
                Me.Report("Content type   : " & content)

                ' Report more information about the response
                If response.IsFromCache Then
                    Me.Report("Response is from cache.")
                End If
                If response.IsMutuallyAuthenticated Then
                    Me.Report("Response is mutually authenticated.")
                End If
                Me.ReportResponseHeaders(response)

                ' Begin the transfer
                Me.ReportCaption("download results")

                ' If the stream doesn't support seek operations...
                If Not source.CanSeek Then
                    ' Treat is as a simple text file, such as html/xml/txt, etc.
                    Me.Report("The response stream doesn't support seek operations.")
                    Dim reader As New IO.StreamReader(source)
                    Dim file As New TextFile
                    file.LocationString = Me.State.TargetLocation
                    file.Content = reader.ReadToEnd()
                    reader.Close()
                    If file.Write() Then
                        Me.State.TransferLength = file.Content.Length
                        Me.Report("Response file size : " & Me.State.TransferLength)
                        Me.Report("The download succeeded.")
                        Return True
                    Else
                        Me.Report("The download failed.")
                        Return False
                    End If
                Else
                    Me.Report("The response stream supports seek operations.")
                    Me.Report("Using block transfer mode on the response stream.")
                    Me.Report("Block size : " & StreamBlockTransfer.BlockSizeDefault.ToString)
                End If

                ' Create the target file and o/p stream
                Dim fs As IO.FileStream = New IO.FileStream(Me.State.TargetLocation, IO.FileMode.Create)
                Dim target As New IO.BinaryWriter(fs)

                ' Create the stream block transfer instance and attach a reporting event hanlder
                Dim xfr As New StreamBlockTransfer(response.GetResponseStream, target.BaseStream)
                Me.StreamBlockTransferInstance = xfr

                ' Do the transfer
                ok = xfr.Transfer(StreamBlockTransfer.BlockSizeDefault)

                ' Report stream transfer results
                Me.Report("Block transfer result : " & xfr.ErrorMessage)

                ' Close the o/p file stream
                target.Close()

            Catch ex As Exception

                Me.Report("Source or target stream creation failed : " & ex.Message)

            Finally

                ' Close the web response object
                response.Close()

            End Try

        Catch ex As Exception

            Me.Report("Unexpected download exception : " & ex.Message)

        End Try

        ' Return success/fail
        Return ok

    End Function

    ' Report caption
    Private Sub ReportCaption(title As String)
        Me.Report("")
        Me.Report("[" & title.ToUpper & "]")
    End Sub

    ' Report response headers
    Private Sub ReportResponseHeaders(response As System.Net.WebResponse)
        Me.ReportCaption("response headers")
        Dim headers As String() = response.Headers.AllKeys
        For Each key As String In headers
            Me.Report(key & " : " & response.Headers(key))
        Next
    End Sub

    ' Handler for progress reports from the stream block transfer object
    Private Sub StreamBlockTransferInstance_ProgressChanged(progress As StreamBlockTransfer.IProgress) _
        Handles StreamBlockTransferInstance.ProgressChanged
        Try
            RaiseEvent ProgressChanged(Me, progress)
        Catch ex As Exception
            Me.Report("Error during handling progress report : " & ex.Message)
        End Try
    End Sub

End Class

