﻿
'
' Conceptual Network IPv4 classes
'
' Provides a paradigm for narrowing the address space for the .NET network
' classes to only IPv4, hence prettifying and simplifying some coding.
'

Imports System.Net
Imports System.Net.Sockets
Imports System.Text

Namespace Conceptual.Network.IPv4

    ' IP4 address class
    ' Obtains an Ip4 address from an object that may map to both ip4 and ip6 addresses
    Public NotInheritable Class Ip4Address

        ' Internal instance of ip4 address
        Private MyIP As IPAddress

        ' Construction
        Public Sub New(hostNameOrAddress As String)
            Me.Resolve(hostNameOrAddress)
        End Sub

        ' Construction
        Public Sub New(ip As IPAddress)
            Me.Resolve(ip)
        End Sub

        ' Construction
        Public Sub New(ep As IPEndPoint)
            Me.Resolve(ep)
        End Sub

        ' Construction
        Public Sub New(entry As IPHostEntry)
            Me.Resolve(entry)
        End Sub

        ' Resolve ip4 from host name or ip address
        Public Sub Resolve(hostNameOrAddress As String)
            Dim entry As IPHostEntry = Dns.GetHostEntry(hostNameOrAddress)
            Me.Resolve(entry.AddressList)
        End Sub

        ' Resolve ip4 from ip address
        Public Sub Resolve(ip As IPAddress)
            If IsIp4(ip) Then
                Me.MyIP = ip
            Else
                Resolve(ip.ToString)
            End If
        End Sub

        ' Resolve ip4 from ip endpoint
        Public Sub Resolve(ep As IPEndPoint)
            Me.Resolve(ep.Address)
        End Sub

        ' Resolve ip4 from ip host entry
        Public Sub Resolve(entry As IPHostEntry)
            Me.Resolve(entry.HostName)
        End Sub

        ' Resolve ip4 from ip address array
        Public Sub Resolve(addresses As IPAddress())
            Try
                Dim ip4 As IPAddress = Ip4Address.GetIp4(addresses)
                If ip4 Is Nothing Then
                    Throw New Exception("No ip4 address was detected.")
                Else
                    Me.MyIP = ip4
                End If
            Catch ex As Exception
                Me.MyIP = Nothing
            End Try
        End Sub

        ' Access to internal instance of ip4 address
        Public ReadOnly Property Address As IPAddress
            Get
                Return Me.MyIP
            End Get
        End Property

        ' String representation of the instance
        Public Overrides Function ToString() As String
            Return Me.Address.ToString()
        End Function

        ' Initialization
        Public Shared Function GetIp4(addresses As IPAddress()) As IPAddress
            For Each ip As IPAddress In addresses
                If IsIp4(ip) Then
                    Return ip
                End If
            Next
            Return Nothing
        End Function

        ' See if an address is Ip4 format
        Public Shared Function IsIp4(ip As IPAddress) As Boolean
            Dim address As String = ip.ToString
            If address.Contains(":") Then
                Return False
            Else
                Return True
            End If
        End Function

    End Class ' Ip4Locator

    ' IP4 host name class
    ' Creates and initializes an IP4 entry for an arbitrary host
    Public NotInheritable Class Ip4HostEntry

        ' Internal instance of host name
        Private MyName As String

        ' Internal instance of ip4 address
        Private MyAddress As IPAddress

        ' Construction
        Public Sub New(entry As IPHostEntry)
            Me.Resolve(entry)
        End Sub

        ' Construction
        Public Sub New(addresses As IPAddress())
            Me.Resolve(addresses)
        End Sub

        ' Construction
        Public Sub New(hostNameOrAddress As String)
            Me.Resolve(hostNameOrAddress)
        End Sub

        ' Construction
        Public Sub New(ip As IPAddress)
            Me.Resolve(ip)
        End Sub

        ' Construction
        Public Sub New(ep As IPEndPoint)
            Me.Resolve(ep)
        End Sub

        ' Construction
        Public Sub New(ip4 As Ip4Address)
            Me.Resolve(ip4)
        End Sub

        ' Construction
        Public Sub New(ep4 As Ip4Endpoint)
            Me.Resolve(ep4)
        End Sub

        ' Clear
        Public Sub Clear()
            Me.MyName = String.Empty
            Me.MyAddress = Nothing
        End Sub

        ' Internal host name resolver
        Private Sub ResolveHostName()
            Try
                Dim entry As IPHostEntry = Dns.GetHostEntry(Me.Address.ToString)
                Me.MyName = entry.HostName
            Catch ex As Exception
                Me.MyName = String.Empty
            End Try
        End Sub

        ' Resolve ip4 address
        Public Sub Resolve(entry As IPHostEntry)
            Me.MyName = entry.HostName
            Me.MyAddress = Ip4Address.GetIp4(entry.AddressList)
        End Sub

        ' Resolve host name and ip4 address
        Public Sub Resolve(addresses As IPAddress())
            Me.MyAddress = Ip4Address.GetIp4(addresses)
            Me.ResolveHostName()
        End Sub

        ' Resolve ip4 address
        Public Sub Resolve(hostNameOrAddress As String)
            Try
                Dim entry As IPHostEntry = Dns.GetHostEntry(hostNameOrAddress)
                Me.Resolve(entry)
            Catch ex As Exception
                Me.Clear()
            End Try
        End Sub

        ' Resolve host name and ip4 address
        Public Sub Resolve(ip As IPAddress)
            Me.Resolve(ip.ToString)
        End Sub

        ' Resolve host name and ip4 address
        Public Sub Resolve(ep As IPEndPoint)
            Me.Resolve(ep.Address.ToString)
        End Sub

        ' Resolve host name and ip4 address
        Public Sub Resolve(ip4 As Ip4Address)
            Try
                Me.MyAddress = ip4.Address
                Me.ResolveHostName()
            Catch ex As Exception
                Me.MyName = String.Empty
            End Try
        End Sub

        ' Resolve host name and ip4 address
        Public Sub Resolve(ep4 As Ip4Endpoint)
            Try
                Me.MyAddress = ep4.Address
                Me.ResolveHostName()
            Catch ex As Exception
                Me.MyName = String.Empty
            End Try
        End Sub

        ' Access to internal instance of host name
        Public ReadOnly Property HostName As String
            Get
                If Me.MyName.Length > 0 Then
                    Return Me.MyName
                End If
                If Me.MyAddress IsNot Nothing Then
                    Return Me.MyAddress.ToString
                End If
                Return String.Empty
            End Get
        End Property

        ' Access to internal instance of ip4 address
        Public ReadOnly Property Address As IPAddress
            Get
                Return Me.MyAddress
            End Get
        End Property

        ' String representation of the instance
        Public Overrides Function ToString() As String
            Return Me.HostName
        End Function

    End Class ' Ip4HostEntry

    ' IP4 Endpoint class
    ' Creates and initializes an IP4 endpoint for an arbitrary host
    Public NotInheritable Class Ip4Endpoint

        ' Internal instance of ip4 address
        Private MyAddress As IPAddress

        ' Internal instance of ip4 address
        Private MyPort As Integer

        ' Construction
        Public Sub New(hostNameOrAddress As String, port As Integer)
            Me.Resolve(hostNameOrAddress, port)
        End Sub

        ' Construction
        Public Sub New(ip As IPAddress, port As Integer)
            Me.Resolve(ip, port)
        End Sub

        ' Construction
        Public Sub New(ep As IPEndPoint, port As Integer)
            Me.Resolve(ep, port)
        End Sub

        ' Construction
        Public Sub New(entry As IPHostEntry, port As Integer)
            Me.Resolve(entry, port)
        End Sub

        ' Construction
        Public Sub New(ip4 As Ip4Address, port As Integer)
            Me.Resolve(ip4, port)
        End Sub

        ' Construction
        Public Sub New(ep4 As Ip4Endpoint, port As Integer)
            Me.Resolve(ep4, port)
        End Sub

        ' Construction
        Public Sub New(entry4 As Ip4HostEntry, port As Integer)
            Me.Resolve(entry4, port)
        End Sub

        ' Construction
        Public Sub New(addresses As IPAddress(), port As Integer)
            Me.Resolve(addresses, port)
        End Sub

        ' Resolve from host name or ip address
        Public Sub Resolve(hostNameOrAddress As String, port As Integer)
            Me.MyPort = port
            Dim ip4 As New Ip4Address(hostNameOrAddress)
            Me.MyAddress = ip4.Address
        End Sub

        ' Resolve from ip address
        Public Sub Resolve(ip As IPAddress, port As Integer)
            Me.Resolve(ip.ToString(), port)
        End Sub

        ' Resolve from ip endpoint
        Public Sub Resolve(ep As IPEndPoint, port As Integer)
            Me.Resolve(ep.Address, port)
        End Sub

        ' Resolve from ip host entry
        Public Sub Resolve(entry As IPHostEntry, port As Integer)
            Me.Resolve(entry.AddressList, port)
        End Sub

        ' Resolve from ip4 address
        Public Sub Resolve(ip4 As Ip4Address, port As Integer)
            Me.MyPort = port
            Me.MyAddress = ip4.Address
        End Sub

        ' Resolve from ip4 endpoint
        Public Sub Resolve(ep4 As Ip4Endpoint, port As Integer)
            Me.MyPort = port
            Me.MyAddress = ep4.Address
        End Sub

        ' Resolve from ip4 host entry
        Public Sub Resolve(entry4 As Ip4HostEntry, port As Integer)
            Me.MyPort = port
            Me.MyAddress = entry4.Address
        End Sub

        ' Resolve from ip4 address array
        Public Sub Resolve(addresses As IPAddress(), port As Integer)
            Me.MyPort = port
            Me.MyAddress = Ip4Address.GetIp4(addresses)
        End Sub

        ' Access to internal instance of ip4 endpoint
        Public ReadOnly Property Address As IPAddress
            Get
                Return Me.MyAddress
            End Get
        End Property

        ' Access to internal instance of port
        Public ReadOnly Property Port As Integer
            Get
                Return Me.MyPort
            End Get
        End Property

        ' String representation of the instance
        Public Overrides Function ToString() As String
            Return New IPEndPoint(Me.Address, Me.Port).ToString
        End Function

    End Class ' Ip4Endpoint

End Namespace ' Conceptual.Network.IPv4


