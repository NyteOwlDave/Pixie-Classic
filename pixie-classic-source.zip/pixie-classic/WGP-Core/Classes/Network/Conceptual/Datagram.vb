﻿
'
' Conceptual Network datagram classes
'
' Provides a basic mechanism for encoding/dispatching datagrams
'

Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports NCS.Conceptual.Network.IPv4

Namespace Conceptual.Network.Datagram

    ' Datagram client dispatcher class
    ' Posts a datagram to an arbitrary host and port using various encoding methods
    Public NotInheritable Class DatagramClientDispatcher

        ' Internal UDP client instance
        Private MyClient As UdpClient

        ' Construction
        Public Sub New(hostName As String, port As Integer)
            Dim ep As New Ip4Endpoint(hostName, port)
            Me.MyClient = New UdpClient
            Me.MyClient.Connect(ep.Address, ep.Port)
        End Sub

        ' Access to the internal UPD client instance
        Public ReadOnly Property Client As UdpClient
            Get
                Return Me.MyClient
            End Get
        End Property

        ' String representation for this instance
        Public Overrides Function ToString() As String
            Return Me.Client.ToString
        End Function

        ' Post a datagram to the current UDP client's IP4 endpoint
        Public Sub Post(packet As Byte())
            Try
                Dim count As Integer = packet.Length
                If Me.Client.Send(packet, count) <> count Then
                    Throw New Exception("Didn't send the entire packet.")
                End If
            Catch ex As Exception
                Throw New Exception("Failed to post datagram packet.", ex)
            End Try
        End Sub

    End Class ' DatagramClientDispatcher

    ' Datagram transmitter module
    ' Transmits datagrams using various encoding schemes
    Public Module DatagramTransmitterModule

        ' Transmit an ascii string
        Public Sub TransmitAscii(dispatch As DatagramClientDispatcher, message As String)
            Try
                dispatch.Post(Encoding.ASCII.GetBytes(message))
            Catch ex As Exception
                Throw New Exception("Failed to post ASCII text.", ex)
            End Try
        End Sub

        ' Transmit a unicode string
        Public Sub TransmitUnicode(dispatch As DatagramClientDispatcher, message As String)
            Try
                dispatch.Post(Encoding.Unicode.GetBytes(message))
            Catch ex As Exception
                Throw New Exception("Failed to post Unicode text.", ex)
            End Try
        End Sub

        ' Transmit a unicode string in reverse byte order
        Public Sub TransmitUnicodeBigEndian(dispatch As DatagramClientDispatcher, message As String)
            Try
                dispatch.Post(Encoding.BigEndianUnicode.GetBytes(message))
            Catch ex As Exception
                Throw New Exception("Failed to post big-endian Unicode text.", ex)
            End Try
        End Sub

        ' Transmit a string using the current code page for the OS
        Public Sub TransmitLocaleCodePage(dispatch As DatagramClientDispatcher, message As String)
            Try
                dispatch.Post(Encoding.Default.GetBytes(message))
            Catch ex As Exception
                Throw New Exception("Failed to post locale code page text.", ex)
            End Try
        End Sub

        ' Transmit a UTF32 string
        Public Sub TransmitUtf32(dispatch As DatagramClientDispatcher, message As String)
            Try
                dispatch.Post(Encoding.UTF32.GetBytes(message))
            Catch ex As Exception
                Throw New Exception("Failed to post UTF32 text.", ex)
            End Try
        End Sub

        ' Transmit a UTF8 string
        Public Sub TransmitUtf8(dispatch As DatagramClientDispatcher, message As String)
            Try
                dispatch.Post(Encoding.UTF8.GetBytes(message))
            Catch ex As Exception
                Throw New Exception("Failed to post UTF8 text.", ex)
            End Try
        End Sub

        ' Transmit a UTF7 string
        Public Sub TransmitUtf7(dispatch As DatagramClientDispatcher, message As String)
            Try
                dispatch.Post(Encoding.UTF7.GetBytes(message))
            Catch ex As Exception
                Throw New Exception("Failed to post UTF7 text.", ex)
            End Try
        End Sub

    End Module ' DatagramTransmitterModule

End Namespace ' 
