﻿
Public Class LocalNetwork

    Private _stationDictionary As New System.Collections.Generic.Dictionary(Of Guid, NCS.LocalNetworkStation)

    Public ReadOnly Property Stations As System.Collections.Generic.Dictionary(Of Guid, NCS.LocalNetworkStation)
        Get
            Return _stationDictionary
        End Get
    End Property

    Public Function CreateStation(name As String) As NCS.LocalNetworkStation

        Dim station As New NCS.LocalNetworkStation
        station.Name = name
        Me.Stations.Add(station.ID, station)
        Return station

    End Function

    Public Sub DiscoverStations()
        ' TODO - LocalNetwork.DiscoverStations()
        Me.Stations.Clear()
    End Sub

    Public Function GetReverseLookupTable() As System.Collections.Generic.Dictionary(Of String, Guid)

        Dim table As New System.Collections.Generic.Dictionary(Of String, Guid)

        For Each item In Me.Stations

            Dim key = item.Value.Name
            Dim value = item.Value.ID
            table.Add(key, value)

        Next

        Return table

    End Function

    Public Sub Save(pathName As String)

        Dim content As String = Me.ToXml()
        FileIO.FileSystem.WriteAllText(pathName, content, False)

    End Sub

    Public Sub Load(pathName As String)

        Dim content As String = FileIO.FileSystem.ReadAllText(pathName)
        Me.ParseXml(content)

    End Sub

    Public Function ToXml() As String

        ' TODO - LocalNetwork.ToXml()
        Return ""

    End Function

    Private Sub ParseXml(content As String)

        ' TODO - LocalNetwork.ParseXml()

    End Sub

End Class
