﻿
Public Class LocalNetworkStation

    Public ID As Guid = Guid.NewGuid
    Public Name As String

    Private _shareDictionary As New System.Collections.Generic.Dictionary(Of Guid, NCS.LocalNetworkShare)

    Public ReadOnly Property Shares As System.Collections.Generic.Dictionary(Of Guid, NCS.LocalNetworkShare)
        Get
            Return _shareDictionary
        End Get
    End Property

    Public Function CreateShare(address As String) As NCS.LocalNetworkShare

        Dim share As New NCS.LocalNetworkShare
        share.FriendlyName = LocalNetworkStation.GetNameFromPath(address)
        share.Location = address
        Me.Shares.Add(share.ID, share)
        Return share

    End Function

    Public Function GetReverseLookupTable() As System.Collections.Generic.Dictionary(Of String, Guid)

        Dim table As New System.Collections.Generic.Dictionary(Of String, Guid)

        For Each item In Me.Shares

            Dim key = item.Value.FriendlyName
            Dim value = item.Value.ID
            table.Add(key, value)

        Next

        Return table

    End Function

    Public Sub DiscoverShares()
        'TODO - LocalNetworkStation.DiscoverShares()
        Me.Shares.Clear()
    End Sub

    Public Sub Save(pathName As String)

        Dim content As String = Me.ToXml()
        FileIO.FileSystem.WriteAllText(pathName, content, False)

    End Sub

    Public Sub Load(pathName As String)

        Dim content As String = FileIO.FileSystem.ReadAllText(pathName)
        Me.ParseXml(content)

    End Sub

    Public Function ToXml() As String

        ' TODO - LocalNetworkStation.ToXml()
        Return ""

    End Function

    Private Sub ParseXml(content As String)

        ' TODO - LocalNetworkStation.ParseXml()

    End Sub

    Public Shared Function GetNameFromPath(address As String) As String

        ' TODO - LocalNetworkStation.GetNameFromPath()
        Return address

    End Function

End Class

