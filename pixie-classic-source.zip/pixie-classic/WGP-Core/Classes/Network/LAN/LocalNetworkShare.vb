﻿
Public Class LocalNetworkShare

    Public ID As Guid = Guid.NewGuid
    Public FriendlyName As String
    Public Location As String

    Public Function Exists() As Boolean
        Return LocalNetworkShare.ShareExists(Me.Location)
    End Function

    Public Shared Function ShareExists(address As String) As Boolean
        ' TODO - determine if a network share exists
        Return False
    End Function

End Class
