﻿
'
' UriCodecAssistant class
'
' Assists in encoding/decoding YouTopia URIs.
'

Public Class UriCodec

    ' Protocol token
    Public Const ProtocolToken As String = "youtopia"

    ' Target
    Public Target As Uri = Nothing

    ' Initialization
    Public Function Initialize(target As Uri) As Boolean
        Me.Target = target
        Return Me.Initialized
    End Function

    ' Whether or not the target is initialized
    Public ReadOnly Property Initialized As Boolean
        Get
            If Me.Target Is Nothing Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    ' Whether or not the target is using the YouTopia protocol
    Public ReadOnly Property IsYouTopiaProtocol As Boolean
        Get
            Dim token As String = Me.Protocol
            If token <> ProtocolToken Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    ' Access to the target's protocol
    Public ReadOnly Property Protocol As String
        Get
            If Me.Initialized Then
                Return Me.Target.GetComponents(UriComponents.Scheme, UriFormat.Unescaped).ToLower
            Else
                Return ""
            End If
        End Get
    End Property

    ' Access to the command
    Public ReadOnly Property Command As String
        Get
            If Me.Initialized Then
                Return Me.Target.GetComponents(UriComponents.Host, UriFormat.Unescaped).ToLower
            Else
                Return ""
            End If
        End Get
    End Property

    ' Access to the command's arguments
    Public ReadOnly Property Arguments As String
        Get
            If Me.Initialized Then
                Return Me.Target.GetComponents(UriComponents.Query, UriFormat.UriEscaped)
            Else
                Return ""
            End If
        End Get
    End Property

    ' Compose URI using the YouTopia protocol (arguments are already escaped)
    Public Shared Function ComposeEscaped(command As String, arguments As String) As Uri
        Try
            Return New Uri(ProtocolToken & "://" & command.ToLower & "?" & arguments)
        Catch ex As Exception
            DebugOut("Failed to compose URI:")
            SilentExceptionReport(ex)
            Return Nothing
        End Try
    End Function

    ' Compose URI using the YouTopia protocol (argments haven't been escaped yet)
    Public Shared Function ComposeUnescaped(command As String, arguments As String) As Uri
        Dim safeArgs As String = ComposeArguments(arguments)
        Return ComposeEscaped(command, safeArgs)
    End Function

    ' Compose arguments
    Public Shared Function ComposeArguments(args As String) As String
        Const Punctuation As String = "-_.!~*'()"
        Dim result As String = ""
        Dim token As String
        Dim count As Integer = args.Length
        For n As Integer = 1 To count
            token = args(n - 1)
            If Char.IsLetterOrDigit(token) Then
                result = result & token
            ElseIf Punctuation.Contains(token) Then
                result = result & token
            Else
                result = result & ComposeReservedCharacter(token)
            End If
        Next
        Return result
    End Function

    ' Compose reserved character
    Public Shared Function ComposeReservedCharacter(ch As Char) As String
        Dim code As String = Hex(AscW(ch)).ToLower()
        If code.Length = 2 Then
            Return "%" & code
        Else
            Return "%0" & code
        End If
    End Function

    ' Filter reserved characters
    Public Shared Function FilterEscapedCharacters(uriText As String) As String
        Dim result As String = ""
        Dim length As Integer = uriText.Length
        Dim index As Integer = uriText.IndexOf("%")
        Do While index >= 0
            result = result & Left(uriText, index)
            uriText = Mid(uriText, 1 + index)
            If uriText.Length < 3 Then
                Throw New UriFormatException("Invalid escape sequence.")
            End If
            Dim token As String = "&h" & Mid(uriText, 2, 2)
            uriText = Mid(uriText, 4)
            result = result & ChrW(Val(token))
            index = uriText.IndexOf("%")
        Loop
        Return result & uriText
    End Function

End Class

