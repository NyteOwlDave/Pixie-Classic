﻿
'
' NetworkShareName class
'
' Provides basic functionality for parsing and composing a Lan Manager share name.
'

Public Class NetworkShareName

    ' Symbol class
    Public Class Symbol
        Private Value As String = ""
        Public Property Name As String
            Get
                Return Me.Value
            End Get
            Set(value As String)
                Me.Value = GetCanonicalName(value)
            End Set
        End Property
        Public ReadOnly Property IsEmpty As Boolean
            Get
                If Me.Value.Length > 0 Then
                    Return False
                Else
                    Return True
                End If
            End Get
        End Property
        Public Sub Clear()
            Me.Value = ""
        End Sub
        Public Shared Function GetCanonicalName(name As String) As String
            Dim result As New System.Text.StringBuilder(1024)
            For Each ch As Char In name
                If Char.IsLetter(ch) Then
                    result.Append(ch)
                End If
            Next
            Return result.ToString
        End Function
    End Class

    ' Internal state structure
    Private Class InternalState
        Public Host As New Symbol
        Public Share As New Symbol
        Public Sub Initialize(Optional hostName As String = "", Optional shareName As String = "")
            With Me.Host
                .Name = hostName
                If .IsEmpty Then
                    .Name = My.Computer.Name
                End If
            End With
            With Me.Share
                .Name = shareName
            End With
        End Sub
        Public Sub Clear()
            Me.Host.Clear()
            Me.Share.Clear()
        End Sub
        Public Function ComposeLocation() As String
            If Me.Host.IsEmpty Then
                Me.Initialize()
            End If
            If Me.Share.IsEmpty Then
                Return "\\" & Me.Host.Name
            Else
                Return "\\" & Me.Host.Name & "\" & Me.Share.Name
            End If
        End Function
        Public Sub ParseLocation(location As String)
            Me.Clear()
            Dim s As String = Trim(location)
            If s.StartsWith("\\") Then
                s = s.Remove(0, 2)
                Dim pos As Integer = s.IndexOf("\")
                If pos > 0 Then
                    Me.Host.Name = Left(s, pos)
                    Me.Share.Name = s.Remove(0, 1 + pos)
                End If
            End If
        End Sub
    End Class

    ' Internal state instance
    Private State As New InternalState

    ' Construction
    Public Sub New(Optional location As String = "")
        Me.Initialize(location)
    End Sub

    ' Initialization
    Public Sub Initialize(location As String)
        Me.State.ParseLocation(location)
    End Sub

    ' Initialization
    Public Sub Initialize(host As String, share As String)
        Me.State.Initialize(host, share)
    End Sub

    ' Access to host name
    Public Property HostName As String
        Get
            Return Me.State.Host.Name
        End Get
        Set(value As String)
            Me.State.Host.Name = value
        End Set
    End Property

    ' Access to share name
    Public Property ShareName As String
        Get
            Return Me.State.Share.Name
        End Get
        Set(value As String)
            Me.State.Share.Name = value
        End Set
    End Property

    ' Access to location
    Public Property Location As String
        Get
            Return Me.State.ComposeLocation()
        End Get
        Set(value As String)
            Me.State.ParseLocation(value)
        End Set
    End Property

End Class


