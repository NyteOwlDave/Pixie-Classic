﻿
Module SupportModule

    Public Function GetSafeString(s As String) As String
        If s Is Nothing Then Return String.Empty
        Return s.Trim()
    End Function

End Module

