﻿
Public Module SystemModule

    ' Terminate the application with an exit code
    Public Sub Terminate(Optional exitCode As Integer = 0)
        Environment.Exit(exitCode)
    End Sub

    ' Get the currently executing assembly
    Public ReadOnly Property ExecutingAssembly As System.Reflection.Assembly
        Get
            Return System.Reflection.Assembly.GetExecutingAssembly()
        End Get
    End Property

End Module

