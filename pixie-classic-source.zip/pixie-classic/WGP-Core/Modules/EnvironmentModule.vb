﻿
Public Module EnvironmentModule

    Public Const ListFileEnvironVariable = "LISTFILE"
    Public Const TemplateFileEnvironVariable = "TEMPLATEFILE"

    Public Function GetEnvironmentVariable(name As String) As String
        Try
            Return My.Application.GetEnvironmentVariable(name)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return ""
        End Try
    End Function

    Public Function GetCommandArgumentCount() As Integer
        Try
            Return Environment.GetCommandLineArgs.Length
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return 0
        End Try
    End Function

    Public Function GetCommandArgument(index) As String
        Try
            Return Environment.GetCommandLineArgs(index)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return ""
        End Try
    End Function

End Module

