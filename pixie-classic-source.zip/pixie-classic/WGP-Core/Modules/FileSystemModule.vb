﻿
Imports System.Runtime.InteropServices

Public Module FileSystemModule

    <DllImport("kernel32.dll", CharSet:=CharSet.Unicode)> _
    Private Function GetShortPathNameW(<MarshalAs(UnmanagedType.LPWStr)> longName As String,
                                       <MarshalAs(UnmanagedType.LPWStr)> shortName As String,
                                       ByVal byteCount As Integer) As Integer
    End Function

    ' Convert a long path name to a short path name
    Public Function GetShortPathName(pathName As String) As String

        Try

            Dim count = 1024
            Dim shortPath As String = ""

            For n = 1 To count
                shortPath += Chr(0)
            Next

            Dim ok = GetShortPathNameW(pathName, shortPath, count)
            Return shortPath

        Catch ex As Exception

            DebugModule.SilentExceptionReport(ex)

        End Try

        Return pathName

    End Function

    ' Determine if file exists
    Public Function FileExists(pathName As String) As Boolean
        Return My.Computer.FileSystem.FileExists(pathName)
    End Function

    ' Determine if folder exists
    Public Function FolderExists(pathName As String) As Boolean
        Return My.Computer.FileSystem.DirectoryExists(pathName)
    End Function

    ' Get information about a file
    Public Function GetFileInfo(pathName As String) As IO.FileInfo
        Return New IO.FileInfo(pathName)
    End Function

    ' Get information about a folder
    Public Function GetFolderInfo(pathName As String) As IO.DirectoryInfo
        Return New IO.DirectoryInfo(pathName)
    End Function

    ' Create a new folder
    Public Function CreateFolder(pathName As String) As Boolean
        Try
            Dim info = IO.Directory.CreateDirectory(pathName)
            Return info.Exists
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Delete a folder (safe)
    Public Function DeleteFolderIfEmpty(pathName As String) As Boolean
        Try
            IO.Directory.Delete(pathName, False)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Delete a folder (unsafe! does not prompt for confirmation or recycle content)
    Public Function DeleteFolderUnsafe(pathName As String) As Boolean
        Try
            IO.Directory.Delete(pathName, True)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Rename a folder
    Public Function RenameFolder(sourceLocation As String, targetLocation As String) As Boolean
        Try
            My.Computer.FileSystem.RenameDirectory(sourceLocation, targetLocation)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Move a folder
    Public Function MoveFolder(sourceLocation As String, targetLocation As String) As Boolean
        Try
            My.Computer.FileSystem.MoveDirectory(sourceLocation, targetLocation)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Create a file
    Public Function CreateFile(pathName As String) As Boolean
        Try
            My.Computer.FileSystem.WriteAllText(pathName, "", False)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Delete a file
    Public Function DeleteFile(pathName As String) As Boolean
        Try
            IO.File.Delete(pathName)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Rename a file
    Public Function RenameFile(sourceLocation As String, targetLocation As String) As Boolean
        Try
            My.Computer.FileSystem.RenameFile(sourceLocation, targetLocation)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Copy a file
    Public Function CopyFile(sourceLocation As String, targetLocation As String) As Boolean
        Try
            My.Computer.FileSystem.CopyFile(sourceLocation, targetLocation)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Move a file
    Public Function MoveFile(sourceLocation As String, targetLocation As String) As Boolean
        Try
            My.Computer.FileSystem.MoveFile(sourceLocation, targetLocation)
            Return True
        Catch ex As Exception
            DebugModule.SilentExceptionReport(ex)
            Return False
        End Try
    End Function

    ' Create logical drive
    Public Function CreateLogicalDrive(letter As Char, location As String) As Boolean
        Return LogicalDrive.Create(letter, location, False)
    End Function

    ' Remove a logical drive
    Public Function RemoveLogicalDrive(letter As Char, location As String) As Boolean
        Return LogicalDrive.Remove(letter, location, False)
    End Function

    ' Remove a logical drive
    Public Function QueryLogicalDrive(letter As Char) As String
        Return LogicalDrive.Query(letter)
    End Function

    ' Get a list of the file name extensions in the specified folder
    Public Function GetFileNameExtensions(location As String) As String()

        Const splitToken As String = Chr(0)

        Dim result(0) As String

        Try

            Dim virgin = True

            Dim doc As String = ""

            Dim splitter As New NCS.FileNameSplitter

            Dim files = My.Computer.FileSystem.GetFiles(location)

            For Each file In files

                splitter.TitleAndExtension = file

                Dim ext = splitter.Extension

                If virgin Then
                    virgin = False
                    doc = ext
                Else
                    doc = doc + splitToken + ext
                End If

            Next

            result = Split(doc, splitToken)

        Catch ex As Exception

            SilentExceptionReport(ex)

        End Try

        Return result

    End Function

End Module

