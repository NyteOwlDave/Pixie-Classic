﻿
'
' Network module
'
' Provides some essential networking capabilities.
'

Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports NCS.Conceptual.Network.Datagram
Imports NCS.Conceptual.Network.IPv4

Public Module NetworkModule

    ' Send a datagram to an arbitrary host and port
    Public Function SendDatagram(hostName As String, port As Integer, message As String) As Boolean
        Try
            Dim dispatch As New DatagramClientDispatcher(hostName, port)
            DatagramTransmitterModule.TransmitAscii(dispatch, message)
            Return True
        Catch ex As Exception
            TraceException(ex)
            Return False
        End Try
    End Function

    ' Get IP4 address for an already resolved host entry
    Public Function GetIPv4Address(entry As IPHostEntry) As IPAddress
        Dim ip4 As New Ip4Address(entry)
        Return ip4.Address
    End Function

    ' Get the IP4 address for an arbitrary host
    Public Function GetHostIp4Address(hostName As String) As IPAddress
        Try
            Dim result As New Ip4Address(hostName)
            Return result.Address
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return Nothing
        End Try
    End Function

    ' Get an IP4 endpoint for an arbitrary host and port
    Public Function GetHostIp4Endpoint(hostName As String, port As String) As IPEndPoint
        Try
            Dim result As New Ip4Endpoint(hostName, port)
            Return New IPEndPoint(result.Address, result.Port)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return Nothing
        End Try
    End Function

    ' Determine if an arbitrary host is available
    Public Function IsHostAvailable(hostName As String) As Boolean
        If GetHostIp4Address(hostName) Is Nothing Then
            Return False
        Else
            Return True
        End If
    End Function

    ' Ping an arbitrary host
    Public Function PingHostOrAddress(target As String) As Boolean
        Try
            Return My.Computer.Network.Ping(target)
        Catch ex As Exception
            SilentExceptionReport(ex)
            Return False
        End Try
    End Function

End Module
