﻿
Public Module DebugModule

    ' Write a message to the debug console
    Public Sub DebugOut(msg As String)
        Debug.Print("=> " + msg)
    End Sub

    ' Write an initialization item message to the debug console
    Public Sub DebugReportInitialize(structName As String)
        DebugOut("Completed " + structName + ".Initialize() method.")
    End Sub

    ' Report a feature as not yet implemented
    Public Sub DebugReportNotImplemented(featureName As String)

        Dim s = "Feature is not yet implemented: " + featureName
        DebugOut(s)

    End Sub

    ' Write a checklist item message to the debug console
    Public Sub DebugCheckListItem(msg As String, success As Boolean)

        If success Then
            DebugOut(" [.] " + msg)
        Else
            DebugOut(" [!] " + msg)
        End If

    End Sub

    ' Silently report an exception
    Public Sub SilentExceptionReport(ex As Exception)
        TraceException(ex)
    End Sub

    ' Trace an exception
    Public Sub TraceException(ex As Exception)
        If ex Is Nothing Then Return
        Debug.Print(vbNewLine)
        Debug.Print("[EXCEPTION]")
        Debug.Print(ex.Source & " ---> " & ex.Message)
        TraceException(ex.InnerException)
        Debug.Print(vbNewLine)
    End Sub

End Module
