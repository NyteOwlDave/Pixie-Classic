﻿
'
' ITraceListener interface
'
' My very favoritest simplest interface of all!!!
'   (ROFLMBO)
'
' For a simple/safe way to report messages to a listener, see the TraceReporter class...
'

' Trace listener interface
Public Interface ITraceListener
    Sub Report(message As String)
End Interface

