﻿
'
' Registry interfaces
'

Public Interface IRegistryKey
    ReadOnly Property Key As Microsoft.Win32.RegistryKey
    Function ReadValue(name As String) As String
    Sub WriteValue(name As String, value As String)
End Interface
