﻿
'
' Collection interfaces
'

' Named item properties
Public Interface INamedItemProperties
    ReadOnly Property Key As Guid
    ReadOnly Property Name As String
    ReadOnly Property Initialized As Boolean
End Interface

' Named object properties
Public Interface INamedObjectProperties
    ReadOnly Property Key As Guid
    ReadOnly Property Name As String
    ReadOnly Property Value As Object
    ReadOnly Property Initialized As Boolean
End Interface

' Named location properties
Public Interface INamedLocationProperties
    ReadOnly Property Key As Guid
    ReadOnly Property Name As String
    ReadOnly Property Location As Uri
    ReadOnly Property Initialized As Boolean
End Interface

' Named enumeration properties
Public Interface INamedEnumerationProperties
    ReadOnly Property Key As Guid
    ReadOnly Property Name As String
    ReadOnly Property Enumerator As IEnumerator
    ReadOnly Property Initialized As Boolean
End Interface

' Named list properties
Public Interface INamedListProperties
    ReadOnly Property Key As Guid
    ReadOnly Property Name As String
    ReadOnly Property Count As Integer
    ReadOnly Property Item(index As Integer) As INamedItemProperties
    ReadOnly Property Initialized As Boolean
End Interface

' Named index properties
Public Interface INamedIndexProperties
    ReadOnly Property Key As Guid
    ReadOnly Property Name As String
    ReadOnly Property Count As Integer
    ReadOnly Property Item(key As Guid) As INamedItemProperties
    ReadOnly Property Initialized As Boolean
End Interface

